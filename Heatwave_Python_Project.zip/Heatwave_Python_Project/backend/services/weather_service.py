"""Weather snapshot for ALL states, built from ONE bulk Open-Meteo request.

Flow:  Open-Meteo  ->  in-memory cache (TTL)  ->  saved to the SQLite database
If Open-Meteo fails we fall back to (1) the last in-memory copy, then
(2) the last data stored in the database - and we SAY so in the response.
We never invent numbers.
"""

import json
import logging
import threading
from datetime import datetime

from flask import current_app

from ..data.reference import describe_weather_code
from ..db import connect, query
from . import open_meteo
from .cache import TtlCache
from .heat_risk import risk_series
from .state_service import list_states
from .utils import IST, add_days, iso, iso_now, today_ist

log = logging.getLogger(__name__)

cache = TtlCache()
BULK_KEY = "bulk-all-states"
PAST_DAYS = 30
FORECAST_DAYS = 7


class WeatherUnavailable(Exception):
    status = 503


def build_state_snapshot(state, om, today):
    """Pure function: one Open-Meteo location entry -> our per-state structure."""
    rows = [{**r, "weatherCondition": describe_weather_code(r["weatherCode"])} for r in open_meteo.daily_rows(om.get("daily"))]
    past = [r for r in rows if r["date"] < today]
    forecast = [r for r in rows if r["date"] >= today]
    c = om.get("current")
    current = None
    if c:
        current = {
            "temperature": c.get("temperature_2m"),
            "apparentTemperature": c.get("apparent_temperature"),
            "humidity": c.get("relative_humidity_2m"),
            "windSpeed": c.get("wind_speed_10m"),
            "weatherCode": c.get("weather_code"),
            "weatherCondition": describe_weather_code(c.get("weather_code")),
            "time": c.get("time"),  # local time (Asia/Kolkata) of the model step
        }
    risks = risk_series(past, forecast, current["humidity"] if current else None)
    for d, r in zip(forecast, risks):
        d["risk"] = r
    return {
        "stateId": state["id"],
        "code": state["code"],
        "name": state["name"],
        "repLocation": state["repLocation"],
        "latitude": state["latitude"],
        "longitude": state["longitude"],
        "elevation": om.get("elevation"),
        "current": current,
        "past": past,
        "forecast": forecast,
        "risk": forecast[0]["risk"] if forecast else None,
    }


def fetch_live():
    states = list_states()
    if not states:
        raise RuntimeError("No states in database.")
    results = open_meteo.fetch_forecast_bulk(states, past_days=PAST_DAYS, forecast_days=FORECAST_DAYS)
    if len(results) != len(states):
        raise RuntimeError(f"Open-Meteo returned {len(results)} locations for {len(states)} states")
    today = today_ist()
    by_code = {s["code"]: build_state_snapshot(s, results[i], today) for i, s in enumerate(states)}
    snapshot = {"fetchedAt": iso_now(), "today": today, "states": by_code}

    db_path = current_app.config["DATABASE"]
    if current_app.config.get("PERSIST_ASYNC", True):
        threading.Thread(target=_persist_safely, args=(db_path, snapshot), daemon=True).start()
    else:
        persist_snapshot(db_path, snapshot)
    return snapshot


def _persist_safely(db_path, snapshot):
    try:
        persist_snapshot(db_path, snapshot)
    except Exception as e:  # never let a background save crash the server
        log.error("[weather] persist failed: %s", e)


def persist_snapshot(db_path, snapshot):
    """Store what we fetched (demonstrates INSERT / UPSERT on the weather tables)."""
    now = iso_now()
    conn = connect(db_path)
    try:
        with conn:  # one transaction
            for s in snapshot["states"].values():
                c = s["current"]
                if c and isinstance(c.get("temperature"), (int, float)):
                    observed = datetime.fromisoformat(c["time"]).replace(tzinfo=IST)
                    conn.execute(
                        """INSERT INTO weather_records (stateId, temperature, apparentTemperature, humidity, windSpeed,
                               weatherCode, weatherCondition, observedAt, recordedAt)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (s["stateId"], c["temperature"], c["apparentTemperature"], c["humidity"], c["windSpeed"],
                         c["weatherCode"], c["weatherCondition"], iso(observed), now),
                    )
                for d in s["forecast"]:
                    if not isinstance(d.get("maxTemperature"), (int, float)):
                        continue
                    conn.execute(
                        """INSERT INTO forecasts (stateId, date, minTemperature, maxTemperature, apparentTemperature,
                               humidity, precipitation, windSpeed, weatherCode, weatherCondition, createdAt, updatedAt)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                           ON CONFLICT(stateId, date) DO UPDATE SET
                               minTemperature = excluded.minTemperature, maxTemperature = excluded.maxTemperature,
                               apparentTemperature = excluded.apparentTemperature, humidity = excluded.humidity,
                               precipitation = excluded.precipitation, windSpeed = excluded.windSpeed,
                               weatherCode = excluded.weatherCode, weatherCondition = excluded.weatherCondition,
                               updatedAt = excluded.updatedAt""",
                        (s["stateId"], d["date"], d["minTemperature"], d["maxTemperature"],
                         d["apparentTemperature"] if d.get("apparentTemperature") is not None else d["maxTemperature"],
                         d.get("humidity"), d.get("precipitation"), d.get("windSpeed"),
                         d["weatherCode"] if d.get("weatherCode") is not None else 0, d["weatherCondition"], now, now),
                    )
                for d in s["past"]:
                    if not isinstance(d.get("maxTemperature"), (int, float)):
                        continue
                    conn.execute(
                        """INSERT INTO historical_weather (stateId, date, minTemperature, maxTemperature,
                               averageTemperature, apparentTemperature, source)
                           VALUES (?, ?, ?, ?, ?, ?, 'open-meteo-forecast-past')
                           ON CONFLICT(stateId, date) DO UPDATE SET
                               minTemperature = excluded.minTemperature, maxTemperature = excluded.maxTemperature,
                               averageTemperature = excluded.averageTemperature,
                               apparentTemperature = excluded.apparentTemperature, source = excluded.source""",
                        (s["stateId"], d["date"], d["minTemperature"], d["maxTemperature"],
                         d["averageTemperature"], d.get("apparentTemperature")),
                    )
                r = s["risk"]
                if r:
                    conn.execute(
                        "INSERT INTO heat_risk (stateId, forDate, score, riskLevel, factors, calculatedAt) VALUES (?, ?, ?, ?, ?, ?)",
                        (s["stateId"], r["date"], r["score"], r["riskLevel"], json.dumps(r["factors"]), now),
                    )
    finally:
        conn.close()


def snapshot_from_database():
    """Rebuild a snapshot purely from the database (used when Open-Meteo is down)."""
    states = list_states()
    today = today_ist()
    since = add_days(today, -PAST_DAYS)
    # latest weather record per state
    records = query(
        """SELECT w.* FROM weather_records w
           JOIN (SELECT stateId, MAX(recordedAt) AS mx FROM weather_records GROUP BY stateId) last
             ON last.stateId = w.stateId AND last.mx = w.recordedAt"""
    )
    forecasts = query("SELECT * FROM forecasts WHERE date >= ? ORDER BY date ASC", (today,))
    history = query("SELECT * FROM historical_weather WHERE date >= ? AND date < ? ORDER BY date ASC", (since, today))
    if not records and not forecasts:
        return None

    newest = None
    by_code = {}
    for st in states:
        rec = next((r for r in records if r["stateId"] == st["id"]), None)
        if rec and (newest is None or rec["recordedAt"] > newest):
            newest = rec["recordedAt"]
        past = [{"date": h["date"], "maxTemperature": h["maxTemperature"], "minTemperature": h["minTemperature"],
                 "averageTemperature": h["averageTemperature"], "apparentTemperature": h["apparentTemperature"]}
                for h in history if h["stateId"] == st["id"]]
        forecast = [{"date": f["date"], "maxTemperature": f["maxTemperature"], "minTemperature": f["minTemperature"],
                     "apparentTemperature": f["apparentTemperature"], "humidity": f["humidity"],
                     "precipitation": f["precipitation"], "windSpeed": f["windSpeed"], "weatherCode": f["weatherCode"],
                     "weatherCondition": f["weatherCondition"]}
                    for f in forecasts if f["stateId"] == st["id"]]
        current = None
        if rec:
            current = {"temperature": rec["temperature"], "apparentTemperature": rec["apparentTemperature"],
                       "humidity": rec["humidity"], "windSpeed": rec["windSpeed"], "weatherCode": rec["weatherCode"],
                       "weatherCondition": rec["weatherCondition"], "time": rec["observedAt"]}
        risks = risk_series(past, forecast, current["humidity"] if current else None)
        for d, r in zip(forecast, risks):
            d["risk"] = r
        by_code[st["code"]] = {
            "stateId": st["id"], "code": st["code"], "name": st["name"], "repLocation": st["repLocation"],
            "latitude": st["latitude"], "longitude": st["longitude"], "current": current, "past": past,
            "forecast": forecast, "risk": forecast[0]["risk"] if forecast else None,
        }
    return {"fetchedAt": newest or iso_now(), "today": today, "states": by_code}


def get_snapshot():
    """Main entry: returns (snapshot, meta). meta tells the UI how fresh the data is."""
    ttl = current_app.config["WEATHER_CACHE_SECONDS"]
    try:
        value, _stored, from_cache = cache.wrap(BULK_KEY, ttl, fetch_live)
        return value, {"source": "cache" if from_cache else "live", "stale": False, "lastUpdated": value["fetchedAt"]}
    except Exception as err:
        log.error("[weather] live fetch failed: %s", err)
        stale = cache.get_stale(BULK_KEY)
        if stale:
            v = stale["value"]
            return v, {"source": "memory", "stale": True, "lastUpdated": v["fetchedAt"],
                       "message": f"Showing cached data — last updated: {v['fetchedAt']}"}
        try:
            from_db = snapshot_from_database()
        except Exception as db_err:
            log.error("[weather] database fallback failed: %s", db_err)
            from_db = None
        if from_db:
            return from_db, {"source": "database", "stale": True, "lastUpdated": from_db["fetchedAt"],
                             "message": f"Showing cached data from the database — last updated: {from_db['fetchedAt']}"}
        raise WeatherUnavailable("Weather data temporarily unavailable.")
