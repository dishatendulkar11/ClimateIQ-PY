"""Small helpers shared by the services: dates in India time, rounding
that behaves like JavaScript's Math.round, and number checks."""

import math
import re
from datetime import date, datetime, timedelta, timezone

# India has no daylight saving, so a fixed +05:30 offset is exact
# (and avoids needing the tzdata package on Windows).
IST = timezone(timedelta(hours=5, minutes=30))
_YMD = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def today_ist(now=None):
    """Today's date in India as 'YYYY-MM-DD'."""
    now = now or datetime.now(timezone.utc)
    return now.astimezone(IST).strftime("%Y-%m-%d")


def add_days(ymd, n):
    return (date.fromisoformat(ymd) + timedelta(days=n)).isoformat()


def days_between(a, b):
    return (date.fromisoformat(b) - date.fromisoformat(a)).days


def is_ymd(s):
    if not isinstance(s, str) or not _YMD.match(s):
        return False
    try:
        date.fromisoformat(s)
        return True
    except ValueError:
        return False


def iso_now():
    """Current UTC time as an ISO string with milliseconds and 'Z'."""
    return iso(datetime.now(timezone.utc))


def iso(dt):
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"


def parse_iso(s):
    """Parse an ISO string produced by iso() back into an aware datetime."""
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def js_round(x, digits=0):
    """Round half away from zero for positives, like JavaScript Math.round
    (Python's round() uses banker's rounding, which would change scores)."""
    f = 10 ** digits
    return math.floor(x * f + 0.5) / f


def round1(x):
    return js_round(x, 1)


def is_num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def clamp01(x):
    return max(0.0, min(1.0, x))
