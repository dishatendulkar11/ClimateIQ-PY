"""Low-level Open-Meteo client. All HTTP calls to Open-Meteo live here.

Docs: https://open-meteo.com/en/docs                       (forecast)
      https://open-meteo.com/en/docs/historical-weather-api (archive)
The free endpoints need no API key.
"""

import requests

from .utils import js_round

FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
TIMEZONE = "Asia/Kolkata"

CURRENT_VARS = ["temperature_2m", "relative_humidity_2m", "apparent_temperature", "weather_code", "wind_speed_10m"]
DAILY_VARS_FULL = [
    "weather_code", "temperature_2m_max", "temperature_2m_min", "temperature_2m_mean",
    "apparent_temperature_max", "precipitation_sum", "wind_speed_10m_max", "relative_humidity_2m_mean",
]
# Fallback if the API ever rejects one of the optional variables above
DAILY_VARS_CORE = ["weather_code", "temperature_2m_max", "temperature_2m_min", "apparent_temperature_max",
                   "precipitation_sum", "wind_speed_10m_max"]
ARCHIVE_DAILY_VARS = ["temperature_2m_max", "temperature_2m_min", "temperature_2m_mean", "apparent_temperature_max"]


class OpenMeteoError(Exception):
    def __init__(self, message, status=503):
        super().__init__(message)
        self.status = status


def get_json(url, params, timeout=15):
    try:
        res = requests.get(url, params=params, timeout=timeout, headers={"Accept": "application/json"})
    except requests.Timeout:
        raise OpenMeteoError("Open-Meteo request timed out", 504)
    except requests.RequestException as e:
        raise OpenMeteoError(f"Open-Meteo unreachable: {e}", 503)
    try:
        body = res.json()
    except ValueError:
        body = None
    if not res.ok:
        reason = body.get("reason") if isinstance(body, dict) and body.get("reason") else res.reason
        raise OpenMeteoError(f"Open-Meteo {res.status_code}: {reason}", res.status_code)
    if isinstance(body, dict) and body.get("error"):
        raise OpenMeteoError(f"Open-Meteo: {body.get('reason')}", 400)
    return body


def fetch_forecast_bulk(locations, past_days=30, forecast_days=7):
    """ONE request for MANY coordinates. Open-Meteo accepts comma-separated
    latitude/longitude lists and returns a list (one entry per location) with
    current conditions + past_days of recent daily data + forecast_days."""
    base = {
        "latitude": ",".join(f"{l['latitude']:.4f}" for l in locations),
        "longitude": ",".join(f"{l['longitude']:.4f}" for l in locations),
        "current": ",".join(CURRENT_VARS),
        "timezone": TIMEZONE,
        "past_days": str(past_days),
        "forecast_days": str(forecast_days),
        "temperature_unit": "celsius",
        "wind_speed_unit": "kmh",
    }
    try:
        data = get_json(FORECAST_URL, {**base, "daily": ",".join(DAILY_VARS_FULL)})
    except OpenMeteoError as err:
        if err.status != 400:
            raise
        data = get_json(FORECAST_URL, {**base, "daily": ",".join(DAILY_VARS_CORE)})
    return data if isinstance(data, list) else [data]


def fetch_daily_range(lat, lon, start_date, end_date, archive=False):
    """Daily data for a date range at one location."""
    params = {
        "latitude": f"{lat:.4f}",
        "longitude": f"{lon:.4f}",
        "start_date": start_date,
        "end_date": end_date,
        "daily": ",".join(ARCHIVE_DAILY_VARS),
        "timezone": TIMEZONE,
        "temperature_unit": "celsius",
    }
    try:
        return get_json(ARCHIVE_URL if archive else FORECAST_URL, params)
    except OpenMeteoError as err:
        if err.status != 400 or archive:
            raise
        # forecast endpoint without temperature_2m_mean
        return get_json(FORECAST_URL, {**params, "daily": "temperature_2m_max,temperature_2m_min,apparent_temperature_max"})


def daily_rows(daily):
    """Turn Open-Meteo's column arrays into a list of row dictionaries."""
    if not daily or not isinstance(daily.get("time"), list):
        return []

    def pick(key, i):
        col = daily.get(key)
        return col[i] if isinstance(col, list) and i < len(col) else None

    rows = []
    for i, day in enumerate(daily["time"]):
        mx = pick("temperature_2m_max", i)
        mn = pick("temperature_2m_min", i)
        mean = pick("temperature_2m_mean", i)
        derived = False
        if mean is None and mx is not None and mn is not None:
            mean = js_round((mx + mn) / 2, 1)
            derived = True
        rows.append({
            "date": day,
            "maxTemperature": mx,
            "minTemperature": mn,
            "averageTemperature": mean,
            "averageDerived": derived,
            "apparentTemperature": pick("apparent_temperature_max", i),
            "weatherCode": pick("weather_code", i),
            "precipitation": pick("precipitation_sum", i),
            "windSpeed": pick("wind_speed_10m_max", i),
            "humidity": pick("relative_humidity_2m_mean", i),
        })
    return rows
