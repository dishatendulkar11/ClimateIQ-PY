"""India state/UT administrative boundaries (GeoJSON).

The file lives at static/data/india_states.geojson (included in the project;
built from the open india-maps-data dataset). Every feature is matched to our
`states` table and tagged with state_code / state_id / state_name so the map
can join weather + risk to the right polygon.
"""

import json
import logging
import os
import re

log = logging.getLogger(__name__)

NAME_PROPS = ["ST_NM", "st_nm", "NAME_1", "name_1", "STATE", "State", "state", "state_name", "State_Name",
              "STATE_NAME", "stname", "NAME", "name", "Name"]

# normalized dataset name -> our state code
ALIASES = {
    "andhrapradesh": "AP", "arunachalpradesh": "AR", "arunanchalpradesh": "AR", "assam": "AS", "bihar": "BR",
    "chhattisgarh": "CG", "chattisgarh": "CG", "goa": "GA", "gujarat": "GJ", "haryana": "HR", "himachalpradesh": "HP",
    "jharkhand": "JH", "karnataka": "KA", "kerala": "KL", "madhyapradesh": "MP", "maharashtra": "MH", "manipur": "MN",
    "meghalaya": "ML", "mizoram": "MZ", "nagaland": "NL", "odisha": "OD", "orissa": "OD", "punjab": "PB", "rajasthan": "RJ",
    "sikkim": "SK", "tamilnadu": "TN", "telangana": "TG", "telengana": "TG", "tripura": "TR", "uttarpradesh": "UP",
    "uttarakhand": "UK", "uttaranchal": "UK", "westbengal": "WB",
    "andamanandnicobarislands": "AN", "andamanandnicobarisland": "AN", "andamanandnicobar": "AN",
    "andamannicobarislands": "AN", "andamannicobar": "AN",
    "chandigarh": "CH",
    "dadraandnagarhavelianddamananddiu": "DH", "dadraandnagarhaveli": "DH", "dadarandnagarhaveli": "DH",
    "dadaraandnagarhavelli": "DH", "dadraandnagarhavelli": "DH", "dadaraandnagarhaveli": "DH", "damananddiu": "DH",
    "thedadraandnagarhavelianddamananddiu": "DH", "dnhanddd": "DH",
    "delhi": "DL", "nctofdelhi": "DL", "nationalcapitalterritoryofdelhi": "DL",
    "jammuandkashmir": "JK", "jammukashmir": "JK", "ladakh": "LA", "lakshadweep": "LD", "puducherry": "PY",
    "pondicherry": "PY",
}


def _norm(s):
    return re.sub(r"[^a-z]", "", str(s or "").lower().replace("&", "and"))


def match_code(raw_name):
    n = _norm(raw_name)
    if n in ALIASES:
        return ALIASES[n]
    # tolerate prefixes/suffixes like "State of ..." or "... (UT)"
    hits = sorted((k for k in ALIASES if len(k) > 4 and k in n), key=len, reverse=True)
    return ALIASES[hits[0]] if hits else None


def _detect_name_prop(features):
    props = (features[0].get("properties") or {}) if features else {}
    return next((p for p in NAME_PROPS if isinstance(props.get(p), str)), None)


def _round_coords(c):
    if isinstance(c[0], (int, float)):
        return [round(c[0], 4), round(c[1], 4)]
    return [_round_coords(x) for x in c]


def tag_features(raw, states):
    """Tag features with state codes. Returns (geojson, unmatched_names, name_prop)."""
    features = raw.get("features", []) if raw.get("type") == "FeatureCollection" else []
    name_prop = _detect_name_prop(features)
    by_code = {s["code"]: s for s in states}
    unmatched, out = [], []
    for f in features:
        if not f or not f.get("geometry"):
            continue
        raw_name = f["properties"].get(name_prop) if name_prop else None
        code = match_code(raw_name)
        st = by_code.get(code) if code else None
        if not st:
            unmatched.append(raw_name)
        out.append({
            "type": "Feature",
            "properties": {
                "state_code": st["code"] if st else None,
                "state_id": st["id"] if st else None,
                "state_name": st["name"] if st else raw_name,
                "source_name": raw_name,
            },
            "geometry": {"type": f["geometry"]["type"], "coordinates": _round_coords(f["geometry"]["coordinates"])},
        })
    return {"type": "FeatureCollection", "features": out}, unmatched, name_prop


_memo = None


def load_geo(geo_path, states):
    """Load + tag the boundary file once. Returns None if the file is missing."""
    global _memo
    if _memo is not None:
        return _memo
    if not os.path.exists(geo_path):
        return None
    with open(geo_path, encoding="utf-8") as f:
        raw = json.load(f)
    geojson, unmatched, _ = tag_features(raw, states)
    if unmatched:
        log.warning("[geo] unmatched boundary names: %s", unmatched)
    _memo = geojson
    return _memo
