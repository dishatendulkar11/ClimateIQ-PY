"""Read access to the `states` reference table."""

from ..db import query

_cached = None


def list_states():
    """All states/UTs from the database (cached in memory - it is reference data)."""
    global _cached
    if _cached:
        return _cached
    rows = query("SELECT * FROM states ORDER BY name ASC")
    if rows:
        _cached = rows
    return rows


def reset_cache():
    global _cached
    _cached = None


def get_state(id_or_code):
    """Find a state by numeric id ('14') or by code ('MH', case-insensitive)."""
    if id_or_code is None:
        return None
    raw = str(id_or_code)
    key = raw.upper()
    for s in list_states():
        if str(s["id"]) == raw or s["code"] == key:
            return s
    return None


def public_state(s):
    return {
        "id": s["id"],
        "name": s["name"],
        "code": s["code"],
        "type": s["type"],
        "latitude": s["latitude"],
        "longitude": s["longitude"],
        "repLocation": s["repLocation"],
    }
