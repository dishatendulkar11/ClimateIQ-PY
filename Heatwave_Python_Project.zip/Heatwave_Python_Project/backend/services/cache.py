"""Tiny in-memory TTL cache with in-flight request de-duplication.

If several browser tabs ask for the same data at the same moment,
Open-Meteo is called only once; the other requests wait for that result.
"""

import threading
import time
from datetime import datetime, timezone


class TtlCache:
    def __init__(self):
        self._store = {}       # key -> {"value", "expires", "stored_at"}
        self._locks = {}       # key -> threading.Lock (one loader at a time per key)
        self._guard = threading.Lock()

    def get(self, key):
        hit = self._store.get(key)
        if not hit or time.time() > hit["expires"]:
            return None
        return hit

    def get_stale(self, key):
        """Last value even if expired (for 'showing cached data' fallbacks)."""
        return self._store.get(key)

    def set(self, key, value, ttl_seconds):
        entry = {"value": value, "stored_at": datetime.now(timezone.utc), "expires": time.time() + ttl_seconds}
        self._store[key] = entry
        return entry

    def clear(self):
        self._store.clear()

    def _lock_for(self, key):
        with self._guard:
            return self._locks.setdefault(key, threading.Lock())

    def wrap(self, key, ttl_seconds, loader):
        """Return the cached value or run loader() once.

        Returns (value, stored_at, from_cache)."""
        hit = self.get(key)
        if hit:
            return hit["value"], hit["stored_at"], True
        with self._lock_for(key):
            hit = self.get(key)  # another thread may have just loaded it
            if hit:
                return hit["value"], hit["stored_at"], True
            value = loader()
            entry = self.set(key, value, ttl_seconds)
            return value, entry["stored_at"], False
