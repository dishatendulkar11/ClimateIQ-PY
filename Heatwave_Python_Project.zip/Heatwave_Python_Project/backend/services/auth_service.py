"""Database-backed authentication.

Passwords: bcrypt (cost 12). Sessions: random 32-byte token in an HTTP-only
cookie; only its SHA-256 hash is stored in the `sessions` table.
"""

import hashlib
import re
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone

import bcrypt

from ..db import execute, query
from .utils import iso, iso_now, parse_iso

COOKIE_NAME = "ci_session"
BCRYPT_COST = 12
SESSION_DAYS = 7

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")
PHONE_RE = re.compile(r"^(\+91[\s-]?)?[6-9]\d{9}$")

# always run one bcrypt check, even for unknown emails (constant-ish time)
DUMMY_HASH = bcrypt.hashpw(b"dummy-password-for-timing", bcrypt.gensalt(10))


def sha256(s):
    return hashlib.sha256(s.encode()).hexdigest()


def public_user(u):
    return {k: u[k] for k in ("id", "fullName", "email", "phoneNumber", "city", "state", "createdAt", "updatedAt")}


# ---------- validation ----------
def _clean(s, max_len):
    return s.strip()[:max_len] if isinstance(s, str) else ""


def password_problems(pw):
    p = []
    pw_s = pw if isinstance(pw, str) else ""
    if not isinstance(pw, str) or len(pw) < 8:
        p.append("at least 8 characters")
    if not re.search(r"[A-Z]", pw_s):
        p.append("an uppercase letter")
    if not re.search(r"[a-z]", pw_s):
        p.append("a lowercase letter")
    if not re.search(r"\d", pw_s):
        p.append("a number")
    if len(pw_s) > 72:
        p.append("at most 72 characters")
    return p


def validate_profile(body, partial=False):
    errors, out = {}, {}
    if not partial or "fullName" in body:
        out["fullName"] = _clean(body.get("fullName"), 100)
        if len(out["fullName"]) < 2:
            errors["fullName"] = "Please enter your full name."
    if not partial or "city" in body:
        out["city"] = _clean(body.get("city"), 80)
        if not out["city"]:
            errors["city"] = "City is required."
    if not partial or "state" in body:
        out["state"] = _clean(body.get("state"), 80)
        if not out["state"]:
            errors["state"] = "State is required."
    if "phoneNumber" in body:
        ph = re.sub(r"\s+", "", _clean(body.get("phoneNumber"), 20))
        if ph and not PHONE_RE.match(ph):
            errors["phoneNumber"] = "Enter a valid 10-digit Indian mobile number."
        out["phoneNumber"] = ph or None
    return errors, out


def validate_registration(body):
    errors, data = validate_profile(body)
    data["email"] = _clean(body.get("email"), 150).lower()
    if not EMAIL_RE.match(data["email"]):
        errors["email"] = "Enter a valid email address."
    probs = password_problems(body.get("password"))
    if probs:
        errors["password"] = f"Password needs {', '.join(probs)}."
    if body.get("password") != body.get("confirmPassword"):
        errors["confirmPassword"] = "Passwords do not match."
    return errors, data


def _hash_password(pw):
    return bcrypt.hashpw(pw.encode()[:72], bcrypt.gensalt(BCRYPT_COST)).decode()


def _check_password(pw, hashed):
    try:
        return bcrypt.checkpw(str(pw or "").encode()[:72], hashed.encode() if isinstance(hashed, str) else hashed)
    except ValueError:
        return False


# ---------- sessions ----------
def create_session(user_id):
    token = secrets.token_hex(32)
    expires = datetime.now(timezone.utc) + timedelta(days=SESSION_DAYS)
    execute("INSERT INTO sessions (tokenHash, userId, expiresAt, createdAt) VALUES (?, ?, ?, ?)",
            (sha256(token), user_id, iso(expires), iso_now()))
    return token, expires


def user_from_token(token):
    if not token or not isinstance(token, str) or len(token) != 64:
        return None
    row = query(
        """SELECT s.id AS sessionId, s.expiresAt, u.* FROM sessions s JOIN users u ON u.id = s.userId
           WHERE s.tokenHash = ?""", (sha256(token),), one=True)
    if not row:
        return None
    if parse_iso(row["expiresAt"]) < datetime.now(timezone.utc):
        execute("DELETE FROM sessions WHERE id = ?", (row["sessionId"],))
        return None
    return row


def destroy_session(token):
    if token:
        execute("DELETE FROM sessions WHERE tokenHash = ?", (sha256(token),))


def purge_expired_sessions():
    execute("DELETE FROM sessions WHERE expiresAt < ?", (iso_now(),))


# ---------- operations ----------
def register(body):
    """Returns (user, errors)."""
    errors, data = validate_registration(body)
    if errors:
        return None, errors
    if query("SELECT id FROM users WHERE email = ?", (data["email"],), one=True):
        return None, {"email": "An account with this email already exists."}
    now = iso_now()
    try:
        cur = execute(
            """INSERT INTO users (fullName, email, passwordHash, phoneNumber, city, state, createdAt, updatedAt)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (data["fullName"], data["email"], _hash_password(body["password"]), data.get("phoneNumber"),
             data["city"], data["state"], now, now))
    except sqlite3.IntegrityError:
        return None, {"email": "An account with this email already exists."}
    return query("SELECT * FROM users WHERE id = ?", (cur.lastrowid,), one=True), None


def login(email, password):
    e = _clean(email, 150).lower()
    user = query("SELECT * FROM users WHERE email = ?", (e,), one=True) if e else None
    ok = _check_password(password, user["passwordHash"] if user else DUMMY_HASH.decode())
    return user if (ok and user) else None


def update_profile(user_id, body):
    errors, data = validate_profile(body, partial=True)
    if errors:
        return None, errors
    if data:
        sets = ", ".join(f"{k} = ?" for k in data)
        execute(f"UPDATE users SET {sets}, updatedAt = ? WHERE id = ?", (*data.values(), iso_now(), user_id))
    return query("SELECT * FROM users WHERE id = ?", (user_id,), one=True), None


def change_password(user_id, current_password, new_password, confirm_password):
    user = query("SELECT * FROM users WHERE id = ?", (user_id,), one=True)
    if not user or not _check_password(current_password, user["passwordHash"]):
        return {"currentPassword": "Current password is incorrect."}
    probs = password_problems(new_password)
    if probs:
        return {"newPassword": f"Password needs {', '.join(probs)}."}
    if new_password != confirm_password:
        return {"confirmPassword": "Passwords do not match."}
    execute("UPDATE users SET passwordHash = ?, updatedAt = ? WHERE id = ?",
            (_hash_password(new_password), iso_now(), user_id))
    return None
