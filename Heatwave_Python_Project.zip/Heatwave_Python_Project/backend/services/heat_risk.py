"""System-Generated Heat-Risk Estimate
------------------------------------
A TRANSPARENT, RULE-BASED score computed from real Open-Meteo data.
It is NOT a trained machine-learning model and NOT an official IMD warning.
The bands below are project-defined.

Score (0-100) = sum of five capped components:
  1. Maximum temperature          0-40  (linear 30 C -> 46 C)
  2. Max apparent ("feels like")  0-25  (linear 32 C -> 52 C)
  3. Humidity stress              0-10  (only when Tmax >= 32 C; RH 40 % -> 80 %)
  4. Persistence                  0-15  (5 pts per day >= 40 C in a 3-day window from this day)
  5. Anomaly vs recent baseline   0-10  (Tmax above the mean Tmax of the previous 30 days; +6 C = full)
"""

from .utils import clamp01, is_num, js_round, round1

BANDS = [
    {"level": "VERY_LOW", "min": 0, "max": 19, "label": "Very Low", "color": "#2e9e5b"},
    {"level": "LOW", "min": 20, "max": 34, "label": "Low", "color": "#8bc34a"},
    {"level": "MEDIUM", "min": 35, "max": 49, "label": "Medium", "color": "#f2c94c"},
    {"level": "ELEVATED", "min": 50, "max": 64, "label": "Elevated", "color": "#f2994a"},
    {"level": "HIGH", "min": 65, "max": 79, "label": "High", "color": "#e0412f"},
    {"level": "EXTREME", "min": 80, "max": 100, "label": "Extreme", "color": "#8b0f1a"},
]
LEVEL_ORDER = [b["level"] for b in BANDS]
HOT_DAY_C = 40

DISCLAIMER = (
    "System-Generated Heat-Risk Estimate: a transparent rule-based score from Open-Meteo data "
    "at one representative location per state. Risk bands are project-defined and are NOT "
    "official IMD / government heat-wave thresholds or warnings."
)


def fmt(x):
    """Format a number the way JavaScript prints it (46.0 -> '46', 46.5 -> '46.5')."""
    if float(x).is_integer():
        return str(int(x))
    return str(x)


def level_for_score(score):
    for b in BANDS:
        if b["min"] <= score <= b["max"]:
            return b
    return BANDS[-1]


def level_at_least(level, minimum):
    return LEVEL_ORDER.index(level) >= LEVEL_ORDER.index(minimum)


def _mean(nums):
    v = [n for n in nums if is_num(n)]
    return sum(v) / len(v) if v else None


def compute_heat_risk(day, window=None, baseline=None, fallback_humidity=None):
    """Score one day.

    day       - daily row (maxTemperature, apparentTemperature, humidity, date)
    window    - this day + following days (up to 3) for persistence
    baseline  - previous ~30 days of daily rows
    fallback_humidity - current humidity if the daily mean is unavailable
    Returns None when the maximum temperature is missing (we never invent numbers).
    """
    window = window or []
    baseline = baseline or []
    if not day or not is_num(day.get("maxTemperature")):
        return None

    tmax = day["maxTemperature"]
    app = day.get("apparentTemperature") if is_num(day.get("apparentTemperature")) else None
    if is_num(day.get("humidity")):
        rh = day["humidity"]
    elif is_num(fallback_humidity):
        rh = fallback_humidity
    else:
        rh = None
    hot_days = len([d for d in window[:3] if is_num(d.get("maxTemperature")) and d["maxTemperature"] >= HOT_DAY_C])
    base_mean = _mean([d.get("maxTemperature") for d in baseline])

    factors = []

    p_tmax = clamp01((tmax - 30) / 16) * 40
    factors.append({"key": "tmax", "label": "Maximum temperature", "value": f"{fmt(round1(tmax))} °C",
                    "points": round1(p_tmax), "max": 40,
                    "explain": "Scaled from 30 °C (0 pts) to 46 °C (40 pts)."})

    p_app = 0 if app is None else clamp01((app - 32) / 20) * 25
    factors.append({"key": "apparent", "label": "Feels-like (apparent) maximum",
                    "value": "n/a" if app is None else f"{fmt(round1(app))} °C",
                    "points": round1(p_app), "max": 25,
                    "explain": "Scaled from 32 °C (0 pts) to 52 °C (25 pts)."})

    p_rh = 0 if (rh is None or tmax < 32) else clamp01((rh - 40) / 40) * 10
    factors.append({"key": "humidity", "label": "Humidity stress",
                    "value": "n/a" if rh is None else f"{int(js_round(rh))} %",
                    "points": round1(p_rh), "max": 10,
                    "explain": "Counts only when Tmax ≥ 32 °C. RH 40 % = 0 pts, 80 % = 10 pts."})

    p_persist = min(15, hot_days * 5)
    span = min(3, len(window)) or 1
    factors.append({"key": "persistence", "label": "Hot-day persistence",
                    "value": f"{hot_days} of next {span} day(s) ≥ {HOT_DAY_C} °C",
                    "points": p_persist, "max": 15,
                    "explain": "5 pts for each day ≥ 40 °C in a 3-day window starting this day."})

    p_anom = 0
    anomaly_text = "n/a"
    if base_mean is not None:
        diff = tmax - base_mean
        p_anom = clamp01(diff / 6) * 10
        sign = "+" if diff >= 0 else ""
        anomaly_text = f"{sign}{fmt(round1(diff))} °C vs {fmt(round1(base_mean))} °C"
    factors.append({"key": "anomaly", "label": "Above recent 30-day mean Tmax", "value": anomaly_text,
                    "points": round1(p_anom), "max": 10,
                    "explain": "Compared with the previous 30 days only — this is NOT a long-term climate normal."})

    score = int(js_round(min(100, p_tmax + p_app + p_rh + p_persist + p_anom)))
    band = level_for_score(score)
    notes = []
    if tmax >= 45:
        notes.append("Max temperature at the representative point is ≥ 45 °C. IMD treats ≥ 45 °C as "
                     "heat-wave temperature regardless of normal — check official IMD bulletins.")
    return {
        "date": day.get("date"),
        "score": score,
        "riskLevel": band["level"],
        "label": band["label"],
        "color": band["color"],
        "factors": factors,
        "notes": notes,
    }


def risk_series(past, forecast, fallback_humidity=None):
    """Score every forecast day. past = rows before today, forecast = today onward."""
    baseline = past[-30:]
    return [
        compute_heat_risk(day, forecast[i:i + 3], baseline, fallback_humidity if i == 0 else None)
        for i, day in enumerate(forecast)
    ]
