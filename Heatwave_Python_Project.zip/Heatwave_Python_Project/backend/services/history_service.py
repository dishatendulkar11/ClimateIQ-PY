"""Historical daily temperatures for one state.

 - "7" / "30"  -> recent days, taken from the bulk snapshot (forecast API past_days)
 - "custom"    -> Open-Meteo: forecast endpoint for the last ~3 months,
                  ERA5-based Historical Weather (archive) API for older ranges.
Historical data is kept separate from forecast data everywhere.
"""

import logging

from flask import current_app

from ..db import connect
from . import open_meteo
from .cache import TtlCache
from .utils import add_days, days_between, is_ymd, iso, round1, today_ist
from .weather_service import get_snapshot

log = logging.getLogger(__name__)

cache = TtlCache()
SIX_HOURS = 6 * 3600
RECENT_LIMIT_DAYS = 85  # forecast API serves the recent past reliably within ~3 months
ARCHIVE_LAG_DAYS = 5    # archive (reanalysis) data is ~5 days behind
MAX_SPAN_DAYS = 366


class HistoryError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def summarize(rows):
    """Statistics for the summary cards: means, hottest day, coolest night, days >= 40 C."""
    valid = [r for r in rows if isinstance(r.get("maxTemperature"), (int, float))]
    if not valid:
        return None

    def avg(k):
        return round1(sum((r.get(k) or 0) for r in valid) / len(valid))

    hottest = valid[0]
    for r in valid:
        if r["maxTemperature"] > hottest["maxTemperature"]:
            hottest = r
    coolest = valid[0]
    for r in valid:
        if r["minTemperature"] < coolest["minTemperature"]:
            coolest = r
    return {
        "days": len(valid),
        "meanMax": avg("maxTemperature"),
        "meanMin": avg("minTemperature"),
        "meanAvg": avg("averageTemperature"),
        "hottestDay": {"date": hottest["date"], "value": hottest["maxTemperature"]},
        "coolestNight": {"date": coolest["date"], "value": coolest["minTemperature"]},
        "daysAbove40": len([r for r in valid if r["maxTemperature"] >= 40]),
    }


def validate_range(start, end):
    """Return an error message, or None when the custom range is valid."""
    today = today_ist()
    if not is_ymd(start) or not is_ymd(end):
        return "Dates must be YYYY-MM-DD."
    if start > end:
        return "Start date must be before end date."
    if end >= today:
        return "Historical range must end before today (use the Forecast page for today and later)."
    if start < "1940-01-01":
        return "Open-Meteo historical data starts in 1940."
    if days_between(start, end) + 1 > MAX_SPAN_DAYS:
        return f"Please choose at most {MAX_SPAN_DAYS} days."
    return None


def _strip(r):
    return {
        "date": r["date"], "maxTemperature": r["maxTemperature"], "minTemperature": r["minTemperature"],
        "averageTemperature": r.get("averageTemperature"), "averageDerived": bool(r.get("averageDerived")),
        "apparentTemperature": r.get("apparentTemperature"),
    }


def persist_history(db_path, state_id, rows, source):
    conn = connect(db_path)
    try:
        with conn:
            for r in rows:
                if not isinstance(r.get("maxTemperature"), (int, float)):
                    continue
                conn.execute(
                    """INSERT INTO historical_weather (stateId, date, minTemperature, maxTemperature,
                           averageTemperature, apparentTemperature, source)
                       VALUES (?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(stateId, date) DO UPDATE SET
                           minTemperature = excluded.minTemperature, maxTemperature = excluded.maxTemperature,
                           averageTemperature = excluded.averageTemperature,
                           apparentTemperature = excluded.apparentTemperature, source = excluded.source""",
                    (state_id, r["date"], r["minTemperature"], r["maxTemperature"], r["averageTemperature"],
                     r.get("apparentTemperature"), source),
                )
    finally:
        conn.close()


def get_history(state, range_="30", start=None, end=None):
    today = today_ist()
    notes = []

    if range_ in ("7", "30"):
        n = int(range_)
        snapshot, meta = get_snapshot()
        s = snapshot["states"].get(state["code"])
        rows = [_strip(r) for r in (s["past"] if s else [])][-n:]
        if not rows:
            raise HistoryError("Historical weather unavailable.", 503)
        return _finish(state, rows, start=rows[0]["date"], end=rows[-1]["date"],
                       source="open-meteo-forecast-past",
                       source_label="Open-Meteo Forecast API (past_days, model analysis)",
                       today_forecast=s["forecast"][0] if s and s["forecast"] else None, notes=notes, meta=meta)

    err = validate_range(start, end)
    if err:
        raise HistoryError(err, 400)

    use_archive = start < add_days(today, -RECENT_LIMIT_DAYS)
    eff_end = end
    if use_archive:
        archive_max = add_days(today, -ARCHIVE_LAG_DAYS)
        if eff_end > archive_max:
            eff_end = archive_max
            notes.append(f"Archive data lags ~{ARCHIVE_LAG_DAYS} days; range ends on {eff_end}.")

    key = f"{state['code']}:{start}:{eff_end}:{use_archive}"

    def load():
        data = open_meteo.fetch_daily_range(state["latitude"], state["longitude"], start, eff_end, archive=use_archive)
        return [_strip(r) for r in open_meteo.daily_rows(data.get("daily"))]

    try:
        value, stored_at, _ = cache.wrap(key, SIX_HOURS, load)
    except open_meteo.OpenMeteoError as e:
        raise HistoryError(str(e), e.status if e.status >= 400 else 503)

    source = "open-meteo-archive" if use_archive else "open-meteo-forecast-past"
    try:
        persist_history(current_app.config["DATABASE"], state["id"], value, source)
    except Exception as e:
        log.error("[history] persist failed: %s", e)

    today_forecast = None
    try:
        snap, _m = get_snapshot()
        today_forecast = snap["states"][state["code"]]["forecast"][0]
    except Exception:
        pass  # the comparison is optional

    label = ("Open-Meteo Historical Weather API (ERA5 reanalysis)" if use_archive
             else "Open-Meteo Forecast API (recent past, model analysis)")
    return _finish(state, value, start=start, end=eff_end, source=source, source_label=label,
                   today_forecast=today_forecast, notes=notes,
                   meta={"lastUpdated": iso(stored_at), "stale": False})


def _finish(state, rows, start, end, source, source_label, today_forecast, notes, meta):
    summary = summarize(rows)
    comparison = None
    if summary and today_forecast and isinstance(today_forecast.get("maxTemperature"), (int, float)):
        tmax = round1(today_forecast["maxTemperature"])
        diff = round1(tmax - summary["meanMax"])
        word = "above" if diff >= 0 else "below"
        comparison = {
            "todayMax": tmax,
            "periodMeanMax": summary["meanMax"],
            "difference": diff,
            "text": (f"Today's forecast maximum ({_n(tmax)} °C) is {_n(abs(diff))} °C {word} the mean daily "
                     f"maximum of the selected period ({_n(summary['meanMax'])} °C)."),
            "caveat": "Comparison with the selected period only — not a long-term climate average.",
        }
    if any(r.get("averageDerived") for r in rows):
        notes.append("Average temperature shown as (max + min) / 2 where the daily mean was not provided.")
    return {
        "state": {"id": state["id"], "name": state["name"], "code": state["code"], "repLocation": state["repLocation"]},
        "range": {"start": start, "end": end},
        "source": source,
        "sourceLabel": source_label,
        "rows": rows,
        "summary": summary,
        "comparison": comparison,
        "notes": notes,
        "meta": meta,
    }


def _n(x):
    return str(int(x)) if float(x).is_integer() else str(x)
