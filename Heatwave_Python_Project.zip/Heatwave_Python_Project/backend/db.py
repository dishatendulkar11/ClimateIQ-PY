"""SQLite database access.

* One connection per request (stored on Flask's `g`), closed automatically.
* init_db() creates every table from schema.sql and seeds the reference
  tables (states, safety_tips, emergency_contacts). It is safe to run again.
"""

import os
import sqlite3

from flask import current_app, g, has_app_context

from .data.reference import EMERGENCY_CONTACTS, SAFETY_TIPS
from .data.states import STATES

SCHEMA_PATH = os.path.join(os.path.dirname(__file__), "schema.sql")


def connect(path):
    conn = sqlite3.connect(path, timeout=15, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def get_db():
    """The connection for the current request."""
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def query(sql, params=(), one=False):
    cur = get_db().execute(sql, params)
    rows = cur.fetchall()
    cur.close()
    if one:
        return dict(rows[0]) if rows else None
    return [dict(r) for r in rows]


def execute(sql, params=()):
    """Run an INSERT/UPDATE/DELETE and commit. Returns the cursor."""
    db = get_db()
    cur = db.execute(sql, params)
    db.commit()
    return cur


def init_db(path):
    """Create tables and seed reference data."""
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    conn = connect(path)
    try:
        conn.execute("PRAGMA journal_mode = WAL")  # lets reads and writes overlap
        with open(SCHEMA_PATH, encoding="utf-8") as f:
            conn.executescript(f.read())

        # states: upsert (keeps ids stable, so favourites/history stay valid)
        for s in STATES:
            conn.execute(
                """INSERT INTO states (name, code, type, latitude, longitude, repLocation)
                   VALUES (:name, :code, :type, :latitude, :longitude, :repLocation)
                   ON CONFLICT(code) DO UPDATE SET name = excluded.name, type = excluded.type,
                     latitude = excluded.latitude, longitude = excluded.longitude,
                     repLocation = excluded.repLocation""",
                s,
            )
        # safety tips + emergency contacts: replace
        conn.execute("DELETE FROM safety_tips")
        conn.executemany(
            "INSERT INTO safety_tips (riskLevel, category, title, description) VALUES (:riskLevel, :category, :title, :description)",
            SAFETY_TIPS,
        )
        conn.execute("DELETE FROM emergency_contacts")
        conn.executemany(
            "INSERT INTO emergency_contacts (name, phone, description, source) VALUES (:name, :phone, :description, :source)",
            EMERGENCY_CONTACTS,
        )
        conn.commit()
    finally:
        conn.close()


def standalone_connection():
    """A connection usable outside a request (background persistence)."""
    if has_app_context():
        return connect(current_app.config["DATABASE"])
    raise RuntimeError("standalone_connection() needs an application context")
