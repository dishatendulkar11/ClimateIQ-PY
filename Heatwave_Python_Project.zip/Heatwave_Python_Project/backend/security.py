"""Request helpers shared by the route files: logged-in user lookup,
the login_required decorator, a small rate limiter and an API error type."""

import threading
import time
from collections import defaultdict, deque
from functools import wraps

from flask import g, jsonify, request


class ApiError(Exception):
    """Raise this in a route to send {"error": message} with an HTTP status."""

    def __init__(self, message, status=400, fields=None):
        super().__init__(message)
        self.status = status
        self.fields = fields


def login_required(fn):
    """Blocks the request with 401 unless a valid session cookie was sent."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not g.get("user"):
            return jsonify({"error": "Please log in to continue."}), 401
        return fn(*args, **kwargs)
    return wrapper


class RateLimiter:
    """Sliding-window limiter: at most `limit` requests per `window` seconds per client IP."""

    def __init__(self, limit, window, message="Too many requests. Please slow down."):
        self.limit, self.window, self.message = limit, window, message
        self.hits = defaultdict(deque)
        self.lock = threading.Lock()

    def allow(self, key):
        now = time.time()
        with self.lock:
            q = self.hits[key]
            while q and q[0] <= now - self.window:
                q.popleft()
            if len(q) >= self.limit:
                return False
            q.append(now)
            return True

    def reset(self):
        with self.lock:
            self.hits.clear()

    def __call__(self, fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if not self.allow(request.remote_addr or "local"):
                return jsonify({"error": self.message}), 429
            return fn(*args, **kwargs)
        return wrapper


api_limiter = RateLimiter(300, 60)
auth_limiter = RateLimiter(20, 15 * 60, "Too many attempts. Please wait a few minutes and try again.")
