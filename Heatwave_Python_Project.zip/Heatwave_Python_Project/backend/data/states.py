"""All 28 States and 8 Union Territories of India.

latitude/longitude = a REPRESENTATIVE city (usually the capital) used for
coordinate-based Open-Meteo requests. Weather shown for a state is the
weather at this point, not a state-wide average - the UI labels it as such.
Where the capital is shared (Chandigarh) a large city of the state is used.
"""

STATES = [
    # ---- States ----
    {"name": "Andhra Pradesh", "code": "AP", "type": "STATE", "repLocation": "Amaravati", "latitude": 16.5150, "longitude": 80.5160},
    {"name": "Arunachal Pradesh", "code": "AR", "type": "STATE", "repLocation": "Itanagar", "latitude": 27.0844, "longitude": 93.6053},
    {"name": "Assam", "code": "AS", "type": "STATE", "repLocation": "Dispur (Guwahati)", "latitude": 26.1433, "longitude": 91.7898},
    {"name": "Bihar", "code": "BR", "type": "STATE", "repLocation": "Patna", "latitude": 25.5941, "longitude": 85.1376},
    {"name": "Chhattisgarh", "code": "CG", "type": "STATE", "repLocation": "Raipur", "latitude": 21.2514, "longitude": 81.6296},
    {"name": "Goa", "code": "GA", "type": "STATE", "repLocation": "Panaji", "latitude": 15.4909, "longitude": 73.8278},
    {"name": "Gujarat", "code": "GJ", "type": "STATE", "repLocation": "Gandhinagar", "latitude": 23.2156, "longitude": 72.6369},
    {"name": "Haryana", "code": "HR", "type": "STATE", "repLocation": "Rohtak", "latitude": 28.8955, "longitude": 76.6066},
    {"name": "Himachal Pradesh", "code": "HP", "type": "STATE", "repLocation": "Shimla", "latitude": 31.1048, "longitude": 77.1734},
    {"name": "Jharkhand", "code": "JH", "type": "STATE", "repLocation": "Ranchi", "latitude": 23.3441, "longitude": 85.3096},
    {"name": "Karnataka", "code": "KA", "type": "STATE", "repLocation": "Bengaluru", "latitude": 12.9716, "longitude": 77.5946},
    {"name": "Kerala", "code": "KL", "type": "STATE", "repLocation": "Thiruvananthapuram", "latitude": 8.5241, "longitude": 76.9366},
    {"name": "Madhya Pradesh", "code": "MP", "type": "STATE", "repLocation": "Bhopal", "latitude": 23.2599, "longitude": 77.4126},
    {"name": "Maharashtra", "code": "MH", "type": "STATE", "repLocation": "Mumbai", "latitude": 19.0760, "longitude": 72.8777},
    {"name": "Manipur", "code": "MN", "type": "STATE", "repLocation": "Imphal", "latitude": 24.8170, "longitude": 93.9368},
    {"name": "Meghalaya", "code": "ML", "type": "STATE", "repLocation": "Shillong", "latitude": 25.5788, "longitude": 91.8933},
    {"name": "Mizoram", "code": "MZ", "type": "STATE", "repLocation": "Aizawl", "latitude": 23.7271, "longitude": 92.7176},
    {"name": "Nagaland", "code": "NL", "type": "STATE", "repLocation": "Kohima", "latitude": 25.6751, "longitude": 94.1086},
    {"name": "Odisha", "code": "OD", "type": "STATE", "repLocation": "Bhubaneswar", "latitude": 20.2961, "longitude": 85.8245},
    {"name": "Punjab", "code": "PB", "type": "STATE", "repLocation": "Ludhiana", "latitude": 30.9010, "longitude": 75.8573},
    {"name": "Rajasthan", "code": "RJ", "type": "STATE", "repLocation": "Jaipur", "latitude": 26.9124, "longitude": 75.7873},
    {"name": "Sikkim", "code": "SK", "type": "STATE", "repLocation": "Gangtok", "latitude": 27.3389, "longitude": 88.6065},
    {"name": "Tamil Nadu", "code": "TN", "type": "STATE", "repLocation": "Chennai", "latitude": 13.0827, "longitude": 80.2707},
    {"name": "Telangana", "code": "TG", "type": "STATE", "repLocation": "Hyderabad", "latitude": 17.3850, "longitude": 78.4867},
    {"name": "Tripura", "code": "TR", "type": "STATE", "repLocation": "Agartala", "latitude": 23.8315, "longitude": 91.2868},
    {"name": "Uttar Pradesh", "code": "UP", "type": "STATE", "repLocation": "Lucknow", "latitude": 26.8467, "longitude": 80.9462},
    {"name": "Uttarakhand", "code": "UK", "type": "STATE", "repLocation": "Dehradun", "latitude": 30.3165, "longitude": 78.0322},
    {"name": "West Bengal", "code": "WB", "type": "STATE", "repLocation": "Kolkata", "latitude": 22.5726, "longitude": 88.3639},
    # ---- Union Territories ----
    {"name": "Andaman and Nicobar Islands", "code": "AN", "type": "UNION_TERRITORY", "repLocation": "Sri Vijaya Puram (Port Blair)", "latitude": 11.6234, "longitude": 92.7265},
    {"name": "Chandigarh", "code": "CH", "type": "UNION_TERRITORY", "repLocation": "Chandigarh", "latitude": 30.7333, "longitude": 76.7794},
    {"name": "Dadra and Nagar Haveli and Daman and Diu", "code": "DH", "type": "UNION_TERRITORY", "repLocation": "Daman", "latitude": 20.3974, "longitude": 72.8328},
    {"name": "Delhi", "code": "DL", "type": "UNION_TERRITORY", "repLocation": "New Delhi", "latitude": 28.6139, "longitude": 77.2090},
    {"name": "Jammu and Kashmir", "code": "JK", "type": "UNION_TERRITORY", "repLocation": "Srinagar", "latitude": 34.0837, "longitude": 74.7973},
    {"name": "Ladakh", "code": "LA", "type": "UNION_TERRITORY", "repLocation": "Leh", "latitude": 34.1526, "longitude": 77.5771},
    {"name": "Lakshadweep", "code": "LD", "type": "UNION_TERRITORY", "repLocation": "Kavaratti", "latitude": 10.5669, "longitude": 72.6420},
    {"name": "Puducherry", "code": "PY", "type": "UNION_TERRITORY", "repLocation": "Puducherry", "latitude": 11.9416, "longitude": 79.8083},
]
