"""Reference data seeded into the database: safety tips, emergency contacts
and WMO weather-code descriptions.

Safety guidance is adapted from India's National Disaster Management
Authority (NDMA) heat-wave Do's & Don'ts and the National Action Plan on
Heat Related Illnesses (MoHFW / NCDC).
riskLevel = the LOWEST risk level at which a tip is shown; higher levels
include every tip from lower levels.
"""

SAFETY_TIPS = [
    # VERY_LOW - general good practice
    {"riskLevel": "VERY_LOW", "category": "Hydration", "title": "Keep drinking water through the day", "description": "Drink water regularly even when you are not thirsty. Carry a water bottle when you travel."},
    {"riskLevel": "VERY_LOW", "category": "Prevention", "title": "Check the forecast before planning outdoor work", "description": "Look at tomorrow's maximum and feels-like temperature before scheduling travel, sport or outdoor labour."},
    # LOW
    {"riskLevel": "LOW", "category": "Clothing", "title": "Wear light, loose cotton clothes", "description": "Lightweight, light-coloured, loose and porous cotton clothing helps the body lose heat."},
    {"riskLevel": "LOW", "category": "Outdoor", "title": "Protect your head outdoors", "description": "Use an umbrella, hat, cap, towel or other traditional head covering when in direct sunlight."},
    # MEDIUM
    {"riskLevel": "MEDIUM", "category": "Hydration", "title": "Use ORS and home-made drinks", "description": "Use ORS and home-made drinks such as lassi, torani (rice water), lemon water and buttermilk to rehydrate."},
    {"riskLevel": "MEDIUM", "category": "Outdoor", "title": "Avoid going out between 12 noon and 3 pm", "description": "Stay out of direct sun during the hottest hours where possible."},
    {"riskLevel": "MEDIUM", "category": "Home", "title": "Keep your home cool", "description": "Use curtains, shutters or sunshades and open windows at night. Use fans and damp cloths, and take cool baths."},
    # ELEVATED
    {"riskLevel": "ELEVATED", "category": "Vulnerable people", "title": "Check on vulnerable people", "description": "Infants, young children, pregnant women, elderly people, outdoor workers and people with heart disease or high blood pressure are at higher risk. Check on them regularly."},
    {"riskLevel": "ELEVATED", "category": "Outdoor", "title": "Avoid strenuous activity in the heat", "description": "Avoid heavy physical work outdoors when the temperature is high. Outdoor workers should take frequent rest breaks in shade."},
    {"riskLevel": "ELEVATED", "category": "Hydration", "title": "Avoid alcohol, tea, coffee and carbonated soft drinks", "description": "These can dehydrate the body. Avoid high-protein and stale food during hot spells."},
    # HIGH
    {"riskLevel": "HIGH", "category": "Warning signs", "title": "Know the signs of heat exhaustion", "description": "Heavy sweating, weakness, dizziness, headache, nausea, muscle cramps and a fast pulse. Move to a cool place, loosen clothing, sip water or ORS."},
    {"riskLevel": "HIGH", "category": "Vulnerable people", "title": "Never leave children or pets in parked vehicles", "description": "Temperatures inside a closed vehicle rise to dangerous levels within minutes."},
    {"riskLevel": "HIGH", "category": "Prevention", "title": "Cook during cooler hours", "description": "Avoid cooking during peak hours; keep doors and windows of the cooking area open for ventilation."},
    # EXTREME
    {"riskLevel": "EXTREME", "category": "Warning signs", "title": "Heatstroke is a medical emergency", "description": "Very high body temperature, hot dry skin, confusion, slurred speech, seizures or unconsciousness. Call 108 / 112 immediately."},
    {"riskLevel": "EXTREME", "category": "First aid", "title": "Cool the person while waiting for help", "description": "Move them to shade, remove excess clothing, sponge or spray with cool water and fan them. Do not give fluids to an unconscious person."},
    {"riskLevel": "EXTREME", "category": "Outdoor", "title": "Postpone non-essential outdoor activity", "description": "Reschedule travel, sport and outdoor events to early morning or evening, or postpone them."},
]

# National emergency numbers in India. Only well-established, publicly
# documented numbers are included. 102/108 and 1070/1077 are run state-wise.
EMERGENCY_CONTACTS = [
    {"name": "National Emergency Number (ERSS)", "phone": "112", "description": "Single pan-India emergency number for police, fire and ambulance (Emergency Response Support System).", "source": "Ministry of Home Affairs — ERSS (112.gov.in)"},
    {"name": "Ambulance (Emergency Medical Services)", "phone": "108", "description": "Free emergency ambulance service operated in most states/UTs. Use for heatstroke and other medical emergencies.", "source": "State EMS (108) services under the National Health Mission"},
    {"name": "Ambulance (Patient Transport)", "phone": "102", "description": "Ambulance service in many states, focused on pregnant women and infants.", "source": "National Health Mission (state-run, availability varies)"},
    {"name": "Police", "phone": "100", "description": "Police control room. In many states calls are now routed through 112.", "source": "State police / MHA"},
    {"name": "Fire", "phone": "101", "description": "Fire and rescue services.", "source": "State fire services"},
    {"name": "State Disaster Control Room", "phone": "1070", "description": "State Emergency Operation Centre for disasters, including heat waves.", "source": "NDMA / State Disaster Management Authorities"},
    {"name": "District Disaster Control Room", "phone": "1077", "description": "District Emergency Operation Centre.", "source": "NDMA / District Disaster Management Authorities"},
]

# WMO weather interpretation codes, as documented by Open-Meteo
# https://open-meteo.com/en/docs ("WMO Weather interpretation codes")
WEATHER_CODES = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Depositing rime fog",
    51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle",
    56: "Light freezing drizzle", 57: "Dense freezing drizzle",
    61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
    66: "Light freezing rain", 67: "Heavy freezing rain",
    71: "Slight snowfall", 73: "Moderate snowfall", 75: "Heavy snowfall", 77: "Snow grains",
    80: "Slight rain showers", 81: "Moderate rain showers", 82: "Violent rain showers",
    85: "Slight snow showers", 86: "Heavy snow showers",
    95: "Thunderstorm", 96: "Thunderstorm with slight hail", 99: "Thunderstorm with heavy hail",
}


def describe_weather_code(code):
    """Turn a WMO code (e.g. 61) into text (e.g. 'Slight rain')."""
    if code is None:
        return "Unknown"
    return WEATHER_CODES.get(code, f"Code {code}")
