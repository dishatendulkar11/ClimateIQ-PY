-- Climate Intelligence & Heatwave Early Warning System for India
-- Relational schema (SQLite). Created automatically by backend/db.py on first run.
-- Timestamps are stored as ISO-8601 text in UTC (e.g. 2026-10-21T16:30:00.000Z),
-- calendar dates as YYYY-MM-DD.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    fullName      VARCHAR(100) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    passwordHash  VARCHAR(100) NOT NULL,
    phoneNumber   VARCHAR(15),
    city          VARCHAR(80)  NOT NULL,
    state         VARCHAR(80)  NOT NULL,
    createdAt     TEXT NOT NULL,
    updatedAt     TEXT NOT NULL
);

-- Server-side sessions: the browser only holds an opaque random token in an
-- HTTP-only cookie; we store its SHA-256 hash here.
CREATE TABLE IF NOT EXISTS sessions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    tokenHash  CHAR(64) NOT NULL UNIQUE,
    userId     INTEGER  NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expiresAt  TEXT NOT NULL,
    createdAt  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(userId);

CREATE TABLE IF NOT EXISTS states (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         VARCHAR(80) NOT NULL UNIQUE,
    code         VARCHAR(4)  NOT NULL UNIQUE,
    type         TEXT NOT NULL CHECK (type IN ('STATE', 'UNION_TERRITORY')),
    latitude     REAL NOT NULL,
    longitude    REAL NOT NULL,
    repLocation  VARCHAR(80) NOT NULL          -- representative city used for weather
);

CREATE TABLE IF NOT EXISTS weather_records (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    stateId              INTEGER NOT NULL REFERENCES states(id) ON DELETE CASCADE,
    temperature          REAL NOT NULL,
    apparentTemperature  REAL NOT NULL,
    humidity             REAL NOT NULL,
    windSpeed            REAL,
    weatherCode          INTEGER NOT NULL,
    weatherCondition     VARCHAR(60) NOT NULL,
    observedAt           TEXT NOT NULL,       -- time reported by Open-Meteo
    recordedAt           TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_weather_state_recorded ON weather_records(stateId, recordedAt);

CREATE TABLE IF NOT EXISTS forecasts (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    stateId              INTEGER NOT NULL REFERENCES states(id) ON DELETE CASCADE,
    date                 TEXT NOT NULL,
    minTemperature       REAL NOT NULL,
    maxTemperature       REAL NOT NULL,
    apparentTemperature  REAL NOT NULL,       -- daily max apparent temperature
    humidity             REAL,                -- daily mean relative humidity
    precipitation        REAL,
    windSpeed            REAL,
    weatherCode          INTEGER NOT NULL,
    weatherCondition     VARCHAR(60) NOT NULL,
    createdAt            TEXT NOT NULL,
    updatedAt            TEXT NOT NULL,
    UNIQUE (stateId, date)
);
CREATE INDEX IF NOT EXISTS idx_forecasts_date ON forecasts(date);

CREATE TABLE IF NOT EXISTS historical_weather (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    stateId              INTEGER NOT NULL REFERENCES states(id) ON DELETE CASCADE,
    date                 TEXT NOT NULL,
    minTemperature       REAL NOT NULL,
    maxTemperature       REAL NOT NULL,
    averageTemperature   REAL NOT NULL,
    apparentTemperature  REAL,
    source               VARCHAR(40) NOT NULL,
    UNIQUE (stateId, date)
);

CREATE TABLE IF NOT EXISTS heat_risk (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    stateId       INTEGER NOT NULL REFERENCES states(id) ON DELETE CASCADE,
    forDate       TEXT NOT NULL,
    score         INTEGER NOT NULL CHECK (score BETWEEN 0 AND 100),
    riskLevel     TEXT NOT NULL CHECK (riskLevel IN ('VERY_LOW','LOW','MEDIUM','ELEVATED','HIGH','EXTREME')),
    factors       TEXT NOT NULL,              -- JSON array of contributing factors
    calculatedAt  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_heatrisk_state_calc ON heat_risk(stateId, calculatedAt);

CREATE TABLE IF NOT EXISTS user_favorites (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    userId     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    stateId    INTEGER NOT NULL REFERENCES states(id) ON DELETE CASCADE,
    createdAt  TEXT NOT NULL,
    UNIQUE (userId, stateId)
);

CREATE TABLE IF NOT EXISTS user_search_history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    userId      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    stateId     INTEGER NOT NULL REFERENCES states(id) ON DELETE CASCADE,
    method      VARCHAR(12) NOT NULL CHECK (method IN ('dropdown', 'search', 'map')),
    searchedAt  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_search_user_time ON user_search_history(userId, searchedAt);

CREATE TABLE IF NOT EXISTS safety_tips (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    riskLevel    TEXT NOT NULL CHECK (riskLevel IN ('VERY_LOW','LOW','MEDIUM','ELEVATED','HIGH','EXTREME')),
    category     VARCHAR(40)  NOT NULL,
    title        VARCHAR(120) NOT NULL,
    description  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tips_level ON safety_tips(riskLevel);

CREATE TABLE IF NOT EXISTS emergency_contacts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         VARCHAR(100) NOT NULL,
    phone        VARCHAR(20)  NOT NULL,
    description  TEXT NOT NULL,
    source       VARCHAR(160) NOT NULL
);
