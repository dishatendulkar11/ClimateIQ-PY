"""/api/auth/* - register, login, logout, profile, password, delete account."""

from flask import Blueprint, current_app, g, jsonify, request

from ..db import execute
from ..security import auth_limiter, login_required
from ..services import auth_service as auth

bp = Blueprint("auth", __name__, url_prefix="/api/auth")


def _body():
    return request.get_json(silent=True) or {}


def _set_cookie(resp, token, expires):
    resp.set_cookie(auth.COOKIE_NAME, token, httponly=True, samesite="Lax", expires=expires, path="/",
                    secure=current_app.config["SECURE_COOKIES"])


def _clear_cookie(resp):
    resp.delete_cookie(auth.COOKIE_NAME, path="/", httponly=True, samesite="Lax",
                       secure=current_app.config["SECURE_COOKIES"])


# CREATE - register a new user
@bp.post("/register")
@auth_limiter
def register():
    user, errors = auth.register(_body())
    if errors:
        return jsonify({"error": "Please fix the highlighted fields.", "fields": errors}), 400
    token, expires = auth.create_session(user["id"])
    resp = jsonify({"user": auth.public_user(user)})
    _set_cookie(resp, token, expires)
    return resp, 201


@bp.post("/login")
@auth_limiter
def login():
    body = _body()
    email, password = body.get("email"), body.get("password")
    if not email or not password:
        return jsonify({"error": "Email and password are required."}), 400
    user = auth.login(email, password)
    if not user:
        return jsonify({"error": "Invalid email or password."}), 401
    if g.get("session_token"):
        auth.destroy_session(g.session_token)
    token, expires = auth.create_session(user["id"])
    resp = jsonify({"user": auth.public_user(user)})
    _set_cookie(resp, token, expires)
    return resp


# DELETE - the session row is removed, so the token is useless even if copied
@bp.post("/logout")
def logout():
    auth.destroy_session(g.get("session_token"))
    resp = jsonify({"ok": True})
    _clear_cookie(resp)
    return resp


# READ
@bp.get("/me")
def me():
    return jsonify({"user": auth.public_user(g.user) if g.get("user") else None})


# UPDATE - profile
@bp.put("/profile")
@login_required
def profile():
    user, errors = auth.update_profile(g.user["id"], _body())
    if errors:
        return jsonify({"error": "Please fix the highlighted fields.", "fields": errors}), 400
    return jsonify({"user": auth.public_user(user)})


@bp.put("/password")
@login_required
@auth_limiter
def password():
    b = _body()
    errors = auth.change_password(g.user["id"], b.get("currentPassword"), b.get("newPassword"), b.get("confirmPassword"))
    if errors:
        return jsonify({"error": "Could not change password.", "fields": errors}), 400
    # sign out the user's other sessions
    execute("DELETE FROM sessions WHERE userId = ? AND tokenHash != ?",
            (g.user["id"], auth.sha256(g.session_token)))
    return jsonify({"ok": True})


# DELETE - account (cascades to sessions, favourites, history via foreign keys)
@bp.delete("/account")
@login_required
def delete_account():
    if not auth.login(g.user["email"], _body().get("password")):
        return jsonify({"error": "Password is incorrect."}), 400
    execute("DELETE FROM users WHERE id = ?", (g.user["id"],))
    resp = jsonify({"ok": True})
    _clear_cookie(resp)
    return resp
