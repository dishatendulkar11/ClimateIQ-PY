"""States, weather, forecast, history, heat-risk and map endpoints."""

import os

from flask import Blueprint, current_app, jsonify, request

from ..db import query
from ..security import ApiError
from ..services.geo_service import load_geo
from ..services.heat_risk import BANDS, DISCLAIMER, level_at_least
from ..services.history_service import get_history
from ..services.state_service import get_state, list_states, public_state
from ..services.weather_service import WeatherUnavailable, get_snapshot

bp = Blueprint("weather", __name__, url_prefix="/api")

DATA_SOURCE = {
    "name": "Open-Meteo",
    "url": "https://open-meteo.com/",
    "license": "CC BY 4.0",
    "note": "State representative weather — measured at one representative location per state/UT, not a state-wide average.",
}


def _state_or_404(id_or_code):
    st = get_state(id_or_code)
    if not st:
        raise ApiError("State not found.", 404)
    return st


def _state_snapshot(st):
    snapshot, meta = get_snapshot()
    s = snapshot["states"].get(st["code"])
    if not s:
        raise WeatherUnavailable("Weather data temporarily unavailable.")
    return s, {**meta, "today": snapshot["today"]}


def _tips():
    return query("SELECT id, riskLevel, category, title, description FROM safety_tips ORDER BY id ASC")


@bp.get("/states")
def states():
    return jsonify({"states": [public_state(s) for s in list_states()]})


@bp.get("/states/<id_>")
def state(id_):
    return jsonify({"state": public_state(_state_or_404(id_))})


@bp.get("/states/<id_>/weather")
def weather(id_):
    st = _state_or_404(id_)
    s, meta = _state_snapshot(st)
    return jsonify({"state": public_state(st), "current": s["current"],
                    "today": s["forecast"][0] if s["forecast"] else None,
                    "risk": s["risk"], "source": DATA_SOURCE, "meta": meta})


@bp.get("/states/<id_>/forecast")
def forecast(id_):
    st = _state_or_404(id_)
    s, meta = _state_snapshot(st)
    return jsonify({"state": public_state(st), "forecast": s["forecast"], "source": DATA_SOURCE, "meta": meta})


@bp.get("/states/<id_>/history")
def history(id_):
    st = _state_or_404(id_)
    range_ = request.args.get("range", "30")
    if range_ not in ("7", "30", "custom"):
        raise ApiError("range must be 7, 30 or custom", 400)
    return jsonify(get_history(st, range_, request.args.get("start"), request.args.get("end")))


@bp.get("/heatwave/<id_>")
def heatwave(id_):
    st = _state_or_404(id_)
    s, meta = _state_snapshot(st)
    level = s["risk"]["riskLevel"] if s["risk"] else "VERY_LOW"
    tips = [t for t in _tips() if level_at_least(level, t["riskLevel"])]
    return jsonify({
        "state": public_state(st),
        "today": s["risk"],
        "days": [{"date": d["date"], "maxTemperature": d["maxTemperature"],
                  "apparentTemperature": d.get("apparentTemperature"), "risk": d.get("risk")} for d in s["forecast"]],
        "bands": BANDS,
        "disclaimer": DISCLAIMER,
        "recommendations": list(reversed(tips[-6:])),
        "source": DATA_SOURCE,
        "meta": meta,
    })


# All states, all 7 forecast days - one payload so the map's day slider is instant
@bp.get("/map/risk")
def map_risk():
    snapshot, meta = get_snapshot()
    out = []
    for s in snapshot["states"].values():
        c = s["current"]
        out.append({
            "id": s["stateId"], "code": s["code"], "name": s["name"], "repLocation": s["repLocation"],
            "latitude": s["latitude"], "longitude": s["longitude"],
            "current": {"temperature": c["temperature"], "apparentTemperature": c["apparentTemperature"],
                        "humidity": c["humidity"], "weatherCondition": c["weatherCondition"]} if c else None,
            "days": [{"date": d["date"], "tmax": d["maxTemperature"], "tmin": d["minTemperature"],
                      "apparent": d.get("apparentTemperature"), "condition": d.get("weatherCondition"),
                      "score": d["risk"]["score"] if d.get("risk") else None,
                      "level": d["risk"]["riskLevel"] if d.get("risk") else None} for d in s["forecast"]],
        })
    dates = [d["date"] for d in out[0]["days"]] if out else []
    return jsonify({"dates": dates, "states": out, "bands": BANDS, "disclaimer": DISCLAIMER,
                    "source": DATA_SOURCE, "meta": {**meta, "today": snapshot["today"]}})


@bp.get("/map/geo")
def map_geo():
    path = os.path.join(current_app.static_folder, "data", "india_states.geojson")
    geo = load_geo(path, list_states())
    if not geo:
        raise ApiError("India boundary file missing (static/data/india_states.geojson).", 404)
    resp = jsonify(geo)
    resp.headers["Cache-Control"] = "public, max-age=86400"
    return resp


@bp.get("/safety")
def safety():
    level = str(request.args.get("level", "")).upper()
    tips = _tips()
    if level and any(b["level"] == level for b in BANDS):
        tips = [t for t in tips if level_at_least(level, t["riskLevel"])]
    return jsonify({"tips": tips, "bands": BANDS})


@bp.get("/emergency")
def emergency():
    return jsonify({"contacts": query("SELECT * FROM emergency_contacts ORDER BY id ASC")})
