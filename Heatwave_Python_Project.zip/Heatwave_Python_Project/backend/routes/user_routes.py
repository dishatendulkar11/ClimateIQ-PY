"""User-owned records: favourites + search history (full CRUD) and live DB row counts."""

import time

from flask import Blueprint, g, jsonify, request

from ..db import execute, query
from ..security import login_required
from ..services.state_service import get_state, public_state
from ..services.utils import iso_now, parse_iso

bp = Blueprint("user", __name__, url_prefix="/api")


def _id_param(v):
    try:
        n = int(v)
    except (TypeError, ValueError):
        return None
    return n if n > 0 else None


def _state_by_id(state_id):
    return public_state(get_state(state_id))


# ---------- favourites ----------
@bp.get("/favorites")
@login_required
def favorites():
    rows = query("SELECT * FROM user_favorites WHERE userId = ? ORDER BY createdAt DESC, id DESC", (g.user["id"],))
    return jsonify({"favorites": [{"id": r["id"], "createdAt": r["createdAt"], "state": _state_by_id(r["stateId"])}
                                  for r in rows]})


@bp.post("/favorites")
@login_required
def add_favorite():
    st = get_state((request.get_json(silent=True) or {}).get("stateId"))
    if not st:
        return jsonify({"error": "Unknown state."}), 400
    # INSERT ... ON CONFLICT DO NOTHING behaves like Prisma's upsert with an empty update
    execute("INSERT INTO user_favorites (userId, stateId, createdAt) VALUES (?, ?, ?) ON CONFLICT(userId, stateId) DO NOTHING",
            (g.user["id"], st["id"], iso_now()))
    fav = query("SELECT * FROM user_favorites WHERE userId = ? AND stateId = ?", (g.user["id"], st["id"]), one=True)
    return jsonify({"favorite": {"id": fav["id"], "createdAt": fav["createdAt"], "state": public_state(st)}}), 201


@bp.delete("/favorites/<id_>")
@login_required
def remove_favorite(id_):
    fid = _id_param(id_)
    if not fid:
        return jsonify({"error": "Bad id."}), 400
    # scoped to the owner so users can't delete each other's rows
    cur = execute("DELETE FROM user_favorites WHERE id = ? AND userId = ?", (fid, g.user["id"]))
    if not cur.rowcount:
        return jsonify({"error": "Favorite not found."}), 404
    return jsonify({"ok": True})


# ---------- search history ----------
@bp.get("/search-history")
@login_required
def search_history():
    try:
        limit = min(100, int(request.args.get("limit") or 50))
    except ValueError:
        limit = 50
    rows = query("SELECT * FROM user_search_history WHERE userId = ? ORDER BY searchedAt DESC, id DESC LIMIT ?",
                 (g.user["id"], limit))
    return jsonify({"history": [{"id": r["id"], "method": r["method"], "searchedAt": r["searchedAt"],
                                 "state": _state_by_id(r["stateId"])} for r in rows]})


@bp.post("/search-history")
@login_required
def add_search():
    body = request.get_json(silent=True) or {}
    st = get_state(body.get("stateId"))
    if not st:
        return jsonify({"error": "Unknown state."}), 400
    method = body.get("method") if body.get("method") in ("dropdown", "search", "map") else "dropdown"
    # skip if the same state was the very last entry within 2 minutes
    last = query("SELECT * FROM user_search_history WHERE userId = ? ORDER BY searchedAt DESC, id DESC LIMIT 1",
                 (g.user["id"],), one=True)
    if last and last["stateId"] == st["id"] and time.time() - parse_iso(last["searchedAt"]).timestamp() < 120:
        return jsonify({"entry": {"id": last["id"], "method": last["method"], "searchedAt": last["searchedAt"],
                                  "state": public_state(st)}, "deduplicated": True})
    now = iso_now()
    cur = execute("INSERT INTO user_search_history (userId, stateId, method, searchedAt) VALUES (?, ?, ?, ?)",
                  (g.user["id"], st["id"], method, now))
    return jsonify({"entry": {"id": cur.lastrowid, "method": method, "searchedAt": now, "state": public_state(st)}}), 201


@bp.delete("/search-history/<id_>")
@login_required
def remove_search(id_):
    sid = _id_param(id_)
    if not sid:
        return jsonify({"error": "Bad id."}), 400
    cur = execute("DELETE FROM user_search_history WHERE id = ? AND userId = ?", (sid, g.user["id"]))
    if not cur.rowcount:
        return jsonify({"error": "Entry not found."}), 404
    return jsonify({"ok": True})


@bp.delete("/search-history")
@login_required
def clear_searches():
    cur = execute("DELETE FROM user_search_history WHERE userId = ?", (g.user["id"],))
    return jsonify({"ok": True, "deleted": cur.rowcount})


# ---------- DBMS demo: live row counts ----------
TABLES = ["users", "sessions", "states", "weather_records", "forecasts", "historical_weather", "heat_risk",
          "user_favorites", "user_search_history", "safety_tips", "emergency_contacts"]


@bp.get("/db/stats")
@login_required
def db_stats():
    return jsonify({"tables": {t: query(f"SELECT COUNT(*) AS n FROM {t}", one=True)["n"] for t in TABLES}})
