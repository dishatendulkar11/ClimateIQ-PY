"""Python backend for the Climate Intelligence & Heatwave Early Warning System (Flask + SQLite)."""
