@echo off
REM ============================================================
REM  Climate Intelligence India - one-click start for Windows
REM  Double-click this file. First run installs everything.
REM ============================================================
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo.
    echo  Python was not found. Install Python 3.10 or newer from https://www.python.org/downloads/
    echo  IMPORTANT: tick "Add python.exe to PATH" during installation, then run this file again.
    echo.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment .venv ...
    python -m venv .venv
    if errorlevel 1 goto :fail
)

echo Installing / checking packages ...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt
if errorlevel 1 goto :fail

echo.
echo  Starting server...  The website will open at http://127.0.0.1:8000/
echo  Keep this window open while you use the site. Press CTRL+C here to stop.
echo.
start "" /b cmd /c "ping -n 4 127.0.0.1 >nul & start http://127.0.0.1:8000/"
".venv\Scripts\python.exe" app.py
pause
exit /b 0

:fail
echo.
echo  Something went wrong (see the message above). Check your internet connection and try again.
pause
exit /b 1
