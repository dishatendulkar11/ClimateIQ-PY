"""Unit tests for the pure logic (no database / network needed).
These are the same checks as the original project's tests/logic.test.js, in Python."""

from backend.data.states import STATES
from backend.services.geo_service import match_code, tag_features
from backend.services.heat_risk import compute_heat_risk, level_for_score, risk_series
from backend.services.history_service import summarize
from backend.services.open_meteo import daily_rows
from backend.services.weather_service import build_state_snapshot

OM_SAMPLE = {
    "latitude": 26.9, "longitude": 75.8, "elevation": 431,
    "current": {"time": "2026-10-02T19:00", "temperature_2m": 31.2, "relative_humidity_2m": 55,
                "apparent_temperature": 34.1, "weather_code": 1, "wind_speed_10m": 9.4},
    "daily": {
        "time": ["2026-09-30", "2026-10-01", "2026-10-02", "2026-10-03"],
        "weather_code": [0, 2, 1, 95],
        "temperature_2m_max": [36.1, 37.0, 38.2, 41.0],
        "temperature_2m_min": [24.0, 25.1, 25.9, 27.2],
        "apparent_temperature_max": [38, 39.5, 40.1, 44.2],
        "precipitation_sum": [0, 0, 0, 3.2],
        "wind_speed_10m_max": [12, 14, 10, 20],
    },
}


def test_levels_cover_0_to_100_without_gaps():
    for s in range(101):
        assert level_for_score(s)["level"]
    assert level_for_score(0)["level"] == "VERY_LOW"
    assert level_for_score(50)["level"] == "ELEVATED"
    assert level_for_score(100)["level"] == "EXTREME"


def test_mild_day_scores_very_low_and_extreme_heat_scores_extreme():
    mild = compute_heat_risk({"date": "d", "maxTemperature": 26, "apparentTemperature": 27, "humidity": 60}, [], [])
    assert mild["score"] == 0
    assert mild["riskLevel"] == "VERY_LOW"
    hot = {"date": "d", "maxTemperature": 46.5, "apparentTemperature": 50, "humidity": 30}
    r = compute_heat_risk(hot, [hot, hot, hot], [{"maxTemperature": 40}] * 30)
    assert r["score"] >= 80
    assert r["riskLevel"] == "EXTREME"
    assert len(r["factors"]) == 5
    assert len(r["notes"]) == 1


def test_known_values_are_scored_exactly():
    # Tmax 38 -> 20 pts, feels 42 -> 12.5, RH 60 -> 5, 0 hot days, +2 vs 36 -> 3.3  => 40.8 -> 41
    day = {"date": "d", "maxTemperature": 38, "apparentTemperature": 42, "humidity": 60}
    r = compute_heat_risk(day, [day], [{"maxTemperature": 36}] * 30)
    pts = {f["key"]: f["points"] for f in r["factors"]}
    assert pts == {"tmax": 20.0, "apparent": 12.5, "humidity": 5.0, "persistence": 0, "anomaly": 3.3}
    assert r["score"] == 41 and r["riskLevel"] == "MEDIUM"


def test_missing_temperature_gives_no_risk():
    assert compute_heat_risk({"maxTemperature": None}) is None


def test_daily_rows_derives_mean_when_api_omits_it():
    rows = daily_rows(OM_SAMPLE["daily"])
    assert len(rows) == 4
    assert rows[0]["averageTemperature"] == 30.1
    assert rows[0]["averageDerived"] is True


def test_build_state_snapshot_splits_past_vs_forecast_and_scores_forecast():
    snap = build_state_snapshot({"id": 1, "code": "RJ", "name": "Rajasthan", "repLocation": "Jaipur",
                                 "latitude": 26.9, "longitude": 75.8}, OM_SAMPLE, "2026-10-02")
    assert [d["date"] for d in snap["past"]] == ["2026-09-30", "2026-10-01"]
    assert [d["date"] for d in snap["forecast"]] == ["2026-10-02", "2026-10-03"]
    assert snap["current"]["weatherCondition"] == "Mainly clear"
    assert snap["forecast"][1]["weatherCondition"] == "Thunderstorm"
    assert isinstance(snap["risk"]["score"], int)


def test_risk_series_uses_3_day_persistence_window():
    f = [{"date": f"d{i}", "maxTemperature": t, "apparentTemperature": t} for i, t in enumerate([40, 41, 42, 30])]
    r = risk_series([], f, None)
    persistence = lambda x: next(k for k in x["factors"] if k["key"] == "persistence")["points"]  # noqa: E731
    assert persistence(r[0]) == 15
    assert persistence(r[3]) == 0


def test_boundary_name_matching_handles_common_dataset_spellings():
    assert match_code("Arunanchal Pradesh") == "AR"
    assert match_code("Orissa") == "OD"
    assert match_code("NCT of Delhi") == "DL"
    assert match_code("Andaman & Nicobar Island") == "AN"
    assert match_code("Dadara & Nagar Havelli") == "DH"
    assert match_code("Atlantis") is None
    assert match_code("Dadra and Nagar Haveli and Daman and Diu") == "DH"
    assert match_code("Jammu & Kashmir") == "JK"
    assert match_code("Telangana") == "TG"
    assert match_code("Pondicherry") == "PY"
    for s in STATES:
        assert match_code(s["name"]) == s["code"], s["name"]


def test_tag_features_detects_name_property_and_tags_features():
    fc = {"type": "FeatureCollection", "features": [
        {"type": "Feature", "properties": {"ST_NM": "Maharashtra"},
         "geometry": {"type": "Polygon", "coordinates": [[[72.123456, 19.123456], [73, 19], [73, 20], [72.123456, 19.123456]]]}},
    ]}
    geojson, _unmatched, name_prop = tag_features(fc, [{"id": 7, "code": "MH", "name": "Maharashtra"}])
    assert name_prop == "ST_NM"
    assert geojson["features"][0]["properties"]["state_id"] == 7
    assert geojson["features"][0]["geometry"]["coordinates"][0][0] == [72.1235, 19.1235]


def test_36_states_with_unique_codes_and_coordinates_inside_india():
    assert len(STATES) == 36
    assert len({s["code"] for s in STATES}) == 36
    for s in STATES:
        assert 6 < s["latitude"] < 37.5 and 68 < s["longitude"] < 98, s["name"]


def test_summarize_history():
    rows = [{"date": "a", "maxTemperature": 40, "minTemperature": 25, "averageTemperature": 32},
            {"date": "b", "maxTemperature": 42, "minTemperature": 24, "averageTemperature": 33}]
    s = summarize(rows)
    assert s["meanMax"] == 41 and s["hottestDay"] == {"date": "b", "value": 42}
    assert s["coolestNight"]["date"] == "b" and s["daysAbove40"] == 2
