"""Endpoint tests using Flask's test client (Open-Meteo is faked in conftest.py)."""

from backend.db import connect
from backend.services.utils import add_days, today_ist


def test_homepage_and_assets_are_served(client):
    r = client.get("/")
    assert r.status_code == 200 and b"ClimateIntel" in r.data or b"Climate" in r.data
    assert client.get("/css/styles.css").status_code == 200
    assert client.get("/js/app.js").status_code == 200
    assert "Content-Security-Policy" in r.headers


def test_unknown_api_route_is_json_404(client):
    r = client.get("/api/does-not-exist")
    assert r.status_code == 404 and r.get_json() == {"error": "Not found"}


def test_states_and_lookup_by_code_or_id(client):
    states = client.get("/api/states").get_json()["states"]
    assert len(states) == 36
    mh = client.get("/api/states/mh").get_json()["state"]
    assert mh["name"] == "Maharashtra"
    assert client.get(f"/api/states/{mh['id']}").get_json()["state"]["code"] == "MH"
    assert client.get("/api/states/ZZ").status_code == 404


def test_weather_forecast_heatwave_and_map(client, fake_open_meteo):
    w = client.get("/api/states/RJ/weather").get_json()
    assert w["current"]["temperature"] == 35.5
    assert w["risk"]["riskLevel"] in {"VERY_LOW", "LOW", "MEDIUM", "ELEVATED", "HIGH", "EXTREME"}
    assert w["meta"]["stale"] is False and w["meta"]["today"] == today_ist()
    f = client.get("/api/states/RJ/forecast").get_json()
    assert len(f["forecast"]) == 7 and f["forecast"][0]["date"] == today_ist()
    hw = client.get("/api/heatwave/RJ").get_json()
    assert len(hw["days"]) == 7 and len(hw["bands"]) == 6 and hw["recommendations"]
    m = client.get("/api/map/risk").get_json()
    assert len(m["states"]) == 36 and len(m["dates"]) == 7
    # all of this came from ONE bulk Open-Meteo request (cached afterwards)
    assert fake_open_meteo["bulk"] == 1


def test_refresh_is_saved_to_the_database(app, client):
    client.get("/api/map/risk")
    conn = connect(app.config["DATABASE"])
    counts = {t: conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
              for t in ("weather_records", "forecasts", "historical_weather", "heat_risk")}
    conn.close()
    assert counts == {"weather_records": 36, "forecasts": 36 * 7, "historical_weather": 36 * 30, "heat_risk": 36}


def test_database_fallback_when_open_meteo_is_down(client, fake_open_meteo):
    from backend.services import weather_service
    client.get("/api/map/risk")              # live fetch -> saved to the DB
    weather_service.cache.clear()            # forget the in-memory copy
    fake_open_meteo["fail"] = True           # Open-Meteo now "down"
    r = client.get("/api/states/MH/weather").get_json()
    assert r["meta"]["stale"] is True and r["meta"]["source"] == "database"
    assert "Showing cached data" in r["meta"]["message"]


def test_no_data_at_all_gives_503(client, fake_open_meteo):
    fake_open_meteo["fail"] = True
    r = client.get("/api/states/MH/weather")
    assert r.status_code == 503 and r.get_json()["error"] == "Weather data temporarily unavailable."


def test_history_ranges_and_validation(client):
    r7 = client.get("/api/states/KA/history?range=7").get_json()
    assert len(r7["rows"]) == 7 and r7["summary"]["days"] == 7 and r7["comparison"]
    r30 = client.get("/api/states/KA/history?range=30").get_json()
    assert len(r30["rows"]) == 30
    start, end = add_days(today_ist(), -400), add_days(today_ist(), -380)
    custom = client.get(f"/api/states/KA/history?range=custom&start={start}&end={end}").get_json()
    assert custom["source"] == "open-meteo-archive" and len(custom["rows"]) == 21
    bad = client.get(f"/api/states/KA/history?range=custom&start={end}&end={start}")
    assert bad.status_code == 400 and "before" in bad.get_json()["error"]
    future = client.get(f"/api/states/KA/history?range=custom&start={start}&end={today_ist()}")
    assert future.status_code == 400
    assert client.get("/api/states/KA/history?range=5").status_code == 400


def test_safety_filter_and_emergency_contacts(client):
    all_tips = client.get("/api/safety").get_json()["tips"]
    low = client.get("/api/safety?level=LOW").get_json()["tips"]
    assert len(all_tips) == 16 and {t["riskLevel"] for t in low} == {"VERY_LOW", "LOW"}
    contacts = client.get("/api/emergency").get_json()["contacts"]
    assert contacts[0]["phone"] == "112"


def test_register_validation(client):
    r = client.post("/api/auth/register", json={"fullName": "A", "email": "bad", "password": "short",
                                               "confirmPassword": "x", "city": "", "state": ""})
    assert r.status_code == 400
    assert set(r.get_json()["fields"]) >= {"fullName", "email", "password", "confirmPassword", "city", "state"}


def test_auth_flow_login_logout_and_duplicate_email(client, user):
    assert client.get("/api/auth/me").get_json()["user"]["email"] == "student@example.com"
    dup = client.post("/api/auth/register", json={
        "fullName": "Other", "email": "STUDENT@example.com", "password": "Passw0rdX", "confirmPassword": "Passw0rdX",
        "city": "Pune", "state": "Maharashtra"})
    assert dup.status_code == 400 and "already exists" in dup.get_json()["fields"]["email"]
    assert client.post("/api/auth/logout").get_json() == {"ok": True}
    assert client.get("/api/auth/me").get_json()["user"] is None
    assert client.post("/api/auth/login", json={"email": "student@example.com", "password": "wrong"}).status_code == 401
    ok = client.post("/api/auth/login", json={"email": "student@example.com", "password": "Passw0rdX"})
    assert ok.status_code == 200 and ok.get_json()["user"]["fullName"] == "Test Student"


def test_profile_update_and_password_change(client, user):
    r = client.put("/api/auth/profile", json={"fullName": "New Name", "city": "Pune", "phoneNumber": "12"})
    assert r.status_code == 400 and "phoneNumber" in r.get_json()["fields"]
    r = client.put("/api/auth/profile", json={"fullName": "New Name", "city": "Pune"})
    assert r.get_json()["user"]["fullName"] == "New Name"
    bad = client.put("/api/auth/password", json={"currentPassword": "nope", "newPassword": "Passw0rdY",
                                                 "confirmPassword": "Passw0rdY"})
    assert bad.status_code == 400
    good = client.put("/api/auth/password", json={"currentPassword": "Passw0rdX", "newPassword": "Passw0rdY",
                                                  "confirmPassword": "Passw0rdY"})
    assert good.get_json() == {"ok": True}


def test_favorites_crud(client, user):
    assert client.get("/api/favorites").get_json() == {"favorites": []}
    fav = client.post("/api/favorites", json={"stateId": "GJ"}).get_json()["favorite"]
    client.post("/api/favorites", json={"stateId": "GJ"})  # duplicate is ignored (UNIQUE userId, stateId)
    favs = client.get("/api/favorites").get_json()["favorites"]
    assert len(favs) == 1 and favs[0]["state"]["code"] == "GJ"
    assert client.delete(f"/api/favorites/{fav['id']}").get_json() == {"ok": True}
    assert client.delete(f"/api/favorites/{fav['id']}").status_code == 404
    assert client.post("/api/favorites", json={"stateId": "XX"}).status_code == 400


def test_search_history_crud_and_dedup(client, user):
    a = client.post("/api/search-history", json={"stateId": "DL", "method": "map"})
    assert a.status_code == 201
    again = client.post("/api/search-history", json={"stateId": "DL", "method": "map"}).get_json()
    assert again["deduplicated"] is True
    client.post("/api/search-history", json={"stateId": "KL", "method": "search"})
    hist = client.get("/api/search-history").get_json()["history"]
    assert [h["state"]["code"] for h in hist] == ["KL", "DL"]
    assert client.delete(f"/api/search-history/{hist[0]['id']}").get_json() == {"ok": True}
    assert client.delete("/api/search-history").get_json()["deleted"] == 1


def test_db_stats_and_account_delete_cascades(client, user):
    client.post("/api/favorites", json={"stateId": "GJ"})
    stats = client.get("/api/db/stats").get_json()["tables"]
    assert stats["users"] == 1 and stats["states"] == 36 and stats["user_favorites"] == 1
    assert client.delete("/api/auth/account", json={"password": "wrong"}).status_code == 400
    assert client.delete("/api/auth/account", json={"password": "Passw0rdX"}).get_json() == {"ok": True}
    client.post("/api/auth/login", json={"email": "x@example.com", "password": "Passw0rdX"})
    assert client.get("/api/favorites").status_code == 401


def test_protected_routes_need_login(client):
    for url in ("/api/favorites", "/api/search-history", "/api/db/stats"):
        r = client.get(url)
        assert r.status_code == 401 and r.get_json()["error"] == "Please log in to continue."


def test_map_geo_boundaries_are_tagged(client):
    geo = client.get("/api/map/geo").get_json()
    codes = {f["properties"]["state_code"] for f in geo["features"]}
    assert geo["type"] == "FeatureCollection" and len(codes - {None}) == 36
