"""Shared test fixtures. Open-Meteo is replaced by a fake so tests run offline."""

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app  # noqa: E402
from backend.security import api_limiter, auth_limiter  # noqa: E402
from backend.services import geo_service, history_service, open_meteo, state_service, weather_service  # noqa: E402
from backend.services.utils import add_days, today_ist  # noqa: E402


def fake_location(i, today):
    """A plausible Open-Meteo response for one location (30 past days + 7 forecast days)."""
    days = [add_days(today, d) for d in range(-30, 7)]
    n = len(days)
    tmax = [36.0 + (i % 5) + (d % 3) * 0.5 for d in range(n)]
    return {
        "latitude": 20.0, "longitude": 78.0, "elevation": 100,
        "current": {"time": f"{today}T14:00", "temperature_2m": 35.5, "relative_humidity_2m": 45,
                    "apparent_temperature": 38.2, "weather_code": 1, "wind_speed_10m": 11.0},
        "daily": {
            "time": days,
            "weather_code": [1] * n,
            "temperature_2m_max": tmax,
            "temperature_2m_min": [t - 10 for t in tmax],
            "temperature_2m_mean": [t - 5 for t in tmax],
            "apparent_temperature_max": [t + 2 for t in tmax],
            "precipitation_sum": [0.0] * n,
            "wind_speed_10m_max": [14.0] * n,
            "relative_humidity_2m_mean": [40] * n,
        },
    }


@pytest.fixture
def fake_open_meteo(monkeypatch):
    calls = {"bulk": 0, "range": 0, "fail": False}

    def bulk(locations, past_days=30, forecast_days=7):
        calls["bulk"] += 1
        if calls["fail"]:
            raise open_meteo.OpenMeteoError("Open-Meteo unreachable: test", 503)
        today = today_ist()
        return [fake_location(i, today) for i in range(len(locations))]

    def daily_range(lat, lon, start, end, archive=False):
        calls["range"] += 1
        from datetime import date, timedelta
        d0, d1 = date.fromisoformat(start), date.fromisoformat(end)
        days = [(d0 + timedelta(days=k)).isoformat() for k in range((d1 - d0).days + 1)]
        return {"daily": {"time": days, "temperature_2m_max": [30.0] * len(days),
                          "temperature_2m_min": [20.0] * len(days), "apparent_temperature_max": [32.0] * len(days)}}

    monkeypatch.setattr(open_meteo, "fetch_forecast_bulk", bulk)
    monkeypatch.setattr(open_meteo, "fetch_daily_range", daily_range)
    return calls


@pytest.fixture
def app(tmp_path, fake_open_meteo):
    weather_service.cache.clear()
    history_service.cache.clear()
    state_service.reset_cache()
    geo_service._memo = None
    api_limiter.reset()
    auth_limiter.reset()
    application = create_app({"DATABASE": str(tmp_path / "test.db"), "TESTING": True, "PERSIST_ASYNC": False})
    yield application
    weather_service.cache.clear()
    state_service.reset_cache()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def user(client):
    """A registered + logged-in test user."""
    r = client.post("/api/auth/register", json={
        "fullName": "Test Student", "email": "student@example.com", "password": "Passw0rdX",
        "confirmPassword": "Passw0rdX", "phoneNumber": "9876543210", "city": "Mumbai", "state": "Maharashtra"})
    assert r.status_code == 201, r.get_json()
    return r.get_json()["user"]
