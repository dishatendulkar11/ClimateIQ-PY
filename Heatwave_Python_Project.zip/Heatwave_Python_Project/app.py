"""Climate Intelligence & Heatwave Early Warning System for India - Python version.

Run it:   python app.py      then open  http://127.0.0.1:8000/

What this file does
-------------------
* creates the Flask application (create_app)
* creates/seeds the SQLite database on first start (backend/db.py)
* registers the three groups of API routes (backend/routes/*.py)
* serves the original website (static/index.html + css/js) unchanged
* adds security headers, rate limiting and JSON error handling
"""

import logging
import os
import threading

from flask import Flask, g, jsonify, request, send_from_directory

from backend import db
from backend.routes import auth_routes, user_routes, weather_routes
from backend.security import ApiError, api_limiter
from backend.services import auth_service
from backend.services.history_service import HistoryError
from backend.services.open_meteo import OpenMeteoError
from backend.services.weather_service import WeatherUnavailable

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def load_env_file(path=os.path.join(BASE_DIR, ".env")):
    """Read KEY=VALUE lines from an optional .env file into os.environ."""
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


# Content-Security-Policy: allows MapLibre / Chart.js from their CDNs,
# CARTO basemap tiles and Google Fonts - the same rules as the original site.
CSP = "; ".join([
    "default-src 'self'",
    "script-src 'self' https://unpkg.com https://cdn.jsdelivr.net",
    "style-src 'self' 'unsafe-inline' https://unpkg.com https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com data:",
    "img-src 'self' data: blob: https://basemaps.cartocdn.com https://*.basemaps.cartocdn.com https://*.cartocdn.com",
    "connect-src 'self' https://basemaps.cartocdn.com https://*.basemaps.cartocdn.com https://*.cartocdn.com https://unpkg.com",
    "worker-src 'self' blob:",
    "child-src 'self' blob:",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'self'",
    "object-src 'none'",
])


def create_app(test_config=None):
    load_env_file()
    app = Flask(__name__, static_folder=os.path.join(BASE_DIR, "static"), static_url_path="")
    app.config.update(
        DATABASE=os.environ.get("DATABASE_PATH", os.path.join(BASE_DIR, "database", "heatwave.db")),
        WEATHER_CACHE_SECONDS=int(float(os.environ.get("WEATHER_CACHE_MINUTES", "30")) * 60),
        SECURE_COOKIES=os.environ.get("SECURE_COOKIES", "0") == "1",
        PERSIST_ASYNC=True,
        MAX_CONTENT_LENGTH=20 * 1024,  # JSON bodies are tiny
        JSON_SORT_KEYS=False,
    )
    if test_config:
        app.config.update(test_config)
    app.json.sort_keys = False
    app.json.ensure_ascii = False

    db.init_db(app.config["DATABASE"])
    app.teardown_appcontext(db.close_db)

    app.register_blueprint(auth_routes.bp)
    app.register_blueprint(weather_routes.bp)
    app.register_blueprint(user_routes.bp)

    # ---------- every /api request: rate limit + find the logged-in user ----------
    @app.before_request
    def before_api():
        if not request.path.startswith("/api"):
            return None
        if not api_limiter.allow(request.remote_addr or "local"):
            return jsonify({"error": api_limiter.message}), 429
        g.session_token = request.cookies.get(auth_service.COOKIE_NAME)
        g.user = auth_service.user_from_token(g.session_token) if g.session_token else None
        return None

    @app.after_request
    def headers(resp):
        resp.headers["Content-Security-Policy"] = CSP
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "SAMEORIGIN"
        resp.headers["Referrer-Policy"] = "no-referrer"
        if request.path.startswith("/api") and "Cache-Control" not in resp.headers:
            resp.headers["Cache-Control"] = "no-store"
        elif not request.path.startswith("/api"):
            resp.headers["Cache-Control"] = "no-cache"  # always pick up edited CSS/JS during the demo
        return resp

    @app.get("/api/health")
    def health():
        try:
            db.query("SELECT 1 AS ok")
            return jsonify({"ok": True, "db": "up"})
        except Exception:
            return jsonify({"ok": False, "db": "down"}), 500

    # ---------- errors: always JSON for /api, never leak stack traces ----------
    @app.errorhandler(ApiError)
    def api_error(e):
        body = {"error": str(e)}
        if e.fields:
            body["fields"] = e.fields
        return jsonify(body), e.status

    @app.errorhandler(WeatherUnavailable)
    def weather_unavailable(e):
        return jsonify({"error": str(e)}), 503

    @app.errorhandler(HistoryError)
    def history_error(e):
        return jsonify({"error": str(e)}), e.status

    @app.errorhandler(OpenMeteoError)
    def open_meteo_error(e):
        return jsonify({"error": str(e)}), 503

    @app.errorhandler(404)
    def not_found(e):
        if request.path.startswith("/api"):
            return jsonify({"error": "Not found"}), 404
        # single-page app with hash routing: unknown paths get the main page
        return send_from_directory(app.static_folder, "index.html")

    @app.errorhandler(405)
    def method_not_allowed(e):
        return jsonify({"error": "Method not allowed"}), 405

    @app.errorhandler(413)
    def too_large(e):
        return jsonify({"error": "Request body too large."}), 413

    @app.errorhandler(Exception)
    def server_error(e):
        if hasattr(e, "code") and isinstance(getattr(e, "code"), int) and e.code < 500:
            return jsonify({"error": getattr(e, "description", "Request error")}), e.code
        app.logger.exception(e)
        return jsonify({"error": "Something went wrong on the server."}), 500

    # ---------- the website ----------
    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    # periodically delete expired sessions (every 6 hours)
    def purge_loop():
        import time
        while True:
            time.sleep(6 * 3600)
            try:
                with app.app_context():
                    auth_service.purge_expired_sessions()
            except Exception:
                pass

    if not app.config.get("TESTING"):
        threading.Thread(target=purge_loop, daemon=True).start()

    return app


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    load_env_file()
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8000"))
    application = create_app()
    print(f"\n  Climate Intelligence India (Python / Flask) -> http://{host}:{port}/\n"
          f"  Press CTRL+C to stop the server.\n")
    application.run(host=host, port=port, debug=False, threaded=True)
