The SQLite database file (heatwave.db) is created here automatically the first time you run app.py.
