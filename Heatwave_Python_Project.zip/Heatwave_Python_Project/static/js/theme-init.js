// Apply the saved theme before first paint (per-browser convenience only).
try { var t = localStorage.getItem('ci-theme'); if (t === 'light' || t === 'dark') document.documentElement.dataset.theme = t; } catch (e) { /* storage unavailable */ }
