import { api } from '../api.js';
import { store } from '../store.js';
import { esc, fmtTC, riskChip, loading, updatedStamp } from '../ui.js';
import { createIndiaMap } from '../heatmap.js';
import { onSelectedState } from './common.js';

export default {
  title: 'India Map',
  auth: true,
  async render(view, { onTheme }) {
    view.innerHTML = `
      <div class="page-head">
        <div>
          <div class="eyebrow">India heat map</div>
          <h1>Heat across India</h1>
          <p class="muted">Real state/UT boundaries coloured by the heat-risk estimate or forecast maximum temperature. Drag the slider (or press ▶) to watch the next 7 days. Click a state to select it everywhere.</p>
        </div>
      </div>
      <div id="map" style="margin-bottom:16px"></div>
      <div class="grid g-2">
        <section class="card"><div class="card-head"><h2>Selected state</h2></div><div id="sel">${loading('Loading…')}</div></section>
        <section class="card"><div class="card-head"><h2>Top 10 hottest today</h2><span id="stamp"></span></div><div id="top">${loading('Loading weather data…')}</div></section>
      </div>`;

    const map = createIndiaMap(view.querySelector('#map'), { selectedCode: store.selected?.code, onSelect: (c) => store.select(c, 'map') });
    const offTheme = onTheme(() => map.retheme());

    let data = null;
    try {
      data = await api.mapRisk();
      const rows = data.states.filter((s) => typeof s.days[0]?.tmax === 'number').sort((a, b) => b.days[0].tmax - a.days[0].tmax).slice(0, 10);
      view.querySelector('#stamp').innerHTML = updatedStamp(data.meta);
      view.querySelector('#top').innerHTML = `<div class="table-wrap"><table><thead><tr><th>#</th><th>State / UT</th><th>Max</th><th>Feels like</th><th>Risk</th></tr></thead><tbody>
        ${rows.map((s, i) => `<tr><td>${i + 1}</td><td><button class="link" style="background:none;border:0;color:inherit;font:inherit;font-weight:600;cursor:pointer;padding:0" data-code="${s.code}">${esc(s.name)}</button></td><td>${fmtTC(s.days[0].tmax)}</td><td>${fmtTC(s.days[0].apparent)}</td><td>${riskChip(s.days[0].level)} <span class="muted small">${s.days[0].score ?? ''}</span></td></tr>`).join('')}
      </tbody></table></div>`;
    } catch (e) {
      view.querySelector('#top').innerHTML = `<div class="alert alert-error">${esc(e.message)}</div>`;
    }

    view.querySelector('#top').addEventListener('click', (e) => {
      const b = e.target.closest('[data-code]');
      if (b) store.select(b.dataset.code, 'map');
    });

    const off = onSelectedState((st) => {
      if (!st) return;
      map.setSelected(st.code);
      const s = data && data.states.find((x) => x.code === st.code);
      const d = s && s.days[0];
      view.querySelector('#sel').innerHTML = s ? `
        <h3>${esc(s.name)}</h3>
        <p class="muted small">Representative location: ${esc(s.repLocation)} (${s.latitude.toFixed(2)}°N, ${s.longitude.toFixed(2)}°E)</p>
        <dl class="kv">
          <div><dt>Now</dt><dd>${fmtTC(s.current?.temperature)}</dd></div>
          <div><dt>Max today</dt><dd>${fmtTC(d?.tmax)}</dd></div>
          <div><dt>Min today</dt><dd>${fmtTC(d?.tmin)}</dd></div>
          <div><dt>Risk</dt><dd>${riskChip(d?.level)}</dd></div>
        </dl>
        <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap"><a class="btn btn-secondary btn-sm" href="#/dashboard">Dashboard</a><a class="btn btn-secondary btn-sm" href="#/forecast">Forecast</a><a class="btn btn-secondary btn-sm" href="#/heat-risk">Heat risk</a></div>`
        : `<p>${esc(st.name)}</p><div class="alert alert-warn">Weather data temporarily unavailable.</div>`;
    });

    return () => { off(); offTheme(); map.destroy(); };
  },
};
