import { api } from '../api.js';
import { store } from '../store.js';
import { esc, loading, errorBox, toast } from '../ui.js';

export default {
  title: 'Search History',
  auth: true,
  async render(view, { navigate }) {
    view.innerHTML = `
      <div class="page-head">
        <div><div class="eyebrow">Activity</div><h1>Search history</h1>
        <p class="muted">Every state you select (dropdown, search or map) is stored in <code>user_search_history</code>.</p></div>
        <button class="btn btn-danger" id="clear">Clear all</button>
      </div>
      <section class="card"><div id="list">${loading('Loading…')}</div></section>`;
    const list = view.querySelector('#list');

    async function load() {
      try {
        const { history } = await api.searchHistory();
        list.innerHTML = history.length ? `<div class="table-wrap"><table>
          <thead><tr><th>State / UT</th><th>Selected via</th><th>When</th><th></th></tr></thead>
          <tbody>${history.map((r) => `<tr>
            <td><button class="link" style="background:none;border:0;color:inherit;font:inherit;font-weight:600;cursor:pointer;padding:0" data-open="${r.state.code}">${esc(r.state.name)}</button></td>
            <td><span class="badge">${esc(r.method)}</span></td>
            <td>${esc(new Date(r.searchedAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }))}</td>
            <td style="text-align:right"><button class="btn btn-danger btn-sm" data-del="${r.id}">Delete</button></td>
          </tr>`).join('')}</tbody></table></div>` : '<div class="empty">No searches yet. Select a state from the dropdown, search box or map.</div>';
      } catch (e) { list.innerHTML = errorBox(e.message); }
    }

    list.addEventListener('click', async (e) => {
      const del = e.target.closest('[data-del]');
      const open = e.target.closest('[data-open]');
      if (del) {
        del.disabled = true;
        try { await api.removeSearch(del.dataset.del); load(); } catch (err) { toast(err.message, 'error'); del.disabled = false; }
      } else if (open) {
        store.select(open.dataset.open, 'search');
        navigate('/dashboard');
      }
    });
    view.querySelector('#clear').addEventListener('click', async () => {
      // eslint-disable-next-line no-alert
      if (!window.confirm('Delete all of your search history?')) return;
      try { const r = await api.clearSearches(); toast(`Deleted ${r.deleted} entries.`); load(); } catch (err) { toast(err.message, 'error'); }
    });
    load();
  },
};
