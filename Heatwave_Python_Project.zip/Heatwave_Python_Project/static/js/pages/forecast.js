import { api } from '../api.js';
import { loading, errorBox, updatedStamp, shortDate, dayName, metaBadges } from '../ui.js';
import { lineChart, barChart, COLORS } from '../charts.js';
import { dayStrip, forecastTable, stateTitle, onSelectedState } from './common.js';

export default {
  title: 'Forecast',
  auth: true,
  async render(view) {
    view.innerHTML = `
      <div class="page-head">
        <div>
          <div class="eyebrow">7-day forecast</div>
          <h1>Forecast</h1>
          <p class="muted" id="stTitle"></p>
        </div>
        <span id="stamp"></span>
      </div>
      <section class="card" style="margin-bottom:16px"><div id="badges" style="margin-bottom:10px"></div><div id="days">${loading('Fetching forecast…')}</div></section>
      <section class="card" style="margin-bottom:16px"><div class="card-head"><h2>Temperature trend</h2></div><div class="chart-box tall"><canvas id="line"></canvas></div></section>
      <div class="grid g-2" style="margin-bottom:16px">
        <section class="card"><div class="card-head"><h2>Maximum temperature</h2></div><div class="chart-box"><canvas id="maxBar"></canvas></div></section>
        <section class="card"><div class="card-head"><h2>Minimum temperature</h2></div><div class="chart-box"><canvas id="minBar"></canvas></div></section>
      </div>
      <section class="card"><div class="card-head"><h2>Daily details</h2><span class="stamp">Source: Open-Meteo Forecast API</span></div><div id="table"></div></section>`;
    const $ = (id) => view.querySelector(`#${id}`);

    return onSelectedState(async (st, isCurrent) => {
      if (!st) return;
      $('stTitle').innerHTML = stateTitle();
      $('days').innerHTML = loading('Fetching forecast…');
      try {
        const r = await api.forecast(st.id);
        if (!isCurrent()) return;
        const d = r.forecast;
        $('stamp').innerHTML = updatedStamp(r.meta);
        $('badges').innerHTML = metaBadges(r.meta, r.source);
        $('days').innerHTML = dayStrip(d, r.meta.today);
        $('table').innerHTML = forecastTable(d);
        const labels = d.map((x) => `${dayName(x.date)} ${shortDate(x.date)}`);
        lineChart($('line'), {
          labels,
          series: [
            { label: 'Max', data: d.map((x) => x.maxTemperature), color: COLORS.max },
            { label: 'Feels like (max)', data: d.map((x) => x.apparentTemperature), color: COLORS.apparent, dash: true },
            { label: 'Min', data: d.map((x) => x.minTemperature), color: COLORS.min },
          ],
        });
        barChart($('maxBar'), { labels, series: [{ label: 'Max temperature', data: d.map((x) => x.maxTemperature), color: COLORS.max }] });
        barChart($('minBar'), { labels, series: [{ label: 'Min temperature', data: d.map((x) => x.minTemperature), color: COLORS.min }] });
      } catch (e) {
        if (!isCurrent()) return;
        $('days').innerHTML = errorBox(e.message || 'Weather data temporarily unavailable.');
        $('table').innerHTML = '';
      }
    });
  },
};
