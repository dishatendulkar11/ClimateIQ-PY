import { api } from '../api.js';
import { store } from '../store.js';
import { esc, setBusy, pwToggle, fieldErrors } from '../ui.js';

export default {
  title: 'Login',
  guestOnly: true,
  async render(view, { navigate }) {
    view.innerHTML = `
      <div class="auth">
        <div class="card">
          <div class="eyebrow">Welcome back</div>
          <h1 style="font-size:1.8rem">Log in</h1>
          <p class="muted">Access your dashboard, favourites and search history.</p>
          <div id="msg"></div>
          <form id="f" novalidate>
            <label class="field"><span>Email</span><input name="email" type="email" autocomplete="email" required /><span class="err"></span></label>
            <label class="field"><span>Password</span>
              <div class="pw-wrap"><input name="password" type="password" autocomplete="current-password" required /><button type="button" class="pw-toggle" aria-pressed="false">Show</button></div>
              <span class="err"></span></label>
            <button class="btn btn-primary" style="width:100%" type="submit">Log in</button>
          </form>
          <p class="muted small" style="margin-top:14px">No account yet? <a href="#/register">Register</a></p>
        </div>
      </div>`;
    const form = view.querySelector('#f');
    const msg = view.querySelector('#msg');
    pwToggle(form);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = form.email.value.trim();
      const password = form.password.value;
      const fields = {};
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) fields.email = 'Enter a valid email address.';
      if (!password) fields.password = 'Password is required.';
      fieldErrors(form, fields);
      msg.innerHTML = '';
      if (Object.keys(fields).length) return;
      const btn = form.querySelector('[type=submit]');
      setBusy(btn, true, 'Logging in…');
      try {
        const { user } = await api.login(email, password);
        store.user = user;
        navigate('/dashboard');
      } catch (err) {
        msg.innerHTML = `<div class="alert alert-error" role="alert">${esc(err.status === 401 ? 'Invalid email or password.' : err.message || 'Unable to authenticate.')}</div>`;
        setBusy(btn, false);
      }
    });
  },
};
