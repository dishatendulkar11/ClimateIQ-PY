import { api } from '../api.js';
import { esc, loading, errorBox, riskChip, RISK } from '../ui.js';
import { stateTitle, onSelectedState } from './common.js';

export default {
  title: 'Safety',
  auth: true,
  async render(view) {
    view.innerHTML = `
      <div class="page-head">
        <div>
          <div class="eyebrow">Heat safety</div>
          <h1>Stay safe in the heat</h1>
          <p class="muted" id="stTitle"></p>
        </div>
      </div>
      <section class="card" style="margin-bottom:16px">
        <div class="card-head"><h2>Recommended for current risk</h2><div id="lvl"></div></div>
        <div id="tips">${loading('Loading…')}</div>
      </section>

      <div class="grid g-2" style="margin-bottom:16px">
        <section class="card">
          <h2>Heat exhaustion</h2>
          <p class="muted">Body is losing too much water and salt.</p>
          <p><b>Signs:</b> heavy sweating, weakness, dizziness, headache, nausea or vomiting, muscle cramps, fast weak pulse, pale cool skin.</p>
          <p><b>What to do:</b> move to a cool, shaded place; loosen clothing; sip water or ORS; apply cool wet cloths. Get medical help if symptoms worsen or last more than an hour.</p>
        </section>
        <section class="card">
          <h2>Heatstroke — emergency</h2>
          <p class="muted">The body can no longer control its temperature.</p>
          <p><b>Signs:</b> very high body temperature, hot red dry or damp skin, confusion, slurred speech, fainting, seizures.</p>
          <p><b>What to do:</b> call <a href="tel:108">108</a> / <a href="tel:112">112</a> immediately. Move the person to shade, cool them rapidly with water and fanning, and do not give fluids if they are not fully conscious.</p>
        </section>
      </div>

      <section class="card dodont" style="margin-bottom:16px">
        <div class="do"><h3>✓ Do</h3><ul>
          <li>Drink enough water even if not thirsty; carry water when travelling.</li>
          <li>Use ORS and home-made drinks: lassi, lemon water, buttermilk, torani.</li>
          <li>Wear lightweight, light-coloured, loose cotton clothes.</li>
          <li>Cover your head with a hat, cap, umbrella or cloth in the sun.</li>
          <li>Keep your home cool: curtains, shades, ventilation at night.</li>
          <li>Check on elderly people, children, pregnant women and outdoor workers.</li>
        </ul></div>
        <div class="dont"><h3>✗ Don't</h3><ul>
          <li>Go out in the sun between 12 noon and 3 pm unless necessary.</li>
          <li>Do strenuous outdoor work or exercise in peak heat.</li>
          <li>Leave children or pets in parked vehicles.</li>
          <li>Drink alcohol, tea, coffee or carbonated soft drinks to rehydrate.</li>
          <li>Eat high-protein or stale food during heat spells.</li>
          <li>Walk barefoot on hot surfaces.</li>
        </ul></div>
      </section>

      <div class="grid g-3" style="margin-bottom:16px">
        <section class="card"><h3>Hydration</h3><p class="muted small">Sip regularly through the day rather than drinking a lot at once. Dark urine is a sign you need more fluids.</p></section>
        <section class="card"><h3>Outdoor workers</h3><p class="muted small">Schedule heavy work for early morning or evening, take rest breaks in shade, and keep drinking water available on site.</p></section>
        <section class="card"><h3>Vulnerable people</h3><p class="muted small">Infants, the elderly, pregnant women and people with heart disease, high blood pressure or diabetes are at higher risk. Visit them at least twice a day during heat waves.</p></section>
      </div>

      <section class="card"><div class="card-head"><h2>All tips by risk level</h2><span class="stamp">From the safety_tips table · based on NDMA guidance</span></div><div id="all">${loading('Loading…')}</div></section>`;

    const $ = (id) => view.querySelector(`#${id}`);

    try {
      const { tips } = await api.safety();
      const order = Object.keys(RISK);
      $('all').innerHTML = `<div class="table-wrap"><table><thead><tr><th>From level</th><th>Category</th><th>Tip</th></tr></thead><tbody>
        ${tips.sort((a, b) => order.indexOf(a.riskLevel) - order.indexOf(b.riskLevel)).map((t) => `<tr><td>${riskChip(t.riskLevel)}</td><td>${esc(t.category)}</td><td style="white-space:normal"><b>${esc(t.title)}</b><div class="muted small">${esc(t.description)}</div></td></tr>`).join('')}
      </tbody></table></div>`;
    } catch (e) { $('all').innerHTML = errorBox(e.message); }

    return onSelectedState(async (st, isCurrent) => {
      if (!st) return;
      $('stTitle').innerHTML = stateTitle();
      $('tips').innerHTML = loading('Loading…');
      try {
        const r = await api.heatwave(st.id);
        if (!isCurrent()) return;
        $('lvl').innerHTML = `${riskChip(r.today?.riskLevel)} <span class="muted small">score ${r.today?.score ?? '—'}</span>`;
        $('tips').innerHTML = `<div class="grid g-3">${r.recommendations.map((t) => `<div class="card flat tip" data-level="${t.riskLevel}"><div class="muted small">${esc(t.category)}</div><b>${esc(t.title)}</b><p class="muted small" style="margin:4px 0 0">${esc(t.description)}</p></div>`).join('')}</div>`;
      } catch (e) {
        if (isCurrent()) $('tips').innerHTML = errorBox(e.message);
      }
    });
  },
};
