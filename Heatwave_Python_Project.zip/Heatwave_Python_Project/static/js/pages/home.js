import { api } from '../api.js';
import { store } from '../store.js';
import { esc, fmtTC, riskChip } from '../ui.js';

export default {
  title: 'Home',
  async render(view) {
    const authed = !!store.user;
    view.innerHTML = `
      <section class="hero">
        <div>
          <div class="eyebrow">Climate Intelligence · India</div>
          <h1>See the heat <em>before it hits.</em></h1>
          <p class="lead">Live weather, a 7-day forecast, historical temperature trends and a transparent heat-risk estimate for all 28 states and 8 union territories — on a real interactive map of India.</p>
          <div class="cta">
            ${authed ? '' : '<a class="btn btn-primary" href="#/register">Register</a><a class="btn btn-secondary" href="#/login">Login</a>'}
            <a class="btn ${authed ? 'btn-primary' : 'btn-ghost'}" href="#/dashboard">Explore Dashboard →</a>
          </div>
        </div>
        <div class="hero-visual" aria-hidden="true">${heroSvg()}</div>
      </section>

      <section class="card" style="margin-bottom:18px">
        <div class="card-head"><h2>Hottest right now</h2><span class="stamp" id="hotStamp"></span></div>
        <div id="hot"><div class="state-msg"><span class="spinner"></span>Loading weather data…</div></div>
      </section>

      <section class="grid g-4" style="margin-bottom:18px">
        ${feature('🌡️', 'Weather monitoring', 'Current temperature, feels-like, humidity and wind for every state from Open-Meteo.')}
        ${feature('📅', 'Forecasting', 'Seven-day maximum, minimum and apparent temperatures with charts.')}
        ${feature('📈', 'Historical analysis', 'Last 7 days, 30 days or any custom range — clearly separated from forecasts.')}
        ${feature('🔥', 'Heat-risk awareness', 'A transparent 0–100 score with every contributing factor shown.')}
        ${feature('🗺️', 'Interactive India map', 'Real state boundaries coloured by risk, with an animated heat-wave layer.')}
        ${feature('🛡️', 'Safety preparation', 'NDMA-based heat-safety guidance that adapts to the risk level.')}
        ${feature('🚑', 'Emergency help', 'National helplines and heatstroke first aid in one place.')}
        ${feature('🗄️', 'Database-driven', 'An SQLite database (managed by the Python backend) stores users, favourites, search history and weather records.')}
      </section>

      <section class="grid g-2">
        <div class="card">
          <h2>How it works</h2>
          <ol class="steps" style="padding:0;margin:0">
            <li><div><b>Register / log in</b><div class="muted small">Secure, database-backed accounts.</div></div></li>
            <li><div><b>Pick a state</b><div class="muted small">Dropdown, search box or click it on the map.</div></div></li>
            <li><div><b>Read the data</b><div class="muted small">Current weather, forecast, history and heat risk update together.</div></div></li>
            <li><div><b>Prepare</b><div class="muted small">Follow the safety advice for that risk level.</div></div></li>
          </ol>
        </div>
        <div class="card">
          <h2>About the heat-risk estimate</h2>
          <p class="muted">Heat waves are among India's deadliest weather hazards. This project combines maximum temperature, feels-like temperature, humidity, hot-day persistence and the departure from the previous 30 days into a single 0–100 score.</p>
          <p class="muted small">It is a system-generated estimate using project-defined bands. For official warnings, follow the India Meteorological Department (IMD).</p>
        </div>
      </section>`;

    try {
      const r = await api.mapRisk();
      const rows = r.states.filter((s) => s.days[0] && typeof s.days[0].tmax === 'number')
        .sort((a, b) => b.days[0].tmax - a.days[0].tmax).slice(0, 6);
      const el = view.querySelector('#hot');
      if (!el) return;
      view.querySelector('#hotStamp').textContent = `Today's forecast max · ${r.meta.stale ? r.meta.message : 'live from Open-Meteo'}`;
      el.innerHTML = `<div class="table-wrap"><table><thead><tr><th>State / UT</th><th>Representative location</th><th>Max today</th><th>Feels like</th><th>Heat risk</th></tr></thead><tbody>
        ${rows.map((s) => `<tr><td><b>${esc(s.name)}</b></td><td class="muted">${esc(s.repLocation)}</td><td>${fmtTC(s.days[0].tmax)}</td><td>${fmtTC(s.days[0].apparent)}</td><td>${riskChip(s.days[0].level)}</td></tr>`).join('')}
      </tbody></table></div>`;
    } catch (e) {
      const el = view.querySelector('#hot');
      if (el) el.innerHTML = `<div class="alert alert-warn">Weather data temporarily unavailable. ${esc(e.message)}</div>`;
    }
  },
};

function feature(icon, title, text) {
  return `<div class="card feature"><div class="ico" aria-hidden="true">${icon}</div><h3>${title}</h3><p class="muted small" style="margin:0">${text}</p></div>`;
}

function heroSvg() {
  return `<svg viewBox="0 0 400 400" width="100%" height="100%">
    <defs>
      <radialGradient id="hg" cx="50%" cy="50%" r="50%">
        <stop offset="0" stop-color="#ffd166"/><stop offset=".35" stop-color="#f59e0b"/>
        <stop offset=".65" stop-color="#e0412f" stop-opacity=".75"/><stop offset="1" stop-color="#8b0f1a" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <circle cx="200" cy="200" r="190" fill="url(#hg)" opacity=".55"/>
    ${[150, 120, 90].map((r, i) => `<circle cx="200" cy="200" r="${r}" fill="none" stroke="${['#2e9e5b', '#f2c94c', '#e0412f'][i]}" stroke-width="2" stroke-dasharray="4 8" opacity=".7">
      <animateTransform attributeName="transform" type="rotate" from="0 200 200" to="${i % 2 ? -360 : 360} 200 200" dur="${40 + i * 15}s" repeatCount="indefinite"/></circle>`).join('')}
    <circle cx="200" cy="200" r="54" fill="#ffd166"/>
    <g transform="translate(184 120)">
      <rect x="0" y="0" width="32" height="120" rx="16" style="fill:var(--surface);stroke:var(--border)" stroke-width="3"/>
      <circle cx="16" cy="128" r="26" style="fill:#e0412f;stroke:var(--surface)" stroke-width="4"/>
      <rect x="10" y="30" width="12" height="96" rx="6" fill="#e0412f"/>
    </g>
  </svg>`;
}
