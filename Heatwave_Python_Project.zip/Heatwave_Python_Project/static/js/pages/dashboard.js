import { api } from '../api.js';
import { store } from '../store.js';
import { esc, loading, errorBox, updatedStamp, shortDate, dayName, riskChip } from '../ui.js';
import { lineChart, COLORS } from '../charts.js';
import { createIndiaMap } from '../heatmap.js';
import { currentCard, gauge, dayStrip, stateTitle, onSelectedState } from './common.js';

export default {
  title: 'Dashboard',
  auth: true,
  async render(view, { onTheme }) {
    const first = store.user.fullName.split(/\s+/)[0];
    view.innerHTML = `
      <div class="page-head">
        <div>
          <div class="eyebrow">Dashboard</div>
          <h1>Welcome, ${esc(first)}</h1>
          <p class="muted" id="stTitle"></p>
        </div>
      </div>

      <div class="grid g-dash" style="margin-bottom:16px">
        <div class="grid" style="align-content:start">
          <section class="card"><div class="card-head"><h2>Current weather</h2><span id="wStamp"></span></div><div id="current">${loading('Loading weather data…')}</div></section>
          <section class="card"><div class="card-head"><h2>Heat risk</h2><a href="#/heat-risk" class="small">Details →</a></div><div id="risk">${loading('Calculating heat risk…')}</div></section>
        </div>
        <section class="card">
          <div class="card-head"><h2>India heat map</h2><a href="#/map" class="small">Full screen →</a></div>
          <div id="map"></div>
        </section>
      </div>

      <section class="card" style="margin-bottom:16px">
        <div class="card-head"><h2>7-day forecast</h2><a href="#/forecast" class="small">Charts &amp; table →</a></div>
        <div id="days">${loading('Fetching forecast…')}</div>
      </section>

      <div class="grid g-2" style="margin-bottom:16px">
        <section class="card"><div class="card-head"><h2>Temperature — next 7 days</h2></div><div class="chart-box"><canvas id="fc"></canvas></div></section>
        <section class="card"><div class="card-head"><h2>Historical comparison</h2><a href="#/history" class="small">More →</a></div><div id="histNote" class="small"></div><div class="chart-box"><canvas id="hc"></canvas></div></section>
      </div>

      <div class="grid g-3">
        <section class="card"><div class="card-head"><h2>Safety now</h2><a href="#/safety" class="small">All tips →</a></div><div id="tips">${loading('Loading…')}</div></section>
        <section class="card"><div class="card-head"><h2>Favorite states</h2><a href="#/favorites" class="small">Manage →</a></div><div id="favs">${loading('Loading…')}</div></section>
        <section class="card"><div class="card-head"><h2>Recent searches</h2><a href="#/searches" class="small">All →</a></div><div id="recent">${loading('Loading…')}</div></section>
      </div>

      <section class="card" style="margin-top:16px">
        <div class="card-head"><h2>Database (live row counts)</h2><span class="stamp">SQLite via Python</span></div>
        <div id="db">${loading('Querying…')}</div>
      </section>`;

    const $ = (id) => view.querySelector(`#${id}`);

    const map = createIndiaMap($('map'), { compact: true, selectedCode: store.selected?.code, onSelect: (c) => store.select(c, 'map') });
    const offTheme = onTheme(() => map.retheme());

    const off = onSelectedState(async (st, isCurrent) => {
      if (!st) return;
      $('stTitle').innerHTML = stateTitle();
      map.setSelected(st.code);
      ['current', 'risk', 'days'].forEach((id) => { $(id).innerHTML = loading(id === 'days' ? 'Fetching forecast…' : 'Loading weather data…'); });

      const [w, f, hw, hist] = await Promise.allSettled([api.weather(st.id), api.forecast(st.id), api.heatwave(st.id), api.history(st.id, { range: '30' })]);
      if (!isCurrent()) return;

      if (w.status === 'fulfilled') {
        $('current').innerHTML = currentCard(w.value);
        $('wStamp').innerHTML = updatedStamp(w.value.meta);
        $('risk').innerHTML = gauge(w.value.risk);
      } else {
        $('current').innerHTML = errorBox(w.reason.message || 'Weather data temporarily unavailable.');
        $('risk').innerHTML = errorBox('Heat-risk estimate unavailable.');
      }

      if (f.status === 'fulfilled') {
        const days = f.value.forecast;
        $('days').innerHTML = dayStrip(days, f.value.meta.today);
        lineChart($('fc'), {
          labels: days.map((d) => `${dayName(d.date)} ${shortDate(d.date)}`),
          series: [
            { label: 'Max', data: days.map((d) => d.maxTemperature), color: COLORS.max },
            { label: 'Feels like (max)', data: days.map((d) => d.apparentTemperature), color: COLORS.apparent, dash: true },
            { label: 'Min', data: days.map((d) => d.minTemperature), color: COLORS.min },
          ],
        });
      } else {
        $('days').innerHTML = errorBox(f.reason.message || 'Forecast unavailable.');
      }

      if (hist.status === 'fulfilled' && hist.value.rows.length) {
        const h = hist.value;
        const todayMax = f.status === 'fulfilled' && f.value.forecast[0] ? f.value.forecast[0].maxTemperature : null;
        $('histNote').innerHTML = `<p class="muted">${esc(h.comparison ? h.comparison.text : 'Comparison unavailable.')}</p>
          <p class="stamp">${esc(h.range.start)} → ${esc(h.range.end)} · ${esc(h.sourceLabel)}. Not a long-term climate average.</p>`;
        lineChart($('hc'), {
          labels: h.rows.map((r) => shortDate(r.date)),
          series: [
            { label: 'Daily max (past 30 days)', data: h.rows.map((r) => r.maxTemperature), color: COLORS.max, fill: true },
            { label: '30-day mean max', data: h.rows.map(() => h.summary?.meanMax ?? null), color: COLORS.avg, dash: true },
            ...(typeof todayMax === 'number' ? [{ label: "Today's forecast max", data: h.rows.map(() => todayMax), color: COLORS.apparent, dash: true }] : []),
          ],
        });
      } else {
        $('histNote').innerHTML = errorBox('Historical weather unavailable.');
      }

      if (hw.status === 'fulfilled') {
        const tips = hw.value.recommendations.slice(0, 4);
        $('tips').innerHTML = `<div style="margin-bottom:8px">Level: ${riskChip(hw.value.today?.riskLevel)}</div>
          <ul class="list">${tips.map((t) => `<li style="display:block"><b>${esc(t.title)}</b><div class="muted small">${esc(t.description)}</div></li>`).join('')}</ul>`;
      } else {
        $('tips').innerHTML = errorBox('Recommendations unavailable.');
      }
    });

    // user-owned data (independent of state)
    loadFavs();
    loadRecent();
    const offRecent = store.subscribe((t) => { if (t === 'selected') setTimeout(loadRecent, 400); });
    loadDb();

    async function loadFavs() {
      try {
        const { favorites } = await api.favorites();
        $('favs').innerHTML = favorites.length
          ? `<ul class="list">${favorites.slice(0, 6).map((f) => `<li><button class="link" data-code="${f.state.code}">★ ${esc(f.state.name)}</button><span class="muted small">${f.state.type === 'STATE' ? 'State' : 'UT'}</span></li>`).join('')}</ul>`
          : '<div class="empty">No favorites yet. Use “☆ Add to Favorites” above.</div>';
      } catch (e) { $('favs').innerHTML = errorBox(e.message); }
    }
    async function loadRecent() {
      if (!view.isConnected) return;
      try {
        const { history } = await api.searchHistory();
        $('recent').innerHTML = history.length
          ? `<ul class="list">${history.slice(0, 6).map((r) => `<li><button class="link" data-code="${r.state.code}">${esc(r.state.name)}</button><span class="muted small">${esc(r.method)} · ${new Date(r.searchedAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span></li>`).join('')}</ul>`
          : '<div class="empty">Your state selections will appear here.</div>';
      } catch (e) { $('recent').innerHTML = errorBox(e.message); }
    }
    async function loadDb() {
      try {
        const { tables } = await api.dbStats();
        $('db').innerHTML = `<div class="db-tables">${Object.entries(tables).map(([k, v]) => `<div><b>${v.toLocaleString('en-IN')}</b>${esc(k)}</div>`).join('')}</div>`;
      } catch (e) { $('db').innerHTML = errorBox(e.message); }
    }

    view.addEventListener('click', (e) => {
      const b = e.target.closest('button.link[data-code]');
      if (b) store.select(b.dataset.code, 'dropdown');
    });

    return () => { off(); offRecent(); offTheme(); map.destroy(); };
  },
};

