import { api } from '../api.js';
import { store } from '../store.js';
import { esc, setBusy, pwToggle, fieldErrors } from '../ui.js';

export function stateOptions(states, selected) {
  return `<option value="">Select…</option>${states.map((s) => `<option ${s.name === selected ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}`;
}

export function validatePassword(pw) {
  const p = [];
  if (pw.length < 8) p.push('8+ characters');
  if (!/[A-Z]/.test(pw)) p.push('an uppercase letter');
  if (!/[a-z]/.test(pw)) p.push('a lowercase letter');
  if (!/\d/.test(pw)) p.push('a number');
  return p;
}

export default {
  title: 'Register',
  guestOnly: true,
  async render(view, { navigate }) {
    let states = [];
    try { states = (await api.states()).states; } catch { /* free-text fallback below */ }
    view.innerHTML = `
      <div class="auth wide">
        <div class="card">
          <div class="eyebrow">Create account</div>
          <h1 style="font-size:1.8rem">Register</h1>
          <p class="muted">Your account is stored in SQLite by the Python backend; your password is hashed with bcrypt.</p>
          <div id="msg"></div>
          <form id="f" novalidate>
            <div class="form-grid">
              <label class="field"><span>Full name *</span><input name="fullName" autocomplete="name" required /><span class="err"></span></label>
              <label class="field"><span>Email *</span><input name="email" type="email" autocomplete="email" required /><span class="err"></span></label>
              <label class="field"><span>Password *</span>
                <div class="pw-wrap"><input name="password" type="password" autocomplete="new-password" required /><button type="button" class="pw-toggle">Show</button></div>
                <span class="err"></span></label>
              <label class="field"><span>Confirm password *</span>
                <div class="pw-wrap"><input name="confirmPassword" type="password" autocomplete="new-password" required /><button type="button" class="pw-toggle">Show</button></div>
                <span class="err"></span></label>
              <label class="field"><span>Phone number (optional)</span><input name="phoneNumber" type="tel" inputmode="tel" placeholder="10-digit mobile" autocomplete="tel" /><span class="err"></span></label>
              <label class="field"><span>City *</span><input name="city" autocomplete="address-level2" required /><span class="err"></span></label>
              <label class="field"><span>State / UT *</span>
                ${states.length ? `<select name="state" required>${stateOptions(states)}</select>` : '<input name="state" required />'}
                <span class="err"></span></label>
            </div>
            <p class="muted small">Password must have at least 8 characters, an uppercase letter, a lowercase letter and a number.</p>
            <button class="btn btn-primary" style="width:100%" type="submit">Create account</button>
          </form>
          <p class="muted small" style="margin-top:14px">Already registered? <a href="#/login">Log in</a></p>
        </div>
      </div>`;
    const form = view.querySelector('#f');
    const msg = view.querySelector('#msg');
    pwToggle(form);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      Object.keys(data).forEach((k) => { if (!k.toLowerCase().includes('password')) data[k] = data[k].trim(); });
      const fields = {};
      if (data.fullName.length < 2) fields.fullName = 'Please enter your full name.';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email)) fields.email = 'Enter a valid email address.';
      const pw = validatePassword(data.password);
      if (pw.length) fields.password = `Needs ${pw.join(', ')}.`;
      if (data.password !== data.confirmPassword) fields.confirmPassword = 'Passwords do not match.';
      if (data.phoneNumber && !/^(\+91[\s-]?)?[6-9]\d{9}$/.test(data.phoneNumber.replace(/\s+/g, ''))) fields.phoneNumber = 'Enter a valid 10-digit Indian mobile number.';
      if (!data.city) fields.city = 'City is required.';
      if (!data.state) fields.state = 'State is required.';
      fieldErrors(form, fields);
      msg.innerHTML = '';
      if (Object.keys(fields).length) return;
      const btn = form.querySelector('[type=submit]');
      setBusy(btn, true, 'Creating account…');
      try {
        const { user } = await api.register(data);
        store.user = user;
        navigate('/dashboard');
      } catch (err) {
        fieldErrors(form, err.fields);
        msg.innerHTML = `<div class="alert alert-error" role="alert">${esc(err.message)}</div>`;
        setBusy(btn, false);
      }
    });
  },
};
