import { api } from '../api.js';
import { store } from '../store.js';
import { esc, setBusy, fieldErrors, pwToggle, toast } from '../ui.js';
import { stateOptions, validatePassword } from './register.js';

export default {
  title: 'Profile',
  auth: true,
  async render(view, { navigate }) {
    const u = store.user;
    const states = store.states.length ? store.states : (await api.states()).states;
    view.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">Account</div><h1>Profile</h1></div></div>
      <div class="grid g-2">
        <section class="card">
          <div class="card-head"><h2>Your details</h2><span class="stamp">Member since ${esc(new Date(u.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }))}</span></div>
          <div id="msg"></div>
          <form id="pf" novalidate>
            <label class="field"><span>Full name</span><input name="fullName" value="${esc(u.fullName)}" required /><span class="err"></span></label>
            <label class="field"><span>Email (cannot be changed)</span><input value="${esc(u.email)}" disabled /></label>
            <div class="form-grid">
              <label class="field"><span>Phone</span><input name="phoneNumber" type="tel" value="${esc(u.phoneNumber || '')}" /><span class="err"></span></label>
              <label class="field"><span>City</span><input name="city" value="${esc(u.city)}" required /><span class="err"></span></label>
            </div>
            <label class="field"><span>State / UT</span><select name="state">${stateOptions(states, u.state)}</select><span class="err"></span></label>
            <button class="btn btn-primary" type="submit">Save changes</button>
            <span class="stamp" style="margin-left:10px">Last updated ${esc(new Date(u.updatedAt).toLocaleString('en-IN'))}</span>
          </form>
        </section>
        <div class="grid" style="align-content:start">
          <section class="card">
            <h2>Change password</h2>
            <form id="pw" novalidate>
              <label class="field"><span>Current password</span><div class="pw-wrap"><input name="currentPassword" type="password" autocomplete="current-password" /><button type="button" class="pw-toggle">Show</button></div><span class="err"></span></label>
              <label class="field"><span>New password</span><div class="pw-wrap"><input name="newPassword" type="password" autocomplete="new-password" /><button type="button" class="pw-toggle">Show</button></div><span class="err"></span></label>
              <label class="field"><span>Confirm new password</span><div class="pw-wrap"><input name="confirmPassword" type="password" autocomplete="new-password" /><button type="button" class="pw-toggle">Show</button></div><span class="err"></span></label>
              <button class="btn btn-secondary" type="submit">Update password</button>
            </form>
          </section>
          <section class="card">
            <h2>Delete account</h2>
            <p class="muted small">Permanently deletes your user row. Your sessions, favorites and search history are removed automatically by <code>ON DELETE CASCADE</code> foreign keys.</p>
            <form id="del" novalidate style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
              <label class="field" style="margin:0;flex:1"><span>Confirm with password</span><input name="password" type="password" autocomplete="current-password" required /></label>
              <button class="btn btn-danger" type="submit">Delete account</button>
            </form>
          </section>
        </div>
      </div>`;

    const pf = view.querySelector('#pf');
    const pw = view.querySelector('#pw');
    pwToggle(pw);

    pf.addEventListener('submit', async (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(pf).entries());
      const fields = {};
      if ((data.fullName || '').trim().length < 2) fields.fullName = 'Please enter your full name.';
      if (!(data.city || '').trim()) fields.city = 'City is required.';
      if (data.phoneNumber && !/^(\+91[\s-]?)?[6-9]\d{9}$/.test(data.phoneNumber.replace(/\s+/g, ''))) fields.phoneNumber = 'Enter a valid 10-digit Indian mobile number.';
      if (!data.state) fields.state = 'State is required.';
      fieldErrors(pf, fields);
      if (Object.keys(fields).length) return;
      const btn = pf.querySelector('[type=submit]');
      setBusy(btn, true, 'Saving…');
      try {
        const { user } = await api.updateProfile(data);
        store.user = user;
        toast('Profile saved to the database.');
        setBusy(btn, false);
        const stamp = pf.querySelector('.stamp');
        if (stamp) stamp.textContent = `Last updated ${new Date(user.updatedAt).toLocaleString('en-IN')}`;
      } catch (err) {
        fieldErrors(pf, err.fields);
        view.querySelector('#msg').innerHTML = `<div class="alert alert-error">${esc(err.message)}</div>`;
        setBusy(btn, false);
      }
    });

    pw.addEventListener('submit', async (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(pw).entries());
      const fields = {};
      if (!data.currentPassword) fields.currentPassword = 'Required.';
      const probs = validatePassword(data.newPassword || '');
      if (probs.length) fields.newPassword = `Needs ${probs.join(', ')}.`;
      if (data.newPassword !== data.confirmPassword) fields.confirmPassword = 'Passwords do not match.';
      fieldErrors(pw, fields);
      if (Object.keys(fields).length) return;
      const btn = pw.querySelector('[type=submit]');
      setBusy(btn, true, 'Updating…');
      try {
        await api.changePassword(data);
        pw.reset();
        toast('Password updated. Other sessions were signed out.');
      } catch (err) { fieldErrors(pw, err.fields); toast(err.message, 'error'); }
      setBusy(btn, false);
    });

    view.querySelector('#del').addEventListener('submit', async (e) => {
      e.preventDefault();
      // eslint-disable-next-line no-alert
      if (!window.confirm('Delete your account permanently? This cannot be undone.')) return;
      try {
        await api.deleteAccount(e.currentTarget.password.value);
        store.user = null;
        toast('Account deleted.');
        navigate('/');
      } catch (err) { toast(err.message, 'error'); }
    });
  },
};
