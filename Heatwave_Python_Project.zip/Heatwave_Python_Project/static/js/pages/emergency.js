import { api } from '../api.js';
import { esc, loading, errorBox } from '../ui.js';

export default {
  title: 'Emergency',
  auth: true,
  async render(view) {
    view.innerHTML = `
      <div class="page-head">
        <div>
          <div class="eyebrow">Emergency</div>
          <h1>Emergency help</h1>
          <p class="muted">If someone shows signs of heatstroke, call for help first, then start cooling them.</p>
        </div>
      </div>
      <section style="margin-bottom:16px"><div id="contacts" class="grid g-3">${loading('Loading helplines…')}</div></section>

      <div class="grid g-2" style="margin-bottom:16px">
        <section class="card">
          <h2>Heatstroke first aid</h2>
          <ol style="display:grid;gap:6px;padding-left:1.2rem;margin:0">
            <li>Call <a href="tel:108">108</a> or <a href="tel:112">112</a>.</li>
            <li>Move the person to a cool, shaded or air-conditioned place.</li>
            <li>Remove tight or extra clothing.</li>
            <li>Cool the body quickly: wet the skin with cool water, fan them, place cool wet cloths or ice packs on the neck, armpits and groin.</li>
            <li>If fully conscious and able to swallow, give small sips of water or ORS.</li>
            <li>If unconscious, lay them on their side and check breathing until help arrives.</li>
          </ol>
        </section>
        <section class="card dodont" style="grid-template-columns:1fr">
          <div class="do"><h3>✓ Emergency do's</h3><ul>
            <li>Stay with the person until help arrives.</li>
            <li>Keep cooling continuously.</li>
            <li>Tell responders how long the person was in the heat.</li>
          </ul></div>
          <div class="dont"><h3>✗ Emergency don'ts</h3><ul>
            <li>Don't give fluids to an unconscious or confused person.</li>
            <li>Don't give alcohol, caffeine or medicines like paracetamol to lower body temperature.</li>
            <li>Don't leave the person alone.</li>
          </ul></div>
        </section>
      </div>

      <section class="card">
        <div class="card-head"><h2>Nearby hospitals</h2></div>
        <p class="muted">Opens a map search for hospitals near you. Your location is used only in your browser to build the link and is never sent to our server.</p>
        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
          <button class="btn btn-primary" id="geo">Use my location</button>
          <form id="manual" style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
            <label class="field" style="margin:0"><span>Or enter a city / area</span><input name="q" placeholder="e.g. Andheri, Mumbai" required /></label>
            <button class="btn btn-secondary" type="submit">Search hospitals</button>
          </form>
        </div>
        <div id="geoMsg" style="margin-top:10px"></div>
      </section>`;

    const $ = (id) => view.querySelector(`#${id}`);
    try {
      const { contacts } = await api.emergency();
      $('contacts').innerHTML = contacts.map((c) => `
        <div class="card">
          <div class="hotline"><div><h3 style="margin:0">${esc(c.name)}</h3></div><a class="num" href="tel:${esc(c.phone)}">${esc(c.phone)}</a></div>
          <p class="muted small" style="margin:6px 0 4px">${esc(c.description)}</p>
          <div class="stamp">Source: ${esc(c.source)}</div>
        </div>`).join('');
    } catch (e) { $('contacts').innerHTML = errorBox(e.message); }

    const openSearch = (q) => window.open(`https://www.google.com/maps/search/${encodeURIComponent(q)}`, '_blank', 'noopener');
    $('geo').addEventListener('click', () => {
      if (!navigator.geolocation) { $('geoMsg').innerHTML = '<div class="alert alert-warn">Location is not available in this browser. Enter a city instead.</div>'; return; }
      $('geoMsg').innerHTML = loading('Getting your location…');
      navigator.geolocation.getCurrentPosition(
        (p) => {
          const { latitude, longitude } = p.coords;
          $('geoMsg').innerHTML = `<div class="alert alert-info">Opening hospitals near ${latitude.toFixed(3)}, ${longitude.toFixed(3)}…</div>`;
          window.open(`https://www.google.com/maps/search/hospital/@${latitude},${longitude},14z`, '_blank', 'noopener');
        },
        () => { $('geoMsg').innerHTML = '<div class="alert alert-warn">Location permission denied or unavailable. You can search by city instead.</div>'; },
        { timeout: 10000 },
      );
    });
    $('manual').addEventListener('submit', (e) => { e.preventDefault(); openSearch(`hospitals near ${e.currentTarget.q.value.trim()}`); });
  },
};
