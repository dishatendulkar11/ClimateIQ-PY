// Reusable page fragments.
import { esc, fmtT, fmtTC, fmtPct, fmtStamp, dayName, shortDate, riskChip, wxIcon, RISK, metaBadges } from '../ui.js';
import { store } from '../store.js';

export function currentCard(w) {
  const c = w.current;
  if (!c) return '<div class="alert alert-warn">Weather data temporarily unavailable.</div>';
  return `
    <div class="now">
      <div class="now-temp num">${fmtT(c.temperature)}<sup>C</sup></div>
      <div class="now-meta">
        <div class="now-cond">${wxIcon(c.weatherCode)} ${esc(c.weatherCondition)}</div>
        <div class="muted">Feels like <b>${fmtT(c.apparentTemperature)}C</b></div>
        <div class="stamp">Model time: ${esc(fmtStamp(c.time))}</div>
      </div>
    </div>
    <dl class="kv">
      <div><dt>Humidity</dt><dd>${fmtPct(c.humidity)}</dd></div>
      <div><dt>Wind</dt><dd>${typeof c.windSpeed === 'number' ? `${Math.round(c.windSpeed)} km/h` : '—'}</dd></div>
      <div><dt>Today max</dt><dd>${fmtT(w.today?.maxTemperature, 1)}</dd></div>
      <div><dt>Today min</dt><dd>${fmtT(w.today?.minTemperature, 1)}</dd></div>
    </dl>
    <div style="margin-top:12px">${metaBadges(w.meta, w.source)}</div>`;
}

export function gauge(risk, { big = false } = {}) {
  if (!risk) return '<div class="alert alert-warn">Heat-risk estimate unavailable (no forecast data).</div>';
  const color = RISK[risk.riskLevel]?.color || '#888';
  return `<div class="gauge">
      <div class="gauge-ring" style="--p:${risk.score};--c:${color};${big ? 'width:150px;height:150px' : ''}">
        <div style="${big ? 'width:118px;height:118px' : ''}"><div><b class="num">${risk.score}</b><br><small>/ 100</small></div></div>
      </div>
      <div>
        <div style="margin-bottom:6px">${riskChip(risk.riskLevel)}</div>
        <div class="small muted">System-Generated Heat-Risk Estimate for ${esc(shortDate(risk.date))}.</div>
        <div class="small muted">Project-defined bands — not an official IMD warning.</div>
      </div>
    </div>`;
}

export function factorsList(risk) {
  if (!risk) return '';
  return risk.factors.map((f) => `
    <div class="factor">
      <div><b>${esc(f.label)}</b><div class="val">${esc(f.value)}</div></div>
      <div class="num">${f.points}<span class="muted"> / ${f.max}</span></div>
      <div class="bar"><i style="width:${(f.points / f.max) * 100}%"></i></div>
      <div class="val" style="grid-column:1/-1">${esc(f.explain)}</div>
    </div>`).join('');
}

export function dayStrip(days, today) {
  if (!days || !days.length) return '<div class="alert alert-warn">Forecast unavailable.</div>';
  return `<div class="days">${days.map((d) => `
    <div class="day ${d.date === today ? 'today' : ''}">
      <div class="dname">${d.date === today ? 'Today' : esc(dayName(d.date))}</div>
      <div class="ddate">${esc(shortDate(d.date))}</div>
      ${wxIcon(d.weatherCode)}
      <div class="dmax num">${fmtT(d.maxTemperature)}</div>
      <div class="dmin">${fmtT(d.minTemperature)}</div>
      <div class="dcond">${esc(d.weatherCondition)}</div>
      ${d.risk ? riskChip(d.risk.riskLevel) : ''}
    </div>`).join('')}</div>`;
}

export function forecastTable(days) {
  return `<div class="table-wrap"><table>
    <thead><tr><th>Date</th><th>Day</th><th>Min</th><th>Max</th><th>Feels like (max)</th><th>Humidity</th><th>Rain</th><th>Wind</th><th>Condition</th><th>Heat risk</th></tr></thead>
    <tbody>${days.map((d) => `<tr>
      <td>${esc(shortDate(d.date))}</td><td>${esc(dayName(d.date))}</td>
      <td>${fmtTC(d.minTemperature)}</td><td><b>${fmtTC(d.maxTemperature)}</b></td><td>${fmtTC(d.apparentTemperature)}</td>
      <td>${fmtPct(d.humidity)}</td><td>${typeof d.precipitation === 'number' ? `${d.precipitation.toFixed(1)} mm` : '—'}</td>
      <td>${typeof d.windSpeed === 'number' ? `${Math.round(d.windSpeed)} km/h` : '—'}</td>
      <td>${esc(d.weatherCondition)}</td><td>${d.risk ? `${riskChip(d.risk.riskLevel)} <span class="muted small">${d.risk.score}</span>` : '—'}</td>
    </tr>`).join('')}</tbody></table></div>`;
}

export function stateTitle() {
  const st = store.selected;
  return st ? `${esc(st.name)} <span class="muted small">· ${esc(st.repLocation)} (representative location)</span>` : '—';
}

/** Run loader now and whenever the shared selected state changes. Returns unsubscribe. */
export function onSelectedState(loader) {
  let seq = 0;
  const run = () => { const my = ++seq; loader(store.selected, () => my === seq); };
  run();
  return store.subscribe((type) => { if (type === 'selected') run(); });
}
