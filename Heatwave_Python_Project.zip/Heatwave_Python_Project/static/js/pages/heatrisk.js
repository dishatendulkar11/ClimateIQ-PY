import { api } from '../api.js';
import { esc, loading, errorBox, updatedStamp, shortDate, dayName, riskChip, RISK } from '../ui.js';
import { barChart } from '../charts.js';
import { gauge, factorsList, stateTitle, onSelectedState } from './common.js';

export default {
  title: 'Heat Risk',
  auth: true,
  async render(view) {
    view.innerHTML = `
      <div class="page-head">
        <div>
          <div class="eyebrow">Heat Risk / Heatwave</div>
          <h1>System-Generated Heat-Risk Estimate</h1>
          <p class="muted" id="stTitle"></p>
        </div>
        <span id="stamp"></span>
      </div>
      <div class="alert alert-info small" id="disc">This is a transparent, rule-based score calculated from real Open-Meteo data. It is <b>not</b> a trained AI model and <b>not</b> an official IMD heat-wave warning. Risk bands are project-defined.</div>
      <div class="grid g-2" style="margin-bottom:16px">
        <section class="card"><div class="card-head"><h2>Today</h2></div><div id="gauge">${loading('Calculating heat risk…')}</div><div id="notes"></div></section>
        <section class="card"><div class="card-head"><h2>Contributing factors</h2></div><div id="factors">${loading('Loading…')}</div></section>
      </div>
      <div class="grid g-2" style="margin-bottom:16px">
        <section class="card"><div class="card-head"><h2>Risk score — next 7 days</h2></div><div class="chart-box"><canvas id="rc"></canvas></div></section>
        <section class="card"><div class="card-head"><h2>Recommended actions</h2></div><div id="recs">${loading('Loading…')}</div></section>
      </div>
      <section class="card">
        <div class="card-head"><h2>Risk bands (project-defined)</h2></div>
        <div class="table-wrap"><table><thead><tr><th>Score</th><th>Level</th><th>Map colour</th></tr></thead><tbody id="bands"></tbody></table></div>
        <h3 style="margin-top:16px">How the score is calculated</h3>
        <ul class="muted small" style="display:grid;gap:4px">
          <li><b>Maximum temperature</b> (0–40 pts): linear from 30 °C to 46 °C.</li>
          <li><b>Feels-like maximum</b> (0–25 pts): linear from 32 °C to 52 °C.</li>
          <li><b>Humidity stress</b> (0–10 pts): only when Tmax ≥ 32 °C; RH 40 % → 80 %.</li>
          <li><b>Persistence</b> (0–15 pts): 5 pts per day ≥ 40 °C in a 3-day window.</li>
          <li><b>Anomaly</b> (0–10 pts): Tmax above the mean of the previous 30 days (+6 °C = full). This is a recent baseline, not a climate normal.</li>
        </ul>
      </section>`;
    const $ = (id) => view.querySelector(`#${id}`);

    const off = onSelectedState(async (st, isCurrent) => {
      if (!st) return;
      $('stTitle').innerHTML = stateTitle();
      $('gauge').innerHTML = loading('Calculating heat risk…');
      try {
        const r = await api.heatwave(st.id);
        if (!isCurrent()) return;
        $('stamp').innerHTML = updatedStamp(r.meta);
        $('gauge').innerHTML = gauge(r.today, { big: true });
        $('notes').innerHTML = (r.today?.notes || []).map((n) => `<div class="alert alert-warn small" style="margin-top:12px">${esc(n)}</div>`).join('')
          + (r.meta.stale ? `<div class="alert alert-warn small" style="margin-top:12px">${esc(r.meta.message)}</div>` : '');
        $('factors').innerHTML = factorsList(r.today) || errorBox('No factors available.');
        $('bands').innerHTML = r.bands.map((b) => `<tr><td>${b.min}–${b.max}</td><td>${riskChip(b.level)}</td><td><span style="display:inline-block;width:40px;height:14px;border-radius:4px;background:${b.color}"></span></td></tr>`).join('');
        const days = r.days.filter((d) => d.risk);
        barChart($('rc'), {
          labels: days.map((d) => `${dayName(d.date)} ${shortDate(d.date)}`),
          yTitle: 'Risk score (0–100)',
          series: [{ label: 'Heat-risk score', data: days.map((d) => d.risk.score), color: '#f2994a', colors: days.map((d) => RISK[d.risk.riskLevel].color), unit: 'pts' }],
        });
        $('recs').innerHTML = r.recommendations.length
          ? `<ul class="list">${r.recommendations.map((t) => `<li style="display:block" class="tip" data-level="${t.riskLevel}"><b>${esc(t.title)}</b><div class="muted small">${esc(t.description)}</div></li>`).join('')}</ul>`
          : '<div class="empty">No recommendations.</div>';
      } catch (e) {
        if (!isCurrent()) return;
        $('gauge').innerHTML = errorBox(e.message || 'Weather data temporarily unavailable.');
        $('factors').innerHTML = '';
      }
    });
    return off;
  },
};
