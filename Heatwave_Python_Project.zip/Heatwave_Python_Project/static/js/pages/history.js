import { api } from '../api.js';
import { esc, loading, errorBox, shortDate, fmtTC, fmtDate } from '../ui.js';
import { lineChart, barChart, COLORS } from '../charts.js';
import { stateTitle, onSelectedState } from './common.js';
import { store } from '../store.js';

function ymd(d) { return d.toISOString().slice(0, 10); }

export default {
  title: 'Historical Weather',
  auth: true,
  async render(view) {
    const today = new Date();
    const yest = new Date(today.getTime() - 86400000);
    const monthAgo = new Date(today.getTime() - 60 * 86400000);
    view.innerHTML = `
      <div class="page-head">
        <div>
          <div class="eyebrow">Historical weather</div>
          <h1>Past temperatures</h1>
          <p class="muted" id="stTitle"></p>
        </div>
      </div>
      <section class="card" style="margin-bottom:16px">
        <div class="row" style="display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end">
          <div class="seg" role="group" aria-label="Range" id="ranges">
            <button type="button" data-r="7" aria-pressed="false">Last 7 days</button>
            <button type="button" data-r="30" aria-pressed="true">Last 30 days</button>
            <button type="button" data-r="custom" aria-pressed="false">Custom</button>
          </div>
          <form id="custom" hidden style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
            <label class="field" style="margin:0"><span>From</span><input type="date" name="start" min="1940-01-01" max="${ymd(yest)}" value="${ymd(monthAgo)}" required /></label>
            <label class="field" style="margin:0"><span>To</span><input type="date" name="end" min="1940-01-01" max="${ymd(yest)}" value="${ymd(yest)}" required /></label>
            <button class="btn btn-primary" type="submit">Load range</button>
          </form>
        </div>
        <p class="muted small" style="margin:10px 0 0">Historical data is kept separate from forecasts. Ranges older than ~3 months use Open-Meteo's ERA5-based Historical Weather API (data from 1940, ~5-day delay). Max 366 days per request.</p>
      </section>
      <div id="out">${loading('Loading historical weather…')}</div>`;

    const $ = (id) => view.querySelector(`#${id}`);
    let query = { range: '30' };

    $('ranges').addEventListener('click', (e) => {
      const b = e.target.closest('[data-r]');
      if (!b) return;
      $('ranges').querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
      const r = b.dataset.r;
      $('custom').hidden = r !== 'custom';
      if (r !== 'custom') { query = { range: r }; load(store.selected, () => true); }
    });
    $('custom').addEventListener('submit', (e) => {
      e.preventDefault();
      const f = e.currentTarget;
      if (f.start.value > f.end.value) { $('out').innerHTML = errorBox('Start date must be before end date.'); return; }
      query = { range: 'custom', start: f.start.value, end: f.end.value };
      load(store.selected, () => true);
    });

    let seq = 0;
    async function load(st, isCurrentState) {
      if (!st) return;
      const my = ++seq;
      $('stTitle').innerHTML = stateTitle();
      $('out').innerHTML = loading('Loading historical weather…');
      try {
        const h = await api.history(st.id, query);
        if (my !== seq || !isCurrentState()) return;
        render(h);
      } catch (e) {
        if (my !== seq) return;
        $('out').innerHTML = errorBox(e.message || 'Historical weather unavailable.');
      }
    }

    function render(h) {
      const s = h.summary;
      const labels = h.rows.map((r) => shortDate(r.date));
      $('out').innerHTML = `
        <div class="alert alert-info small"><b>Range:</b> ${esc(fmtDate(h.range.start, { day: 'numeric', month: 'short', year: 'numeric' }))} → ${esc(fmtDate(h.range.end, { day: 'numeric', month: 'short', year: 'numeric' }))} ·
          <b>Source:</b> ${esc(h.sourceLabel)} · <b>Location:</b> ${esc(h.state.repLocation)} (state representative)</div>
        ${h.notes.map((n) => `<div class="alert alert-warn small">${esc(n)}</div>`).join('')}
        ${s ? `<div class="grid g-4" style="margin-bottom:16px">
          <div class="card"><div class="muted small">Mean daily max</div><div class="num" style="font-size:1.6rem;font-weight:700">${fmtTC(s.meanMax)}</div></div>
          <div class="card"><div class="muted small">Mean daily min</div><div class="num" style="font-size:1.6rem;font-weight:700">${fmtTC(s.meanMin)}</div></div>
          <div class="card"><div class="muted small">Hottest day</div><div class="num" style="font-size:1.6rem;font-weight:700">${fmtTC(s.hottestDay.value)}</div><div class="stamp">${esc(shortDate(s.hottestDay.date))}</div></div>
          <div class="card"><div class="muted small">Days ≥ 40 °C</div><div class="num" style="font-size:1.6rem;font-weight:700">${s.daysAbove40} <span class="muted small">of ${s.days}</span></div></div>
        </div>` : ''}
        ${h.comparison ? `<div class="card" style="margin-bottom:16px"><h3>Current vs selected period</h3><p>${esc(h.comparison.text)}</p><p class="stamp">${esc(h.comparison.caveat)}</p></div>` : ''}
        <section class="card" style="margin-bottom:16px"><div class="card-head"><h2>Temperature trend</h2></div><div class="chart-box tall"><canvas id="hl"></canvas></div></section>
        <div class="grid g-2" style="margin-bottom:16px">
          <section class="card"><div class="card-head"><h2>Daily maximum</h2></div><div class="chart-box"><canvas id="hmax"></canvas></div></section>
          <section class="card"><div class="card-head"><h2>Daily minimum</h2></div><div class="chart-box"><canvas id="hmin"></canvas></div></section>
        </div>
        <section class="card"><div class="card-head"><h2>Daily records</h2></div>
          <div class="table-wrap" style="max-height:420px;overflow:auto"><table><thead><tr><th>Date</th><th>Max</th><th>Min</th><th>Average</th><th>Feels like (max)</th></tr></thead><tbody>
          ${h.rows.slice().reverse().map((r) => `<tr><td>${esc(fmtDate(r.date, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }))}</td><td>${fmtTC(r.maxTemperature)}</td><td>${fmtTC(r.minTemperature)}</td><td>${fmtTC(r.averageTemperature)}${r.averageDerived ? '*' : ''}</td><td>${fmtTC(r.apparentTemperature)}</td></tr>`).join('')}
          </tbody></table></div></section>`;
      lineChart(view.querySelector('#hl'), {
        labels,
        series: [
          { label: 'Max', data: h.rows.map((r) => r.maxTemperature), color: COLORS.max },
          { label: 'Average', data: h.rows.map((r) => r.averageTemperature), color: COLORS.avg },
          { label: 'Min', data: h.rows.map((r) => r.minTemperature), color: COLORS.min },
        ],
      });
      barChart(view.querySelector('#hmax'), { labels, series: [{ label: 'Daily max', data: h.rows.map((r) => r.maxTemperature), color: COLORS.max }] });
      barChart(view.querySelector('#hmin'), { labels, series: [{ label: 'Daily min', data: h.rows.map((r) => r.minTemperature), color: COLORS.min }] });
    }

    return onSelectedState(load);
  },
};
