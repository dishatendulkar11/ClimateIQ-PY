import { api } from '../api.js';
import { store } from '../store.js';
import { esc, loading, errorBox, toast, fmtTC, riskChip } from '../ui.js';

export default {
  title: 'Favorites',
  auth: true,
  async render(view, { navigate }) {
    view.innerHTML = `
      <div class="page-head">
        <div><div class="eyebrow">Saved</div><h1>Favorite states</h1>
        <p class="muted">Stored in the <code>user_favorites</code> table (unique per user + state).</p></div>
      </div>
      <section class="card" style="margin-bottom:16px">
        <form id="add" style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
          <label class="field" style="margin:0;min-width:240px"><span>Add a state / UT</span>
            <select name="code">${store.states.map((s) => `<option value="${s.code}">${esc(s.name)}</option>`).join('')}</select></label>
          <button class="btn btn-primary" type="submit">Add to Favorites</button>
        </form>
      </section>
      <div id="list">${loading('Loading favorites…')}</div>`;

    const list = view.querySelector('#list');
    const add = view.querySelector('#add');
    if (store.selected) add.code.value = store.selected.code;

    async function load() {
      try {
        const [{ favorites }, risk] = await Promise.all([api.favorites(), api.mapRisk().catch(() => null)]);
        if (!favorites.length) { list.innerHTML = '<div class="empty">No favorites yet.</div>'; return; }
        list.innerHTML = `<div class="grid g-3">${favorites.map((f) => {
          const s = risk && risk.states.find((x) => x.code === f.state.code);
          const d = s && s.days[0];
          return `<div class="card">
            <div class="card-head"><h3>★ ${esc(f.state.name)}</h3>${riskChip(d?.level)}</div>
            <div class="muted small">${esc(f.state.repLocation)} · saved ${esc(new Date(f.createdAt).toLocaleDateString('en-IN'))}</div>
            <dl class="kv"><div><dt>Now</dt><dd>${fmtTC(s?.current?.temperature)}</dd></div><div><dt>Max today</dt><dd>${fmtTC(d?.tmax)}</dd></div></dl>
            <div style="display:flex;gap:8px;margin-top:12px">
              <button class="btn btn-secondary btn-sm" data-open="${f.state.code}">Open dashboard</button>
              <button class="btn btn-danger btn-sm" data-del="${f.id}">Remove</button>
            </div></div>`;
        }).join('')}</div>`;
      } catch (e) { list.innerHTML = errorBox(e.message); }
    }

    add.addEventListener('submit', async (e) => {
      e.preventDefault();
      const st = store.states.find((s) => s.code === add.code.value);
      try { await api.addFavorite(st.id); toast(`${st.name} added.`); load(); } catch (err) { toast(err.message, 'error'); }
    });
    list.addEventListener('click', async (e) => {
      const del = e.target.closest('[data-del]');
      const open = e.target.closest('[data-open]');
      if (del) {
        del.disabled = true;
        try { await api.removeFavorite(del.dataset.del); toast('Removed from favorites.'); load(); } catch (err) { toast(err.message, 'error'); del.disabled = false; }
      } else if (open) {
        store.select(open.dataset.open, 'dropdown');
        navigate('/dashboard');
      }
    });
    load();
  },
};
