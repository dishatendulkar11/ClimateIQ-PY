// Chart.js helpers — theme-aware (readable in dark and light), with axes,
// units, legends and tooltips. Charts re-theme when the theme toggles.

const live = new Set();

export const COLORS = {
  max: '#ef5a3c',
  min: '#3b82f6',
  apparent: '#f59e0b',
  avg: '#14b8a6',
  precip: '#60a5fa',
};

function themeVars() {
  const cs = getComputedStyle(document.documentElement);
  return {
    text: cs.getPropertyValue('--chart-text').trim() || '#888',
    grid: cs.getPropertyValue('--chart-grid').trim() || 'rgba(128,128,128,.2)',
    surface: cs.getPropertyValue('--surface').trim() || '#fff',
    border: cs.getPropertyValue('--border').trim() || '#ccc',
    heading: cs.getPropertyValue('--heading').trim() || '#000',
  };
}

function baseOptions(yTitle, xTitle) {
  const t = themeVars();
  return {
    responsive: true,
    maintainAspectRatio: false,
    animation: { duration: 500, easing: 'easeOutQuart' },
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: { position: 'top', align: 'end', labels: { color: t.text, usePointStyle: true, boxWidth: 8, boxHeight: 8, font: { family: 'Inter', size: 12 } } },
      tooltip: {
        backgroundColor: t.surface, titleColor: t.heading, bodyColor: t.text, borderColor: t.border, borderWidth: 1,
        padding: 10, titleFont: { family: 'Inter', weight: '600' }, bodyFont: { family: 'Inter' },
        callbacks: { label: (ctx) => `${ctx.dataset.label}: ${ctx.parsed.y == null ? '—' : ctx.parsed.y.toFixed(1)} ${ctx.dataset.unit || '°C'}` },
      },
    },
    scales: {
      x: {
        ticks: { color: t.text, font: { family: 'Inter', size: 11 }, maxRotation: 0, autoSkipPadding: 12 },
        grid: { display: false }, border: { color: t.grid },
        title: xTitle ? { display: true, text: xTitle, color: t.text, font: { family: 'Inter', size: 11 } } : undefined,
      },
      y: {
        ticks: { color: t.text, font: { family: 'Inter', size: 11 }, callback: (v) => `${v}°` },
        grid: { color: t.grid }, border: { display: false },
        title: { display: true, text: yTitle || 'Temperature (°C)', color: t.text, font: { family: 'Inter', size: 11 } },
      },
    },
  };
}

function make(canvas, config) {
  if (!canvas) return null;
  if (typeof window.Chart === 'undefined') {
    canvas.replaceWith(Object.assign(document.createElement('div'), { className: 'alert alert-warn', textContent: 'Chart library failed to load (check internet connection).' }));
    return null;
  }
  const old = window.Chart.getChart(canvas);
  if (old) { old.destroy(); live.delete(old); }
  const chart = new window.Chart(canvas, config);
  chart.$build = config.$build;
  live.add(chart);
  return chart;
}

/** series: [{ label, data, color, dash?, fill? }] */
export function lineChart(canvas, { labels, series, yTitle, xTitle }) {
  const build = () => ({
    type: 'line',
    data: {
      labels,
      datasets: series.map((s) => ({
        label: s.label, data: s.data, borderColor: s.color, backgroundColor: s.fill ? `${s.color}22` : s.color,
        borderWidth: 2.5, pointRadius: labels.length > 40 ? 0 : 3, pointHoverRadius: 5, tension: 0.35,
        borderDash: s.dash ? [6, 4] : undefined, fill: s.fill ? 'origin' : false, spanGaps: true, unit: s.unit,
      })),
    },
    options: baseOptions(yTitle, xTitle),
  });
  return make(canvas, { ...build(), $build: build });
}

export function barChart(canvas, { labels, series, yTitle, xTitle }) {
  const build = () => {
    const opts = baseOptions(yTitle, xTitle);
    opts.scales.y.beginAtZero = false;
    return {
      type: 'bar',
      data: {
        labels,
        datasets: series.map((s) => ({
          label: s.label, data: s.data, backgroundColor: s.colors || `${s.color}cc`, borderColor: s.color,
          borderWidth: 0, borderRadius: 6, maxBarThickness: 34, unit: s.unit,
        })),
      },
      options: opts,
    };
  };
  return make(canvas, { ...build(), $build: build });
}

/** Re-apply theme colours to every live chart. */
export function rethemeCharts() {
  for (const c of [...live]) {
    if (!c.canvas || !c.canvas.isConnected) { c.destroy(); live.delete(c); continue; }
    if (c.$build) {
      const fresh = c.$build();
      c.options = fresh.options;
      c.update('none');
    }
  }
}

export function destroyDetached() {
  for (const c of [...live]) if (!c.canvas || !c.canvas.isConnected) { c.destroy(); live.delete(c); }
}
