// App shell: router, navigation, theme, shared state selector.
import { api } from './api.js';
import { store } from './store.js';
import { h, esc, toast } from './ui.js';
import { rethemeCharts } from './charts.js';

import home from './pages/home.js';
import login from './pages/login.js';
import register from './pages/register.js';
import dashboard from './pages/dashboard.js';
import mapPage from './pages/map.js';
import heatrisk from './pages/heatrisk.js';
import forecast from './pages/forecast.js';
import history from './pages/history.js';
import safety from './pages/safety.js';
import emergency from './pages/emergency.js';
import profile from './pages/profile.js';
import favorites from './pages/favorites.js';
import searches from './pages/searches.js';

const ROUTES = {
  '/': home,
  '/login': login,
  '/register': register,
  '/dashboard': dashboard,
  '/map': mapPage,
  '/heat-risk': heatrisk,
  '/forecast': forecast,
  '/history': history,
  '/safety': safety,
  '/emergency': emergency,
  '/profile': profile,
  '/favorites': favorites,
  '/searches': searches,
};

const NAV_AUTH = [
  ['/dashboard', 'Dashboard'], ['/map', 'India Map'], ['/heat-risk', 'Heat Risk'], ['/forecast', 'Forecast'],
  ['/history', 'Historical'], ['/safety', 'Safety'], ['/emergency', 'Emergency'], ['/favorites', 'Favorites'], ['/searches', 'Search History'],
];
const NAV_PUBLIC = [['/', 'Home'], ['/login', 'Login'], ['/register', 'Register']];

const view = document.getElementById('view');
const nav = document.getElementById('nav');
const userArea = document.getElementById('userArea');
const stateBar = document.getElementById('stateBar');
let cleanup = null;
const themeListeners = new Set();

export const onTheme = (fn) => { themeListeners.add(fn); return () => themeListeners.delete(fn); };
export const navigate = (path) => { location.hash = `#${path}`; };

// ---------- theme ----------
document.getElementById('themeToggle').addEventListener('click', () => {
  const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
  document.documentElement.dataset.theme = next;
  try { localStorage.setItem('ci-theme', next); } catch { /* ignore */ }
  rethemeCharts();
  themeListeners.forEach((fn) => fn(next));
});

// ---------- mobile nav ----------
const navToggle = document.getElementById('navToggle');
navToggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', String(open));
});

function renderNav(path) {
  const items = store.user ? NAV_AUTH : NAV_PUBLIC;
  nav.innerHTML = items.map(([p, label]) => `<a href="#${p}" class="${p === path ? 'active' : ''}">${label}</a>`).join('');
  nav.classList.remove('open');
  navToggle.setAttribute('aria-expanded', 'false');
  if (store.user) {
    const initials = store.user.fullName.split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
    userArea.innerHTML = `<div class="user-chip">
      <a href="#/profile" class="avatar" title="Profile — ${esc(store.user.fullName)}" aria-label="Profile">${esc(initials)}</a>
      <button class="btn btn-ghost btn-sm" id="logoutBtn">Logout</button></div>`;
    userArea.querySelector('#logoutBtn').addEventListener('click', logout);
  } else {
    userArea.innerHTML = `<a class="btn btn-primary btn-sm" href="#/login">Login</a>`;
  }
}

async function logout() {
  try { await api.logout(); } catch { /* cookie cleared server-side anyway */ }
  store.user = null;
  toast('You have been logged out.');
  navigate('/login');
}

// ---------- shared state selector (dropdown + search) ----------
const SELECTOR_PAGES = new Set(['/dashboard', '/map', '/heat-risk', '/forecast', '/history', '/safety']);

function renderStateBar(path) {
  if (!store.user || !SELECTOR_PAGES.has(path) || !store.states.length) { stateBar.hidden = true; stateBar.innerHTML = ''; return; }
  stateBar.hidden = false;
  const groups = [['STATE', 'States'], ['UNION_TERRITORY', 'Union Territories']];
  const opts = groups.map(([t, label]) => `<optgroup label="${label}">${store.states.filter((s) => s.type === t)
    .map((s) => `<option value="${s.code}">${esc(s.name)}</option>`).join('')}</optgroup>`).join('');
  stateBar.innerHTML = `<div class="statebar-inner">
      <label for="stateSelect">State / UT</label>
      <select id="stateSelect" class="compact" aria-label="Select state or union territory">${opts}</select>
      <div class="search-wrap">
        <input id="stateSearch" type="search" placeholder="Search a state or UT…" autocomplete="off" role="combobox"
          aria-autocomplete="list" aria-expanded="false" aria-controls="stateSuggest" aria-label="Search state" />
        <ul id="stateSuggest" class="suggest" role="listbox" hidden></ul>
      </div>
      <button class="btn btn-secondary btn-sm" id="favBtn" title="Save to favorites">☆ Add to Favorites</button>
      <span class="muted small">Selected: <span class="current" id="curState"></span> · <a href="#/map">pick on map</a></span>
    </div>`;
  const sel = stateBar.querySelector('#stateSelect');
  const input = stateBar.querySelector('#stateSearch');
  const list = stateBar.querySelector('#stateSuggest');
  let active = -1;
  let matches = [];

  sel.addEventListener('change', () => store.select(sel.value, 'dropdown'));

  const close = () => { list.hidden = true; input.setAttribute('aria-expanded', 'false'); active = -1; };
  const pick = (code) => { store.select(code, 'search'); input.value = ''; close(); };
  function show() {
    const q = input.value.trim().toLowerCase();
    if (!q) { close(); return; }
    matches = store.states.filter((s) => s.name.toLowerCase().includes(q) || s.code.toLowerCase() === q || s.repLocation.toLowerCase().includes(q)).slice(0, 8);
    list.innerHTML = matches.length
      ? matches.map((s, i) => `<li role="option" id="sg-${s.code}" data-code="${s.code}" aria-selected="${i === active}">${esc(s.name)}<span class="tag">${s.type === 'STATE' ? 'State' : 'UT'} · ${esc(s.repLocation)}</span></li>`).join('')
      : '<li aria-disabled="true" class="muted">No matching state or UT</li>';
    list.hidden = false;
    input.setAttribute('aria-expanded', 'true');
  }
  let deb;
  input.addEventListener('input', () => { active = -1; clearTimeout(deb); deb = setTimeout(show, 120); });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      if (!matches.length) return;
      active = (active + (e.key === 'ArrowDown' ? 1 : -1) + matches.length) % matches.length;
      show();
      input.setAttribute('aria-activedescendant', `sg-${matches[active].code}`);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (matches.length) pick(matches[Math.max(0, active)].code);
    } else if (e.key === 'Escape') close();
  });
  list.addEventListener('mousedown', (e) => { const li = e.target.closest('li[data-code]'); if (li) { e.preventDefault(); pick(li.dataset.code); } });
  input.addEventListener('blur', () => setTimeout(close, 120));

  stateBar.querySelector('#favBtn').addEventListener('click', async (e) => {
    const st = store.selected;
    if (!st) return;
    const btn = e.currentTarget; // keep a reference: currentTarget is null after the await
    btn.disabled = true;
    try { await api.addFavorite(st.id); toast(`${st.name} saved to favorites.`); } catch (err) { toast(err.message, 'error'); }
    btn.disabled = false;
  });
  syncStateBar();
}

function syncStateBar() {
  const st = store.selected;
  const sel = stateBar.querySelector('#stateSelect');
  const cur = stateBar.querySelector('#curState');
  if (sel && st) sel.value = st.code;
  if (cur) cur.textContent = st ? st.name : '—';
}

store.subscribe((type) => { if (type === 'selected') syncStateBar(); });

// ---------- router ----------
async function route() {
  const path = (location.hash.replace(/^#/, '') || '/').split('?')[0];
  const page = ROUTES[path] || home;

  if (page.auth && !store.user) { navigate('/login'); return; }
  if (page.guestOnly && store.user) { navigate('/dashboard'); return; }

  if (cleanup) { try { cleanup(); } catch (e) { console.error(e); } cleanup = null; }
  renderNav(path);
  if (page.auth) {
    try { await store.loadStates(); } catch (e) { view.innerHTML = `<div class="alert alert-error">Could not load states: ${esc(e.message)}</div>`; return; }
  }
  renderStateBar(path);
  document.title = `${page.title || 'Home'} · Climate Intelligence India`;
  view.innerHTML = '';
  window.scrollTo(0, 0);
  try {
    cleanup = (await page.render(view, { navigate, onTheme })) || null;
  } catch (e) {
    console.error(e);
    view.appendChild(h(`<div class="alert alert-error">Something went wrong: ${esc(e.message)}</div>`));
  }
  view.focus({ preventScroll: true });
}

window.addEventListener('hashchange', route);
store.subscribe((type) => { if (type === 'user') renderNav((location.hash.replace(/^#/, '') || '/')); });

// ---------- boot ----------
(async () => {
  try {
    const { user } = await api.me();
    store.user = user;
  } catch {
    store.user = null;
  }
  route();
})();
