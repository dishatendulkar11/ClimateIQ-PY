// Thin API client. All server calls go through here (no fetch() in pages).
// GETs are de-duplicated and cached briefly so switching pages doesn't refetch.

const inflight = new Map();
const cache = new Map(); // url -> { at, data }
const TTL = 60 * 1000;

export class ApiError extends Error {
  constructor(message, status, fields) {
    super(message);
    this.status = status;
    this.fields = fields || null;
  }
}

async function request(method, url, body) {
  let res;
  try {
    res = await fetch(url, {
      method,
      credentials: 'same-origin',
      headers: body ? { 'Content-Type': 'application/json' } : {},
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError('Cannot reach the server. Check your connection.', 0);
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(data.error || `Request failed (${res.status})`, res.status, data.fields);
  return data;
}

export function get(url, { fresh = false, ttl = TTL } = {}) {
  const hit = cache.get(url);
  if (!fresh && hit && Date.now() - hit.at < ttl) return Promise.resolve(hit.data);
  if (inflight.has(url)) return inflight.get(url);
  const p = request('GET', url)
    .then((data) => { cache.set(url, { at: Date.now(), data }); return data; })
    .finally(() => inflight.delete(url));
  inflight.set(url, p);
  return p;
}

export const post = (url, body) => request('POST', url, body || {});
export const put = (url, body) => request('PUT', url, body || {});
export const del = (url, body) => request('DELETE', url, body);

export function invalidate(prefix) {
  for (const k of cache.keys()) if (k.startsWith(prefix)) cache.delete(k);
}

// ---- endpoints ----
export const api = {
  me: () => request('GET', '/api/auth/me'),
  login: (email, password) => post('/api/auth/login', { email, password }),
  register: (data) => post('/api/auth/register', data),
  logout: () => post('/api/auth/logout'),
  updateProfile: (data) => put('/api/auth/profile', data),
  changePassword: (data) => put('/api/auth/password', data),
  deleteAccount: (password) => del('/api/auth/account', { password }),

  states: () => get('/api/states', { ttl: 3600e3 }),
  weather: (id) => get(`/api/states/${id}/weather`),
  forecast: (id) => get(`/api/states/${id}/forecast`),
  history: (id, q) => get(`/api/states/${id}/history?${new URLSearchParams(q)}`, { ttl: 10 * 60e3 }),
  heatwave: (id) => get(`/api/heatwave/${id}`),
  mapRisk: () => get('/api/map/risk'),
  mapGeo: () => get('/api/map/geo', { ttl: 24 * 3600e3 }),
  safety: (level) => get(`/api/safety${level ? `?level=${level}` : ''}`, { ttl: 3600e3 }),
  emergency: () => get('/api/emergency', { ttl: 3600e3 }),

  favorites: () => get('/api/favorites', { fresh: true }),
  addFavorite: (stateId) => post('/api/favorites', { stateId }),
  removeFavorite: (id) => del(`/api/favorites/${id}`),
  searchHistory: () => get('/api/search-history', { fresh: true }),
  addSearch: (stateId, method) => post('/api/search-history', { stateId, method }),
  removeSearch: (id) => del(`/api/search-history/${id}`),
  clearSearches: () => del('/api/search-history'),
  dbStats: () => get('/api/db/stats', { fresh: true }),
};
