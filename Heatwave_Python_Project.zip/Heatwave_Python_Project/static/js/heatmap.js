// Interactive India heat map (MapLibre GL JS).
// - Real state/UT boundaries (GeoJSON from /api/map/geo)
// - Choropleth by heat-risk level OR by max temperature
// - "Heat glow" heatmap layer weighted by forecast Tmax → shows heat-wave cores
// - 7-day slider with play button to watch the heat move across India
// - Basemap follows the app theme (CARTO Dark Matter / Positron)
// - Hover = info popup, click = select state globally

import { api } from './api.js';
import { esc, fmtTC, fmtDate, RISK } from './ui.js';

const STYLES = {
  dark: 'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json',
  light: 'https://basemaps.cartocdn.com/gl/positron-gl-style/style.json',
};

const TEMP_STOPS = [
  [15, '#2c7bb6'], [22, '#74add1'], [27, '#abd9e9'], [31, '#ffffbf'], [35, '#fee090'],
  [38, '#fdae61'], [41, '#f46d43'], [44, '#d73027'], [47, '#7f0000'],
];
const NO_DATA = 'rgba(140,150,170,0.25)';

const styleCache = {};
async function loadStyle(theme) {
  if (styleCache[theme]) return structuredClone(styleCache[theme]);
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 8000);
    const res = await fetch(STYLES[theme], { signal: ctrl.signal });
    clearTimeout(t);
    if (!res.ok) throw new Error(res.status);
    styleCache[theme] = await res.json();
    return structuredClone(styleCache[theme]);
  } catch {
    // offline / blocked basemap: plain background so the data layers still work
    return {
      version: 8,
      sources: {},
      layers: [{ id: 'bg', type: 'background', paint: { 'background-color': theme === 'dark' ? '#0c1426' : '#f3eee3' } }],
    };
  }
}

const currentTheme = () => (document.documentElement.dataset.theme === 'light' ? 'light' : 'dark');

export function createIndiaMap(host, { compact = false, selectedCode = null, onSelect = () => {} } = {}) {
  host.innerHTML = `
    <div class="map-shell ${compact ? 'compact' : ''}">
      <div class="map" role="region" aria-label="Interactive heat map of India"></div>
      <div class="map-overlay map-controls" hidden>
        <div class="row">
          <div class="seg" role="group" aria-label="Colour states by">
            <button type="button" data-mode="risk" aria-pressed="true">Heat risk</button>
            <button type="button" data-mode="temp" aria-pressed="false">Max temp</button>
          </div>
          <label class="toggle"><input type="checkbox" data-heat checked /> Heat glow</label>
          <label class="toggle"><input type="checkbox" data-labels checked /> °C labels</label>
        </div>
        <div class="row map-day">
          <button type="button" class="btn btn-secondary btn-sm" data-play aria-label="Play 7-day animation">▶</button>
          <input type="range" min="0" max="6" value="0" step="1" aria-label="Forecast day" data-day />
          <output data-day-label>Today</output>
        </div>
      </div>
      <div class="map-overlay legend" hidden></div>
      <div class="map-overlay map-status"><div class="state-msg"><span class="spinner"></span>Loading map &amp; weather data…</div></div>
    </div>`;

  const el = {
    map: host.querySelector('.map'),
    controls: host.querySelector('.map-controls'),
    legend: host.querySelector('.legend'),
    status: host.querySelector('.map-status'),
    day: host.querySelector('[data-day]'),
    dayLabel: host.querySelector('[data-day-label]'),
    play: host.querySelector('[data-play]'),
    heat: host.querySelector('[data-heat]'),
    labels: host.querySelector('[data-labels]'),
  };

  let map = null;
  let geo = null;           // FeatureCollection or null if boundary file missing
  let risk = null;          // /api/map/risk payload
  let idsByCode = {};       // state_code -> [feature ids]
  let mode = 'risk';
  let day = 0;
  let selected = selectedCode;
  let hoverId = null;
  let timer = null;
  let destroyed = false;
  let glyphFont = null;
  const popup = window.maplibregl ? new window.maplibregl.Popup({ closeButton: false, closeOnClick: false, offset: 10, maxWidth: '260px' }) : null;

  const showStatus = (html) => { el.status.hidden = false; el.status.innerHTML = html; };

  // ---------- data → map ----------
  function stateByCode(code) { return risk && risk.states.find((s) => s.code === code); }

  function pointsFC() {
    return {
      type: 'FeatureCollection',
      features: (risk ? risk.states : []).map((s) => {
        const d = s.days[day] || {};
        return {
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [s.longitude, s.latitude] },
          properties: { code: s.code, name: s.name, tmax: d.tmax ?? null, level: d.level || 'NONE', label: typeof d.tmax === 'number' ? `${Math.round(d.tmax)}°` : '' },
        };
      }),
    };
  }

  function applyDay() {
    if (!map || !risk) return;
    if (geo) {
      for (const s of risk.states) {
        const d = s.days[day] || {};
        for (const id of idsByCode[s.code] || []) {
          map.setFeatureState({ source: 'states', id }, { level: d.level || null, tmax: typeof d.tmax === 'number' ? d.tmax : null });
        }
      }
    }
    const src = map.getSource('pts');
    if (src) src.setData(pointsFC());
    const date = risk.dates[day];
    el.dayLabel.textContent = day === 0 ? 'Today' : fmtDate(date);
  }

  function fillColorExpr() {
    if (mode === 'temp') {
      const stops = TEMP_STOPS.flat();
      return ['case', ['==', ['typeof', ['feature-state', 'tmax']], 'number'],
        ['interpolate', ['linear'], ['feature-state', 'tmax'], ...stops], NO_DATA];
    }
    const pairs = Object.entries(RISK).flatMap(([k, v]) => [k, v.color]);
    return ['match', ['coalesce', ['feature-state', 'level'], 'NONE'], ...pairs, NO_DATA];
  }

  function pointColorExpr() {
    if (mode === 'temp') {
      return ['case', ['==', ['typeof', ['get', 'tmax']], 'number'], ['interpolate', ['linear'], ['get', 'tmax'], ...TEMP_STOPS.flat()], NO_DATA];
    }
    return ['match', ['get', 'level'], ...Object.entries(RISK).flatMap(([k, v]) => [k, v.color]), NO_DATA];
  }

  function renderLegend() {
    el.legend.hidden = false;
    if (mode === 'temp') {
      const grad = TEMP_STOPS.map(([t, c]) => `${c} ${((t - 15) / 32) * 100}%`).join(',');
      el.legend.innerHTML = `<h4>Forecast max temp (°C)</h4><div class="ramp" style="background:linear-gradient(90deg,${grad})"></div>
        <div class="ramp-labels"><span>15</span><span>31</span><span>41</span><span>47+</span></div>`;
    } else {
      el.legend.innerHTML = `<h4>Heat-risk estimate</h4>${Object.entries(RISK).map(([, v]) => `<div class="sw"><i style="background:${v.color}"></i>${v.label}</div>`).join('')}
        <div class="sw"><i style="background:${NO_DATA}"></i>No data</div>
        <div class="muted" style="margin-top:4px;max-width:180px">Project-defined bands, not IMD warnings.</div>`;
    }
  }

  function addLayers() {
    const style = map.getStyle();
    const firstSymbol = (style.layers || []).find((l) => l.type === 'symbol');
    const before = firstSymbol ? firstSymbol.id : undefined;
    const fontLayer = (style.layers || []).find((l) => l.type === 'symbol' && l.layout && l.layout['text-font']);
    glyphFont = style.glyphs && fontLayer ? fontLayer.layout['text-font'] : null;
    const css = getComputedStyle(document.documentElement);
    const accent = css.getPropertyValue('--accent').trim() || '#2dd4bf';
    const lineColor = currentTheme() === 'dark' ? 'rgba(220,230,255,0.45)' : 'rgba(30,45,80,0.45)';

    if (geo) {
      map.addSource('states', { type: 'geojson', data: geo });
      map.addLayer({ id: 'states-fill', type: 'fill', source: 'states', paint: {
        'fill-color': fillColorExpr(),
        'fill-opacity': ['case', ['boolean', ['feature-state', 'hover'], false], 0.92, 0.7],
      } }, before);
      map.addLayer({ id: 'states-line', type: 'line', source: 'states', paint: { 'line-color': lineColor, 'line-width': ['interpolate', ['linear'], ['zoom'], 3, 0.5, 7, 1.4] } }, before);
    }

    map.addSource('pts', { type: 'geojson', data: pointsFC() });
    map.addLayer({ id: 'heat', type: 'heatmap', source: 'pts', layout: { visibility: el.heat.checked ? 'visible' : 'none' }, paint: {
      'heatmap-weight': ['case', ['==', ['typeof', ['get', 'tmax']], 'number'], ['interpolate', ['linear'], ['get', 'tmax'], 32, 0, 38, 0.45, 42, 0.8, 46, 1], 0],
      'heatmap-intensity': ['interpolate', ['linear'], ['zoom'], 3, 1.1, 7, 2],
      'heatmap-radius': ['interpolate', ['linear'], ['zoom'], 3, 38, 5, 80, 7, 150],
      'heatmap-opacity': geo ? 0.7 : 0.85,
      'heatmap-color': ['interpolate', ['linear'], ['heatmap-density'],
        0, 'rgba(255,200,0,0)', 0.15, 'rgba(255,214,90,0.35)', 0.35, 'rgba(253,174,97,0.6)',
        0.55, 'rgba(244,109,67,0.75)', 0.75, 'rgba(215,48,39,0.85)', 1, 'rgba(127,0,0,0.95)'],
    } });

    if (geo) {
      map.addLayer({ id: 'states-selected', type: 'line', source: 'states', filter: ['==', ['get', 'state_code'], selected || ''],
        paint: { 'line-color': accent, 'line-width': 3 } });
    }

    map.addLayer({ id: 'pts-circle', type: 'circle', source: 'pts', paint: {
      'circle-radius': geo ? ['interpolate', ['linear'], ['zoom'], 3, 3, 7, 6] : ['interpolate', ['linear'], ['zoom'], 3, 9, 7, 16],
      'circle-color': geo ? (currentTheme() === 'dark' ? '#e7edf8' : '#13213f') : pointColorExpr(),
      'circle-stroke-width': geo ? 1 : 2,
      'circle-stroke-color': currentTheme() === 'dark' ? '#0a1020' : '#ffffff',
    } });

    if (glyphFont) {
      map.addLayer({ id: 'pts-label', type: 'symbol', source: 'pts', layout: {
        'text-field': ['get', 'label'], 'text-font': glyphFont, 'text-size': ['interpolate', ['linear'], ['zoom'], 3, 10, 7, 14],
        'text-offset': [0, -1.1], 'text-allow-overlap': false, visibility: el.labels.checked ? 'visible' : 'none',
      }, paint: {
        'text-color': currentTheme() === 'dark' ? '#ffffff' : '#0f2a5f',
        'text-halo-color': currentTheme() === 'dark' ? 'rgba(10,16,32,0.9)' : 'rgba(255,255,255,0.95)', 'text-halo-width': 1.4,
      } });
    } else {
      el.labels.closest('label').hidden = true;
    }
    applyDay();
  }

  // ---------- interaction ----------
  function popupHtml(code, fallbackName) {
    const s = stateByCode(code);
    if (!s) return `<div class="pop"><h4>${esc(fallbackName || 'Unknown area')}</h4><div class="muted small">No matching state in database</div></div>`;
    const d = s.days[day] || {};
    const lvl = d.level ? RISK[d.level] : null;
    return `<div class="pop">
      <h4>${esc(s.name)}</h4>
      <div class="muted small" style="margin-bottom:6px">${esc(s.repLocation)} · ${day === 0 ? 'Today' : esc(fmtDate(d.date))}</div>
      <div class="row"><span>Heat risk</span><b style="color:${lvl ? lvl.color : 'inherit'}">${lvl ? `${esc(lvl.label)} (${d.score})` : 'n/a'}</b></div>
      <div class="row"><span>Max / Min</span><b>${fmtTC(d.tmax)} / ${fmtTC(d.tmin)}</b></div>
      <div class="row"><span>Feels like (max)</span><b>${fmtTC(d.apparent)}</b></div>
      <div class="row"><span>Condition</span><b>${esc(d.condition || '—')}</b></div>
      ${day === 0 && s.current ? `<div class="row"><span>Now</span><b>${fmtTC(s.current.temperature)} · ${Math.round(s.current.humidity ?? 0)}% RH</b></div>` : ''}
      <div class="muted small" style="margin-top:6px">Click to select</div>
    </div>`;
  }

  function bindEvents() {
    const hoverLayer = geo ? 'states-fill' : 'pts-circle';
    map.on('mousemove', hoverLayer, (e) => {
      const f = e.features && e.features[0];
      if (!f) return;
      map.getCanvas().style.cursor = 'pointer';
      if (geo) {
        if (hoverId !== null && hoverId !== f.id) map.setFeatureState({ source: 'states', id: hoverId }, { hover: false });
        hoverId = f.id;
        map.setFeatureState({ source: 'states', id: hoverId }, { hover: true });
      }
      const code = geo ? f.properties.state_code : f.properties.code;
      popup && popup.setLngLat(e.lngLat).setHTML(popupHtml(code, f.properties.state_name || f.properties.name)).addTo(map);
    });
    map.on('mouseleave', hoverLayer, () => {
      map.getCanvas().style.cursor = '';
      if (geo && hoverId !== null) map.setFeatureState({ source: 'states', id: hoverId }, { hover: false });
      hoverId = null;
      popup && popup.remove();
    });
    map.on('click', hoverLayer, (e) => {
      const f = e.features && e.features[0];
      const code = f && (geo ? f.properties.state_code : f.properties.code);
      if (code) {
        onSelect(code);
        popup && popup.setLngLat(e.lngLat).setHTML(popupHtml(code)).addTo(map);
      }
    });
  }

  el.controls.addEventListener('click', (e) => {
    const b = e.target.closest('[data-mode]');
    if (!b || !map) return;
    mode = b.dataset.mode;
    el.controls.querySelectorAll('[data-mode]').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
    if (map.getLayer('states-fill')) map.setPaintProperty('states-fill', 'fill-color', fillColorExpr());
    if (!geo && map.getLayer('pts-circle')) map.setPaintProperty('pts-circle', 'circle-color', pointColorExpr());
    renderLegend();
  });
  el.heat.addEventListener('change', () => map && map.getLayer('heat') && map.setLayoutProperty('heat', 'visibility', el.heat.checked ? 'visible' : 'none'));
  el.labels.addEventListener('change', () => map && map.getLayer('pts-label') && map.setLayoutProperty('pts-label', 'visibility', el.labels.checked ? 'visible' : 'none'));
  el.day.addEventListener('input', () => { day = Number(el.day.value); applyDay(); });
  el.play.addEventListener('click', () => {
    if (timer) { stop(); return; }
    el.play.textContent = '❚❚';
    el.play.setAttribute('aria-label', 'Pause animation');
    timer = setInterval(() => {
      day = (day + 1) % ((risk && risk.dates.length) || 7);
      el.day.value = String(day);
      applyDay();
    }, 1300);
  });
  function stop() {
    clearInterval(timer); timer = null;
    el.play.textContent = '▶';
    el.play.setAttribute('aria-label', 'Play 7-day animation');
  }

  // ---------- boot ----------
  (async () => {
    if (!window.maplibregl) {
      showStatus('<div class="alert alert-error">Map library failed to load. Check your internet connection and reload.</div>');
      return;
    }
    const [geoRes, riskRes] = await Promise.allSettled([api.mapGeo(), api.mapRisk()]);
    if (destroyed) return;
    if (riskRes.status === 'rejected') {
      showStatus(`<div class="alert alert-error">${esc(riskRes.reason.message || 'Weather data temporarily unavailable.')}</div>`);
      return;
    }
    risk = riskRes.value;
    if (geoRes.status === 'fulfilled') {
      geo = structuredClone(geoRes.value);
      idsByCode = {};
      geo.features.forEach((f, i) => {
        f.id = i;
        const c = f.properties.state_code;
        if (c) (idsByCode[c] = idsByCode[c] || []).push(i);
      });
    }
    el.day.max = String(Math.max(0, risk.dates.length - 1));

    const style = await loadStyle(currentTheme());
    if (destroyed) return;
    map = new window.maplibregl.Map({
      container: el.map,
      style,
      center: [82.8, 22.6],
      zoom: compact ? 3.35 : 3.75,
      minZoom: 2.8,
      maxZoom: 9,
      maxBounds: [[55, -2], [110, 42]],
      dragRotate: false,
      pitchWithRotate: false,
      attributionControl: { compact: true },
    });
    map.touchZoomRotate.disableRotation();
    map.addControl(new window.maplibregl.NavigationControl({ showCompass: false }), 'top-right');
    map.on('style.load', () => { if (!destroyed) addLayers(); });
    map.once('load', () => {
      el.status.hidden = true;
      el.controls.hidden = false;
      renderLegend();
      bindEvents();
      if (!geo) {
        el.controls.insertAdjacentHTML('beforeend', `<div class="alert alert-warn small" style="margin:0">State boundary file not installed — showing representative points. Run <code>npm run fetch-geo</code>.</div>`);
      }
      if (risk.meta && risk.meta.stale) {
        el.controls.insertAdjacentHTML('beforeend', `<div class="badge badge-stale">${esc(risk.meta.message || 'Showing cached data')}</div>`);
      }
    });
  })().catch((e) => showStatus(`<div class="alert alert-error">Map error: ${esc(e.message)}</div>`));

  return {
    setSelected(code) {
      selected = code;
      if (map && map.getLayer('states-selected')) map.setFilter('states-selected', ['==', ['get', 'state_code'], code || '']);
    },
    async retheme() {
      if (!map) return;
      const style = await loadStyle(currentTheme());
      if (!destroyed) map.setStyle(style, { diff: false }); // style.load → addLayers()
    },
    resize() { map && map.resize(); },
    destroy() {
      destroyed = true;
      stop();
      popup && popup.remove();
      if (map) map.remove();
    },
  };
}
