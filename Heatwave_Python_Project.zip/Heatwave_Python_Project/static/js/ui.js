// Small DOM + formatting helpers shared by all pages.

export function h(html) {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ESC[c]);

export const fmtT = (v, d = 0) => (typeof v === 'number' ? `${v.toFixed(d)}°` : '—');
export const fmtTC = (v, d = 1) => (typeof v === 'number' ? `${v.toFixed(d)} °C` : '—');
export const fmtPct = (v) => (typeof v === 'number' ? `${Math.round(v)}%` : '—');

export function fmtDate(ymd, opts = { weekday: 'short', day: 'numeric', month: 'short' }) {
  if (!ymd) return '—';
  return new Date(`${ymd}T00:00:00`).toLocaleDateString('en-IN', opts);
}
export const dayName = (ymd) => new Date(`${ymd}T00:00:00`).toLocaleDateString('en-IN', { weekday: 'short' });
export const shortDate = (ymd) => new Date(`${ymd}T00:00:00`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });

export function fmtStamp(iso) {
  if (!iso) return '—';
  const d = new Date(iso.length === 16 ? `${iso}:00+05:30` : iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Kolkata' }) + ' IST';
}

export const RISK = {
  VERY_LOW: { label: 'Very Low', color: '#2e9e5b' },
  LOW: { label: 'Low', color: '#8bc34a' },
  MEDIUM: { label: 'Medium', color: '#f2c94c' },
  ELEVATED: { label: 'Elevated', color: '#f2994a' },
  HIGH: { label: 'High', color: '#e0412f' },
  EXTREME: { label: 'Extreme', color: '#8b0f1a' },
};
export const riskChip = (level) => (level ? `<span class="risk" data-level="${esc(level)}">${esc(RISK[level]?.label || level)}</span>` : '<span class="badge">n/a</span>');

export const loading = (msg) => `<div class="state-msg" role="status"><span class="spinner"></span>${esc(msg)}</div>`;
export const errorBox = (msg) => `<div class="alert alert-error" role="alert">${esc(msg)}</div>`;

export function metaBadges(meta, source) {
  const parts = [`<span class="badge badge-rep" title="${esc(source?.note || '')}">State representative weather</span>`];
  if (meta?.stale) parts.push(`<span class="badge badge-stale">${esc(meta.message || 'Showing cached data')}</span>`);
  return parts.join(' ');
}
export const updatedStamp = (meta) => `<span class="stamp">Last updated: ${esc(fmtStamp(meta?.lastUpdated))}</span>`;

export function toast(msg, type = 'info') {
  const box = document.getElementById('toasts');
  const t = h(`<div class="toast ${type === 'error' ? 'error' : ''}">${esc(msg)}</div>`);
  box.appendChild(t);
  setTimeout(() => t.remove(), 3800);
}

export function setBusy(btn, busy, text) {
  if (!btn) return;
  if (busy) {
    btn.dataset.label = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner"></span>${esc(text || 'Please wait…')}`;
  } else {
    btn.disabled = false;
    if (btn.dataset.label) btn.innerHTML = btn.dataset.label;
  }
}

/** Simple weather icon by WMO code. */
export function wxIcon(code) {
  const c = Number(code);
  const sun = '<circle cx="16" cy="16" r="6" fill="#f59e0b"/><g stroke="#f59e0b" stroke-width="2.2" stroke-linecap="round"><path d="M16 3v3M16 26v3M3 16h3M26 16h3M6.8 6.8l2.1 2.1M23.1 23.1l2.1 2.1M6.8 25.2l2.1-2.1M23.1 8.9l2.1-2.1"/></g>';
  const cloud = (x = 0, fill = '#9fb0cc') => `<path transform="translate(${x} 0)" d="M10 25h13a5 5 0 0 0 0-10 7 7 0 0 0-13.4 1.6A4.2 4.2 0 0 0 10 25z" fill="${fill}"/>`;
  const rain = '<g stroke="#60a5fa" stroke-width="2" stroke-linecap="round"><path d="M12 27l-1 3M17 27l-1 3M22 27l-1 3"/></g>';
  let body;
  if (c === 0 || c === 1) body = sun;
  else if (c === 2) body = `<g transform="translate(-3 -4) scale(.8)">${sun}</g>${cloud(2)}`;
  else if (c === 3 || c === 45 || c === 48) body = cloud(0);
  else if (c >= 95) body = `${cloud(0, '#7c8aa5')}<path d="M17 24l-3 5h3l-2 4 5-6h-3l2-3z" fill="#f59e0b"/>`;
  else if ((c >= 51 && c <= 67) || (c >= 80 && c <= 82)) body = `<g transform="translate(0 -3)">${cloud(0)}</g>${rain}`;
  else if (c >= 71 && c <= 86) body = `<g transform="translate(0 -3)">${cloud(0)}</g><g fill="#cfe3ff"><circle cx="12" cy="28" r="1.4"/><circle cx="17" cy="29" r="1.4"/><circle cx="22" cy="28" r="1.4"/></g>`;
  else body = cloud(0);
  return `<svg class="wx-icon" viewBox="0 0 32 32" aria-hidden="true">${body}</svg>`;
}

export function fieldErrors(form, fields) {
  form.querySelectorAll('.field').forEach((f) => { f.classList.remove('invalid'); const e = f.querySelector('.err'); if (e) e.textContent = ''; });
  if (!fields) return;
  for (const [name, msg] of Object.entries(fields)) {
    const input = form.querySelector(`[name="${name}"]`);
    const field = input && input.closest('.field');
    if (field) { field.classList.add('invalid'); const e = field.querySelector('.err'); if (e) e.textContent = msg; }
  }
}

export function pwToggle(root) {
  root.querySelectorAll('.pw-toggle').forEach((b) => b.addEventListener('click', () => {
    const input = b.parentElement.querySelector('input');
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    b.textContent = show ? 'Hide' : 'Show';
    b.setAttribute('aria-pressed', String(show));
  }));
}
