// ONE shared selected-state value for the whole app.
// Dropdown, search box and map all call select(); every page subscribes.
import { api } from './api.js';

const listeners = new Set();
const state = {
  user: null,
  states: [],
  selectedCode: null,
};

function readSaved() {
  try { return localStorage.getItem('ci-state'); } catch { return null; }
}
function save(code) {
  try { localStorage.setItem('ci-state', code); } catch { /* ignore */ }
}

export const store = {
  get user() { return state.user; },
  set user(u) { state.user = u; emit('user'); },
  get states() { return state.states; },
  get selected() { return state.states.find((s) => s.code === state.selectedCode) || null; },

  async loadStates() {
    if (state.states.length) return state.states;
    const { states } = await api.states();
    state.states = states;
    const saved = readSaved();
    const pref = state.user && states.find((s) => s.name.toLowerCase() === String(state.user.state || '').toLowerCase());
    state.selectedCode = (states.find((s) => s.code === saved) || pref || states.find((s) => s.code === 'DL') || states[0] || {}).code || null;
    return states;
  },

  /** method: 'dropdown' | 'search' | 'map' */
  select(codeOrId, method = 'dropdown') {
    const st = state.states.find((s) => s.code === codeOrId || s.id === Number(codeOrId));
    if (!st || st.code === state.selectedCode) return;
    state.selectedCode = st.code;
    save(st.code);
    emit('selected', { method });
    if (state.user) api.addSearch(st.id, method).catch(() => { /* history is best-effort */ });
  },

  subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
};

function emit(type, detail = {}) {
  for (const fn of [...listeners]) {
    try { fn(type, detail); } catch (e) { console.error(e); }
  }
}
